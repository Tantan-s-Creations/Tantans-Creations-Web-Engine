"""Startup launcher for browsing and creating projects."""
from __future__ import annotations

import json
import os
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from ..core.project import Project
from ..core.theme import apply_theme, PALETTE


RECENTS_FILE = Path.home() / ".tantan_engine_recent_projects.json"


class ProjectWizardDialog(tk.Toplevel):
    """Project creation wizard used by the launcher and editor."""

    def __init__(self, parent):
        super().__init__(parent)
        self.title("Create Project")
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()
        self.result = None

        self._theme = apply_theme(self)
        self.configure(background=PALETTE["bg"])

        frame = ttk.Frame(self, padding=18)
        frame.pack(fill=tk.BOTH, expand=True)

        ttk.Label(frame, text="New Project", style="Header.TLabel").grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 8))
        ttk.Label(frame, text="Create a project, choose a template, and set the startup scene.", style="Subtle.TLabel").grid(row=1, column=0, columnspan=3, sticky="w", pady=(0, 10))

        self.name_var = tk.StringVar(value="MyGame")
        self.location_var = tk.StringVar(value=str(Path.cwd()))
        self.type_var = tk.StringVar(value="3D")
        self.template_var = tk.StringVar(value="3D FPS")
        self.scene_var = tk.StringVar(value="MainScene")
        self.company_var = tk.StringVar(value="Tantan's Creations")
        self.product_var = tk.StringVar(value="My Game")
        self.description_var = tk.StringVar(value="")

        self._field(frame, 2, "Project name", self.name_var)
        self._field(frame, 3, "Location", self.location_var, browse=True)
        self._combo(frame, 4, "Project type", self.type_var, ["2D", "3D", "Hybrid"])
        self._combo(frame, 5, "Template", self.template_var, ["Empty", "2D Platformer", "3D FPS"])
        self._field(frame, 6, "Startup scene", self.scene_var)
        self._field(frame, 7, "Company", self.company_var)
        self._field(frame, 8, "Product", self.product_var)
        self._field(frame, 9, "Description", self.description_var)

        button_row = ttk.Frame(frame)
        button_row.grid(row=10, column=0, columnspan=3, sticky="e", pady=(14, 0))
        ttk.Button(button_row, text="Cancel", command=self._cancel).pack(side=tk.RIGHT, padx=(8, 0))
        ttk.Button(button_row, text="Create", style="Success.TButton", command=self._confirm).pack(side=tk.RIGHT)

        self.bind("<Return>", lambda e: self._confirm())
        self.bind("<Escape>", lambda e: self._cancel())
        self.protocol("WM_DELETE_WINDOW", self._cancel)

        frame.columnconfigure(1, weight=1)
        self.update_idletasks()
        self.geometry(f"{min(580, self.winfo_reqwidth())}x{self.winfo_reqheight()}")

    def _field(self, parent, row, label, variable, browse=False):
        ttk.Label(parent, text=f"{label}:").grid(row=row, column=0, sticky="w", pady=5, padx=(0, 10))
        entry = ttk.Entry(parent, textvariable=variable, width=42)
        entry.grid(row=row, column=1, sticky="ew", pady=5)
        if browse:
            ttk.Button(parent, text="Browse", command=self._browse).grid(row=row, column=2, sticky="e", padx=(8, 0))
        parent.columnconfigure(1, weight=1)

    def _combo(self, parent, row, label, variable, values):
        ttk.Label(parent, text=f"{label}:").grid(row=row, column=0, sticky="w", pady=5, padx=(0, 10))
        box = ttk.Combobox(parent, textvariable=variable, values=values, state="readonly")
        box.grid(row=row, column=1, columnspan=2, sticky="ew", pady=5)

    def _browse(self):
        path = filedialog.askdirectory(title="Choose project folder")
        if path:
            self.location_var.set(path)

    def _confirm(self):
        name = self.name_var.get().strip()
        location = self.location_var.get().strip()
        if not name:
            messagebox.showwarning("Create Project", "Project name is required.", parent=self)
            return
        if not location:
            messagebox.showwarning("Create Project", "Project location is required.", parent=self)
            return
        self.result = {
            "name": name,
            "location": location,
            "project_type": self.type_var.get(),
            "template": self.template_var.get(),
            "scene_name": self.scene_var.get().strip() or "MainScene",
            "company": self.company_var.get().strip() or "Tantan's Creations",
            "product": self.product_var.get().strip() or name,
            "description": self.description_var.get().strip(),
        }
        self.destroy()

    def _cancel(self):
        self.result = None
        self.destroy()


class ProjectLauncher(tk.Tk):
    """Startup window listing recent projects and providing quick actions."""

    def __init__(self):
        super().__init__()
        self.title("Tantan's Creations Web Engine")
        self.geometry("1120x720")
        self.minsize(980, 640)

        self._theme = apply_theme(self)
        self.configure(background=PALETTE["bg"])

        self.recents = self._load_recents()
        self._build_ui()
        self._refresh_recent_list()

        self.protocol("WM_DELETE_WINDOW", self.destroy)

    def _build_ui(self):
        outer = ttk.Frame(self, padding=20)
        outer.pack(fill=tk.BOTH, expand=True)

        hero = ttk.Frame(outer)
        hero.pack(fill=tk.X, pady=(0, 16))

        banner = ttk.Frame(hero)
        banner.pack(fill=tk.X)
        ttk.Label(banner, text="Tantan's Creations Web Engine", style="Header.TLabel").pack(anchor="w")
        ttk.Label(
            banner,
            text="A pastel editor shell for building, testing, and exporting scenes.",
            style="Subtle.TLabel",
        ).pack(anchor="w", pady=(4, 0))

        quick = ttk.Frame(hero)
        quick.pack(fill=tk.X, pady=(14, 0))
        ttk.Button(quick, text="New Project", style="Success.TButton", command=self.create_project).pack(side=tk.LEFT, padx=(0, 8))
        ttk.Button(quick, text="Open Project...", style="Accent.TButton", command=self.open_project_dialog).pack(side=tk.LEFT, padx=(0, 8))
        ttk.Button(quick, text="Refresh", command=self.refresh_recent_projects).pack(side=tk.LEFT)

        body = ttk.Panedwindow(outer, orient=tk.HORIZONTAL)
        body.pack(fill=tk.BOTH, expand=True)

        left = ttk.Frame(body)
        right = ttk.Frame(body)
        body.add(left, weight=3)
        body.add(right, weight=1)

        recent_card = ttk.Labelframe(left, text="Recent Projects", padding=10)
        recent_card.pack(fill=tk.BOTH, expand=True)

        self.recent_tree = ttk.Treeview(recent_card, columns=("name", "path"), show="headings", height=16)
        self.recent_tree.heading("name", text="Project")
        self.recent_tree.heading("path", text="Location")
        self.recent_tree.column("name", width=220, anchor="w")
        self.recent_tree.column("path", width=520, anchor="w")
        self.recent_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        recent_scroll = ttk.Scrollbar(recent_card, orient="vertical", command=self.recent_tree.yview)
        self.recent_tree.configure(yscrollcommand=recent_scroll.set)
        recent_scroll.pack(side=tk.RIGHT, fill=tk.Y)

        self.recent_tree.bind("<Double-1>", lambda e: self.open_selected())
        self.recent_tree.bind("<Return>", lambda e: self.open_selected())

        side_top = ttk.Labelframe(right, text="Get Started", padding=14)
        side_top.pack(fill=tk.X)
        ttk.Label(
            side_top,
            text="Create a project, pick a 2D or 3D template, and launch straight into the editor.",
            wraplength=260,
            justify="left",
        ).pack(anchor="w", pady=(0, 12))
        ttk.Button(side_top, text="Create Project", style="Success.TButton", command=self.create_project).pack(fill=tk.X, pady=4)
        ttk.Button(side_top, text="Open Project Folder", style="Accent.TButton", command=self.open_project_dialog).pack(fill=tk.X, pady=4)
        ttk.Button(side_top, text="Open Recents Folder", command=self.open_recents_folder).pack(fill=tk.X, pady=4)

        info_card = ttk.Labelframe(right, text="Launcher Info", padding=14)
        info_card.pack(fill=tk.X, pady=(14, 0))
        self.info_label = ttk.Label(info_card, text="", justify="left", wraplength=260)
        self.info_label.pack(anchor="w")
        self._refresh_info()

    def _refresh_info(self):
        self.info_label.config(text=f"Recent projects: {len(self.recents)}\nConfig: {RECENTS_FILE}")

    def _load_recents(self):
        if RECENTS_FILE.exists():
            try:
                data = json.loads(RECENTS_FILE.read_text(encoding="utf-8"))
                if isinstance(data, list):
                    return [str(Path(p)) for p in data if p]
            except Exception:
                pass
        return []

    def _save_recents(self):
        RECENTS_FILE.write_text(json.dumps(self.recents[:12], indent=2), encoding="utf-8")
        self._refresh_info()

    def _remember_project(self, path: str):
        norm = str(Path(path))
        self.recents = [p for p in self.recents if p != norm]
        self.recents.insert(0, norm)
        self._save_recents()
        self._refresh_recent_list()

    def _refresh_recent_list(self):
        for item in self.recent_tree.get_children():
            self.recent_tree.delete(item)

        for path in self.recents:
            proj_path = Path(path)
            manifest = proj_path / "Project.tcproj"
            display_name = proj_path.name
            if manifest.exists():
                try:
                    data = json.loads(manifest.read_text(encoding="utf-8"))
                    display_name = data.get("name", display_name)
                except Exception:
                    pass
            self.recent_tree.insert("", tk.END, values=(display_name, path))

    def refresh_recent_projects(self):
        self.recents = self._load_recents()
        self._refresh_recent_list()
        self._refresh_info()

    def selected_project_path(self):
        selection = self.recent_tree.selection()
        if not selection:
            return None
        values = self.recent_tree.item(selection[0], "values")
        if len(values) >= 2:
            return values[1]
        return None

    def open_selected(self):
        path = self.selected_project_path()
        if path:
            self.launch_editor(path)

    def open_project_dialog(self):
        path = filedialog.askdirectory(title="Open Project Folder")
        if path:
            self.launch_editor(path)

    def open_recents_folder(self):
        RECENTS_FILE.parent.mkdir(parents=True, exist_ok=True)
        try:
            os.startfile(str(RECENTS_FILE.parent))  # type: ignore[attr-defined]
        except Exception:
            messagebox.showinfo("Recent Projects", f"Recent projects are stored in:\n{RECENTS_FILE.parent}")

    def create_project(self):
        dialog = ProjectWizardDialog(self)
        self.wait_window(dialog)
        if not dialog.result:
            return

        info = dialog.result
        project_path = Path(info["location"]) / info["name"]
        try:
            project = Project(str(project_path))
            project.settings.project_type = info["project_type"]
            project.settings.company_name = info["company"]
            project.settings.product_name = info["product"]
            project.settings.project_description = info.get("description", "")

            template_map = {
                "Empty": "empty",
                "2D Platformer": "2d",
                "3D FPS": "3d",
            }
            scene_path = project.create_scene(info["scene_name"], template=template_map.get(info["template"], "empty"), set_active=True)
            project.settings.startup_scene = scene_path
            project.set_start_scene(scene_path)
            project.save()

            self._remember_project(str(project_path))
            self.launch_editor(str(project_path))
        except Exception as exc:
            messagebox.showerror("Create Project", f"Failed to create project:\n{exc}")

    def launch_editor(self, project_path: str):
        self._remember_project(project_path)
        self.destroy()

        from .main_window import MainWindow
        app = MainWindow(project_path=project_path)
        app.run()

    def run(self):
        self.mainloop()
