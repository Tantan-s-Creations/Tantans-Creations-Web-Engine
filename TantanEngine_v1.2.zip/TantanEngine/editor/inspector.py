"""Property inspector panel"""
import tkinter as tk
from tkinter import ttk
from ..core.ecs import Transform, MeshFilter, MeshRenderer, SpriteRenderer, Camera, Light, Script, RigidBody, BoxCollider
from ..core.math3d import Vector3

class InspectorPanel(ttk.Frame):
    """Dynamic property inspector for selected entity"""
    def __init__(self, parent, engine, **kwargs):
        super().__init__(parent, **kwargs)
        self.engine = engine
        self.current_entity = None

        # Header
        self.header = ttk.Label(self, text="Inspector", font=("Bungee", 10, "bold"))
        self.header.pack(fill=tk.X, pady=5)

        # Scrollable frame
        self.canvas = tk.Canvas(self, highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.content = ttk.Frame(self.canvas)

        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.canvas_window = self.canvas.create_window((0, 0), window=self.content, anchor="nw", width=240)

        self.content.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfig(self.canvas_window, width=e.width))

        # Component add button
        self.add_comp_btn = ttk.Button(self, text="+ Add Component", command=self.show_add_component)
        self.add_comp_btn.pack(fill=tk.X, side=tk.BOTTOM, pady=5)

        self.widgets = []

    def inspect(self, entity):
        """Display properties for entity"""
        # Clear existing
        for w in self.widgets:
            w.destroy()
        self.widgets.clear()

        self.current_entity = entity

        if not entity:
            self.header.config(text="Inspector - No Selection")
            return

        self.header.config(text=f"Inspector - {entity.name}")

        # Entity name field
        name_frame = ttk.Frame(self.content)
        name_frame.pack(fill=tk.X, pady=2, padx=5)
        ttk.Label(name_frame, text="Name:").pack(side=tk.LEFT)
        name_var = tk.StringVar(value=entity.name)
        name_entry = ttk.Entry(name_frame, textvariable=name_var)
        name_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        name_var.trace("w", lambda *args: self._set_entity_name(entity, name_var.get()))
        self.widgets.append(name_frame)

        # Active checkbox
        active_frame = ttk.Frame(self.content)
        active_frame.pack(fill=tk.X, pady=2, padx=5)
        active_var = tk.BooleanVar(value=entity.active)
        active_cb = ttk.Checkbutton(active_frame, text="Active", variable=active_var,
                                   command=lambda: self._set_entity_active(entity, active_var.get()))
        active_cb.pack(side=tk.LEFT)
        self.widgets.append(active_frame)

        # Components
        for comp in entity.components:
            self._build_component_ui(comp)

    def _build_component_ui(self, comp):
        """Build UI for a specific component"""
        frame = ttk.LabelFrame(self.content, text=comp.get_type_name(), padding=5)
        frame.pack(fill=tk.X, pady=5, padx=5)
        self.widgets.append(frame)

        # Enabled checkbox
        enabled_var = tk.BooleanVar(value=comp.enabled)
        ttk.Checkbutton(frame, text="Enabled", variable=enabled_var,
                       command=lambda: setattr(comp, "enabled", enabled_var.get())).pack(anchor="w")

        if isinstance(comp, Transform):
            self._build_vector3_field(frame, "Position", comp.position, lambda v: setattr(comp, "position", v))
            self._build_vector3_field(frame, "Rotation", comp.rotation, lambda v: setattr(comp, "rotation", v))
            self._build_vector3_field(frame, "Scale", comp.scale, lambda v: setattr(comp, "scale", v))

        elif isinstance(comp, MeshFilter):
            self._build_string_field(frame, "Mesh Asset ID", comp.mesh_asset_id, 
                                    lambda v: setattr(comp, "mesh_asset_id", v))

        elif isinstance(comp, MeshRenderer):
            self._build_string_field(frame, "Material Asset ID", comp.material_asset_id,
                                    lambda v: setattr(comp, "material_asset_id", v))
            self._build_bool_field(frame, "Cast Shadows", comp.cast_shadows,
                                  lambda v: setattr(comp, "cast_shadows", v))
            self._build_bool_field(frame, "Receive Shadows", comp.receive_shadows,
                                  lambda v: setattr(comp, "receive_shadows", v))

        elif isinstance(comp, SpriteRenderer):
            self._build_string_field(frame, "Texture Asset ID", comp.texture_asset_id,
                                    lambda v: setattr(comp, "texture_asset_id", v))
            self._build_color_field(frame, "Color", comp.color,
                                   lambda v: setattr(comp, "color", v))
            self._build_bool_field(frame, "Flip X", comp.flip_x,
                                  lambda v: setattr(comp, "flip_x", v))
            self._build_bool_field(frame, "Flip Y", comp.flip_y,
                                  lambda v: setattr(comp, "flip_y", v))

        elif isinstance(comp, Camera):
            self._build_float_field(frame, "FOV", comp.fov, lambda v: setattr(comp, "fov", v), 0, 179)
            self._build_float_field(frame, "Near Clip", comp.near_clip, lambda v: setattr(comp, "near_clip", v), 0.001, 100)
            self._build_float_field(frame, "Far Clip", comp.far_clip, lambda v: setattr(comp, "far_clip", v), 1, 10000)
            self._build_bool_field(frame, "Orthographic", comp.is_orthographic,
                                  lambda v: setattr(comp, "is_orthographic", v))
            self._build_float_field(frame, "Ortho Size", comp.orthographic_size,
                                   lambda v: setattr(comp, "orthographic_size", v), 0.1, 100)

        elif isinstance(comp, Light):
            light_types = ["Directional", "Point", "Spot"]
            self._build_dropdown_field(frame, "Type", comp.light_type, light_types,
                                      lambda v: setattr(comp, "light_type", v))
            self._build_color_field(frame, "Color", comp.color,
                                   lambda v: setattr(comp, "color", v))
            self._build_float_field(frame, "Intensity", comp.intensity,
                                   lambda v: setattr(comp, "intensity", v), 0, 100)
            self._build_float_field(frame, "Range", comp.range,
                                   lambda v: setattr(comp, "range", v), 0.1, 1000)

        elif isinstance(comp, Script):
            langs = ["javascript", "csharp"]
            self._build_dropdown_field(frame, "Language", comp.language, langs,
                                      lambda v: setattr(comp, "language", v))
            self._build_string_field(frame, "Source File", comp.source_file,
                                    lambda v: setattr(comp, "source_file", v))
            self._build_string_field(frame, "Class Name", comp.class_name,
                                    lambda v: setattr(comp, "class_name", v))

        elif isinstance(comp, RigidBody):
            self._build_float_field(frame, "Mass", comp.mass, lambda v: setattr(comp, "mass", v), 0.001, 1000)
            self._build_bool_field(frame, "Use Gravity", comp.use_gravity,
                                  lambda v: setattr(comp, "use_gravity", v))
            self._build_bool_field(frame, "Is Kinematic", comp.is_kinematic,
                                  lambda v: setattr(comp, "is_kinematic", v))
            self._build_vector3_field(frame, "Velocity", comp.velocity, lambda v: setattr(comp, "velocity", v))

        elif isinstance(comp, BoxCollider):
            self._build_vector3_field(frame, "Size", comp.size, lambda v: setattr(comp, "size", v))
            self._build_vector3_field(frame, "Center", comp.center, lambda v: setattr(comp, "center", v))
            self._build_bool_field(frame, "Is Trigger", comp.is_trigger,
                                  lambda v: setattr(comp, "is_trigger", v))

    def _build_vector3_field(self, parent, label, vector, setter):
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.X, pady=1)
        ttk.Label(frame, text=label, width=10).pack(side=tk.LEFT)

        vars_list = []
        for i, axis in enumerate(["X", "Y", "Z"]):
            val = [vector.x, vector.y, vector.z][i]
            var = tk.DoubleVar(value=val)
            vars_list.append(var)
            entry = ttk.Spinbox(frame, from_=-9999, to=9999, textvariable=var, width=6, increment=0.1)
            entry.pack(side=tk.LEFT, padx=2)

            var.trace("w", lambda *args, idx=i: self._update_vector3(vector, vars_list, setter))

    def _update_vector3(self, vector, vars, setter):
        try:
            vector.x = vars[0].get()
            vector.y = vars[1].get()
            vector.z = vars[2].get()
            setter(vector)
            self.engine.mark_modified()
        except:
            pass

    def _build_float_field(self, parent, label, value, setter, min_val, max_val):
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.X, pady=1)
        ttk.Label(frame, text=label, width=10).pack(side=tk.LEFT)
        var = tk.DoubleVar(value=value)
        entry = ttk.Spinbox(frame, from_=min_val, to=max_val, textvariable=var, width=10, increment=0.1)
        entry.pack(side=tk.LEFT, padx=2)
        var.trace("w", lambda *args: self._update_value(var, setter))

    def _update_value(self, var, setter):
        try:
            setter(var.get())
            self.engine.mark_modified()
        except:
            pass

    def _build_string_field(self, parent, label, value, setter):
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.X, pady=1)
        ttk.Label(frame, text=label, width=12).pack(side=tk.LEFT)
        var = tk.StringVar(value=value)
        entry = ttk.Entry(frame, textvariable=var)
        entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=2)
        var.trace("w", lambda *args: self._update_value(var, setter))

    def _build_bool_field(self, parent, label, value, setter):
        var = tk.BooleanVar(value=value)
        cb = ttk.Checkbutton(parent, text=label, variable=var,
                            command=lambda: self._update_value(var, setter))
        cb.pack(anchor="w", pady=1)

    def _build_dropdown_field(self, parent, label, value, options, setter):
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.X, pady=1)
        ttk.Label(frame, text=label, width=10).pack(side=tk.LEFT)
        var = tk.StringVar(value=value)
        dropdown = ttk.Combobox(frame, textvariable=var, values=options, state="readonly", width=15)
        dropdown.pack(side=tk.LEFT, padx=2)
        var.trace("w", lambda *args: self._update_value(var, setter))

    def _build_color_field(self, parent, label, color_dict, setter):
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.X, pady=1)
        ttk.Label(frame, text=label, width=10).pack(side=tk.LEFT)

        vars_list = []
        for i, ch in enumerate([("R", "r"), ("G", "g"), ("B", "b"), ("A", "a")]):
            lbl, key = ch
            val = color_dict.get(key, 1.0)
            var = tk.DoubleVar(value=val)
            vars_list.append((key, var))
            entry = ttk.Spinbox(frame, from_=0, to=1, textvariable=var, width=5, increment=0.01)
            entry.pack(side=tk.LEFT, padx=1)
            var.trace("w", lambda *args: self._update_color(color_dict, vars_list, setter))

    def _update_color(self, color_dict, vars, setter):
        try:
            for key, var in vars:
                color_dict[key] = var.get()
            setter(color_dict)
            self.engine.mark_modified()
        except:
            pass

    def _set_entity_name(self, entity, name):
        entity.name = name
        self.engine.mark_modified()
        if self.engine.hierarchy_panel:
            self.engine.hierarchy_panel.refresh()

    def _set_entity_active(self, entity, active):
        entity.active = active
        self.engine.mark_modified()

    def show_add_component(self):
        """Show dialog to add component to selected entity"""
        if not self.current_entity:
            return

        dialog = tk.Toplevel(self)
        dialog.title("Add Component")
        dialog.geometry("250x300")
        dialog.transient(self.winfo_toplevel())
        dialog.grab_set()

        components = [
            ("Transform", Transform),
            ("Mesh Filter", MeshFilter),
            ("Mesh Renderer", MeshRenderer),
            ("Sprite Renderer", SpriteRenderer),
            ("Camera", Camera),
            ("Light", Light),
            ("Script", Script),
            ("RigidBody", RigidBody),
            ("Box Collider", BoxCollider),
        ]

        listbox = tk.Listbox(dialog)
        for name, _ in components:
            listbox.insert(tk.END, name)
        listbox.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        def on_add():
            sel = listbox.curselection()
            if sel:
                _, comp_class = components[sel[0]]
                # Check if already exists (only one Transform allowed)
                if comp_class == Transform:
                    if self.current_entity.get_component(Transform):
                        return

                self.current_entity.add_component(comp_class)
                self.inspect(self.current_entity)
                self.engine.mark_modified()
            dialog.destroy()

        ttk.Button(dialog, text="Add", command=on_add).pack(pady=5)
