"""Scene hierarchy panel"""
import tkinter as tk
from tkinter import ttk
from ..core.ecs import Entity, Transform

class HierarchyPanel(ttk.Frame):
    """Scene hierarchy tree view"""
    def __init__(self, parent, engine, **kwargs):
        super().__init__(parent, **kwargs)
        self.engine = engine

        # Toolbar
        toolbar = ttk.Frame(self)
        toolbar.pack(fill=tk.X, pady=2)

        ttk.Button(toolbar, text="➕", width=3, command=self.add_entity).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="🗑", width=3, command=self.delete_selected).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="🔍", width=3, command=self.focus_selected).pack(side=tk.LEFT, padx=2)

        # Tree
        self.tree = ttk.Treeview(self, columns=("type",), show="tree", selectmode="browse")
        self.tree.heading("#0", text="Hierarchy")
        self.tree.column("#0", width=200)

        scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)

        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # Bindings
        self.tree.bind("<<TreeviewSelect>>", self.on_select)
        self.tree.bind("<Button-3>", self.show_context_menu)

        self.entity_map = {}  # tree iid -> entity id
        self._refresh_pending = False

    def refresh(self):
        """Refresh the hierarchy tree"""
        if self._refresh_pending:
            return
        self._refresh_pending = True
        self.after(50, self._do_refresh)

    def _do_refresh(self):
        self._refresh_pending = False

        # Save selection
        selected = self.tree.selection()
        selected_id = self.entity_map.get(selected[0]) if selected else None

        # Clear
        for item in self.tree.get_children():
            self.tree.delete(item)
        self.entity_map.clear()

        if not self.engine.current_scene:
            return

        # Populate
        for entity in self.engine.current_scene.root_entities:
            self._add_entity_to_tree(entity, "")

        # Restore selection
        if selected_id:
            for iid, eid in self.entity_map.items():
                if eid == selected_id:
                    self.tree.selection_set(iid)
                    break

    def _add_entity_to_tree(self, entity, parent_iid):
        icon = "📦"
        if entity.get_component(Transform):
            icon = "🧊"

        iid = self.tree.insert(parent_iid, "end", text=f"{icon} {entity.name}", open=True)
        self.entity_map[iid] = entity.id

        for child in entity.children:
            self._add_entity_to_tree(child, iid)

    def on_select(self, event):
        selected = self.tree.selection()
        if selected:
            entity_id = self.entity_map.get(selected[0])
            if entity_id and self.engine.current_scene:
                entity = self.engine.current_scene.entities.get(entity_id)
                if entity:
                    self.engine.select_entity(entity)

    def add_entity(self):
        if self.engine.current_scene:
            entity = self.engine.current_scene.create_entity("New Entity")
            self.refresh()
            self.engine.mark_modified()

    def delete_selected(self):
        selected = self.tree.selection()
        if selected:
            entity_id = self.entity_map.get(selected[0])
            if entity_id and self.engine.current_scene:
                entity = self.engine.current_scene.entities.get(entity_id)
                if entity:
                    self.engine.current_scene.destroy_entity(entity)
                    self.refresh()
                    self.engine.select_entity(None)
                    self.engine.mark_modified()

    def focus_selected(self):
        if self.engine.viewport:
            self.engine.viewport.focus_selected()

    def show_context_menu(self, event):
        item = self.tree.identify_row(event.y)
        if item:
            self.tree.selection_set(item)
            menu = tk.Menu(self, tearoff=0)
            menu.add_command(label="Duplicate", command=lambda: self.duplicate_entity(item))
            menu.add_command(label="Rename", command=lambda: self.rename_entity(item))
            menu.add_separator()
            menu.add_command(label="Create Empty Child", command=lambda: self.add_child(item))
            menu.tk_popup(event.x_root, event.y_root)

    def duplicate_entity(self, item):
        entity_id = self.entity_map.get(item)
        if entity_id and self.engine.current_scene:
            original = self.engine.current_scene.entities.get(entity_id)
            if original:
                # Clone
                clone = self.engine.current_scene.create_entity(original.name + " (Copy)")
                # Copy components
                for comp in original.components:
                    if comp.get_type_name() != "Transform":
                        new_comp = comp.copy()
                        new_comp.entity = clone
                        clone.components.append(new_comp)
                self.refresh()
                self.engine.mark_modified()

    def rename_entity(self, item):
        # Simplified - would open dialog
        pass

    def add_child(self, item):
        entity_id = self.entity_map.get(item)
        if entity_id and self.engine.current_scene:
            parent = self.engine.current_scene.entities.get(entity_id)
            if parent:
                child = self.engine.current_scene.create_entity("New Entity", parent)
                self.refresh()
                self.engine.mark_modified()
