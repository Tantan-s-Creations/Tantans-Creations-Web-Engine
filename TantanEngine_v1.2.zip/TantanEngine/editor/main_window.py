"""Main editor window for Tantan's Creations Web Engine."""
from __future__ import annotations

import json
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

from ..core.assets import AssetDatabase
from ..core.ecs import Scene, Transform, MeshFilter, MeshRenderer, SpriteRenderer, Camera, Light
from ..core.project import Project
from ..core.theme import apply_theme, PALETTE
from ..exporters.html_exporter import HTMLExporter
from ..runtime.scripting_host import ScriptingHost
from .viewport import Viewport
from .inspector import InspectorPanel
from .console import ConsolePanel
from .script_editor import ScriptEditor
from .project_browser import ProjectBrowser
from .toolbar import EditorToolbar
from .hierarchy import HierarchyPanel


class MainWindow:
    """Editor shell with a Unity-like workspace."""
    def __init__(self, project_path: str | None = None):
        self.root = tk.Tk()
        self.root.title("Tantan's Creations Web Engine")
        self.root.geometry("1600x980")
        self.root.minsize(1240, 760)
        self.root.configure(background=PALETTE["bg"])

        self.theme = apply_theme(self.root)

        self.project: Project | None = None
        self.asset_db: AssetDatabase | None = None
        self.current_scene: Scene | None = None
        self.current_scene_path: str | None = None
        self.selected_entity = None
        self.is_playing = False
        self.is_modified = False
        self.script_host = None
        self.play_mode_scene_backup = None
        self.play_mode_scene_path_backup = None
        self._setting_vars = {}
        self._build_scene_tree = None
        self._build_scene_map = {}

        self.toolbar = None
        self.viewport = None
        self.hierarchy_panel = None
        self.inspector_panel = None
        self.project_browser = None
        self.script_editor = None
        self.console = None
        self.status_bar = None

        self._build_ui()
        self._build_menu()
        self._update_title()

        self.root.protocol("WM_DELETE_WINDOW", self.on_exit)

        if project_path:
            self.open_project_path(project_path)

    # ------------------------------------------------------------------
    # UI
    # ------------------------------------------------------------------

    def _build_ui(self):
        outer = ttk.Frame(self.root, padding=10)
        outer.pack(fill=tk.BOTH, expand=True)

        self.toolbar = EditorToolbar(outer, self)
        self.toolbar.pack(fill=tk.X, pady=(0, 8))

        main_paned = ttk.Panedwindow(outer, orient=tk.HORIZONTAL)
        main_paned.pack(fill=tk.BOTH, expand=True)

        left_frame = ttk.Frame(main_paned, width=310)
        main_paned.add(left_frame, weight=0)

        self.hierarchy_panel = HierarchyPanel(left_frame, self)
        self.hierarchy_panel.pack(fill=tk.BOTH, expand=True)

        center_paned = ttk.Panedwindow(main_paned, orient=tk.VERTICAL)
        main_paned.add(center_paned, weight=1)

        viewport_frame = ttk.Frame(center_paned)
        center_paned.add(viewport_frame, weight=2)
        self.viewport = Viewport(viewport_frame, self, width=900, height=560)
        self.viewport.pack(fill=tk.BOTH, expand=True)

        bottom_tabs = ttk.Notebook(center_paned)
        center_paned.add(bottom_tabs, weight=1)

        proj_tab = ttk.Frame(bottom_tabs)
        bottom_tabs.add(proj_tab, text="📁 Project")
        self.project_browser = ProjectBrowser(proj_tab, self)
        self.project_browser.pack(fill=tk.BOTH, expand=True)

        script_tab = ttk.Frame(bottom_tabs)
        bottom_tabs.add(script_tab, text="📜 Script Editor")
        self.script_editor = ScriptEditor(script_tab, self)
        self.script_editor.pack(fill=tk.BOTH, expand=True)

        console_tab = ttk.Frame(bottom_tabs)
        bottom_tabs.add(console_tab, text="💻 Console")
        self.console = ConsolePanel(console_tab, self)
        self.console.pack(fill=tk.BOTH, expand=True)

        right_frame = ttk.Frame(main_paned, width=320)
        main_paned.add(right_frame, weight=0)
        self.inspector_panel = InspectorPanel(right_frame, self)
        self.inspector_panel.pack(fill=tk.BOTH, expand=True)

        self.status_bar = ttk.Label(self.root, text="No Project", style="Sunk.TLabel", anchor=tk.W)
        self.status_bar.pack(fill=tk.X, side=tk.BOTTOM)

    def _build_menu(self):
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)

        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="New Project...", command=self.new_project, accelerator="Ctrl+N")
        file_menu.add_command(label="Open Project...", command=self.open_project, accelerator="Ctrl+O")
        file_menu.add_command(label="Save Project", command=self.save_project, accelerator="Ctrl+S")
        file_menu.add_separator()
        file_menu.add_command(label="New Scene", command=self.new_scene)
        file_menu.add_command(label="Save Scene", command=self.save_scene)
        file_menu.add_separator()
        file_menu.add_command(label="Build HTML...", command=self.build_html)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.on_exit)

        edit_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Edit", menu=edit_menu)
        edit_menu.add_command(label="Undo", command=self.undo)
        edit_menu.add_command(label="Redo", command=self.redo)
        edit_menu.add_separator()
        edit_menu.add_command(label="Duplicate", command=self.duplicate_selected)
        edit_menu.add_command(label="Delete", command=self.delete_selected)

        go_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="GameObject", menu=go_menu)
        go_menu.add_command(label="Create Empty", command=self.create_empty)
        go_menu.add_command(label="Create Cube", command=self.create_cube)
        go_menu.add_command(label="Create Sprite", command=self.create_sprite)
        go_menu.add_command(label="Create Light", command=self.create_light)
        go_menu.add_command(label="Create Camera", command=self.create_camera)

        win_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Window", menu=win_menu)
        win_menu.add_command(label="Project Settings", command=self.open_settings)
        win_menu.add_command(label="Console", command=self.focus_console)
        win_menu.add_command(label="Project Browser", command=self.focus_project_browser)

        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="Documentation", command=self.show_docs)
        help_menu.add_command(label="About", command=self.show_about)

        self.root.bind("<Control-n>", lambda e: self.new_project())
        self.root.bind("<Control-o>", lambda e: self.open_project())
        self.root.bind("<Control-s>", lambda e: self.save_project())
        self.root.bind("<Delete>", lambda e: self.delete_selected())
        self.root.bind("<F5>", lambda e: self.toolbar.on_play())

    # ------------------------------------------------------------------
    # Project lifecycle
    # ------------------------------------------------------------------

    def _project_type_template(self) -> str:
        if not self.project:
            return "empty"
        t = self.project.settings.project_type
        return {"2D": "2d", "3D": "3d", "Hybrid": "empty"}.get(t, "empty")

    def new_project(self):
        from .launcher import ProjectWizardDialog

        dialog = ProjectWizardDialog(self.root)
        self.root.wait_window(dialog)
        if not dialog.result:
            return

        info = dialog.result
        project_path = Path(info["location"]) / info["name"]
        try:
            self.project = Project(str(project_path))
            self.project.settings.project_type = info["project_type"]
            self.project.settings.company_name = info["company"]
            self.project.settings.product_name = info["product"]

            template_map = {"Empty": "empty", "2D Platformer": "2d", "3D FPS": "3d"}
            scene_path = self.project.create_scene(
                info["scene_name"],
                template=template_map.get(info["template"], self._project_type_template()),
                set_active=True,
            )
            self.project.settings.startup_scene = scene_path
            self.project.set_start_scene(scene_path)
            self.project.save()

            self._load_project_assets()
            self.open_scene_path(scene_path)
            self._update_status(f"Created project: {project_path}")
            self.console.log(f"Created project: {project_path}", "info")
            self.mark_modified(False)
        except Exception as exc:
            messagebox.showerror("Create Project", f"Failed to create project:\n{exc}")

    def open_project(self):
        path = filedialog.askdirectory(title="Open Project")
        if path:
            self.open_project_path(path)

    def open_project_path(self, path: str):
        try:
            self.project = Project.load(path)
            self._load_project_assets()

            scene_path = self._preferred_scene_to_open()
            if scene_path:
                self.open_scene_path(scene_path)
            else:
                scene_path = self.project.create_scene("MainScene", template=self._project_type_template(), set_active=True)
                self.project.settings.startup_scene = scene_path
                self.project.set_start_scene(scene_path)
                self.project.save()
                self.open_scene_path(scene_path)

            self._update_ui_for_project()
            self._update_status(f"Opened project: {self.project.name}")
            self.console.log(f"Opened project: {path}", "info")
            self.mark_modified(False)
        except Exception as exc:
            messagebox.showerror("Error", f"Failed to open project: {exc}")

    def _preferred_scene_to_open(self) -> str | None:
        if not self.project:
            return None
        candidates = [
            self.project.active_scene,
            self.project.settings.startup_scene,
            self.project.get_start_scene(),
        ]
        for scene_path in candidates:
            if scene_path and (self.project.path / scene_path).exists():
                return scene_path
        if self.project.scenes:
            return self.project.scenes[0]
        return None

    def _load_project_assets(self):
        if not self.project:
            return
        self.asset_db = AssetDatabase(str(self.project.path))
        self.asset_db.scan_assets()

    def save_project(self):
        if self.project:
            self.save_scene()
            self.project.save()
            self.is_modified = False
            self._update_title()
            self._update_status("Project saved")
            self.console.log("Project saved", "info")

    def _update_ui_for_project(self):
        if not self.project:
            return
        self.status_bar.config(text=f"Project: {self.project.name}")
        self.project_browser.refresh()
        self.hierarchy_panel.refresh()
        if self.viewport and self.project and getattr(self.project, "settings", None):
            self.viewport.show_grid = self.project.settings.editor_show_grid
            self.viewport.nav_speed = self.project.settings.scene_view_navigation_speed
        self._update_title()

    def _update_status(self, text: str):
        if self.status_bar:
            self.status_bar.config(text=text)

    def _update_title(self):
        mod = "● " if self.is_modified else ""
        proj = self.project.name if self.project else "No Project"
        scene = self.current_scene.name if self.current_scene else ""
        self.root.title(f"{mod}Tantan's Creations Web Engine - {proj} - {scene}")

    # ------------------------------------------------------------------
    # Scene management
    # ------------------------------------------------------------------

    def new_scene(self):
        if not self.project:
            return
        name = simpledialog.askstring("New Scene", "Scene name:", initialvalue="NewScene", parent=self.root)
        if name:
            scene_path = self.project.create_scene(name, template=self._project_type_template(), set_active=True)
            self.open_scene_path(scene_path)
            self.project.settings.startup_scene = self.project.get_start_scene() or scene_path
            self.project.save()

    def open_scene_path(self, scene_path: str):
        if not self.project:
            return
        full_path = self.project.path / scene_path
        if not full_path.exists():
            return
        with open(full_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        self.current_scene = Scene.from_dict(data)
        self.current_scene_path = scene_path
        self.project.active_scene = scene_path
        self.project.settings.startup_scene = self.project.get_start_scene() or scene_path
        if self.viewport:
            self.viewport.set_play_mode(False)
        self.hierarchy_panel.refresh()
        self.console.log(f"Loaded scene: {self.current_scene.name}", "info")
        self._update_title()

    def save_scene(self):
        if not self.project or not self.current_scene:
            return

        if not self.current_scene_path:
            self.current_scene_path = f"Assets/Scenes/{self.current_scene.name}.tcscene"

        scene_path = self.project.path / self.current_scene_path
        scene_path.parent.mkdir(parents=True, exist_ok=True)

        with open(scene_path, "w", encoding="utf-8") as f:
            json.dump(self.current_scene.to_dict(), f, indent=2)

        if self.current_scene_path not in self.project.scenes:
            self.project.register_scene(self.current_scene_path, set_active=True)
        self.console.log(f"Saved scene: {self.current_scene.name}", "info")

    def _scene_from_project_path(self, scene_path: str) -> Scene | None:
        if not self.project:
            return None
        full_path = self.project.path / scene_path
        if not full_path.exists():
            return None
        with open(full_path, "r", encoding="utf-8") as f:
            return Scene.from_dict(json.load(f))

    # ------------------------------------------------------------------
    # Entity operations
    # ------------------------------------------------------------------

    def select_entity(self, entity):
        self.selected_entity = entity
        self.viewport.selected_entity = entity
        self.viewport.renderer.selected_entity = entity
        self.inspector_panel.inspect(entity)

    def create_empty(self):
        if self.current_scene:
            entity = self.current_scene.create_entity("Empty")
            self.hierarchy_panel.refresh()
            self.select_entity(entity)
            self.mark_modified()

    def create_cube(self):
        if self.current_scene:
            entity = self.current_scene.create_entity("Cube")
            entity.add_component(MeshFilter)
            entity.add_component(MeshRenderer)
            mf = entity.get_component(MeshFilter)
            if mf:
                mf.mesh_asset_id = ""
            self.hierarchy_panel.refresh()
            self.select_entity(entity)
            self.mark_modified()

    def create_sprite(self):
        if self.current_scene:
            entity = self.current_scene.create_entity("Sprite")
            entity.add_component(SpriteRenderer)
            self.hierarchy_panel.refresh()
            self.select_entity(entity)
            self.mark_modified()

    def create_light(self):
        if self.current_scene:
            entity = self.current_scene.create_entity("Light")
            entity.add_component(Light)
            self.hierarchy_panel.refresh()
            self.select_entity(entity)
            self.mark_modified()

    def create_camera(self):
        if self.current_scene:
            entity = self.current_scene.create_entity("Camera")
            entity.add_component(Camera)
            self.hierarchy_panel.refresh()
            self.select_entity(entity)
            self.mark_modified()

    def duplicate_selected(self):
        if self.selected_entity and self.current_scene:
            original = self.selected_entity
            clone = self.current_scene.create_entity(original.name + " (Copy)")
            for comp in original.components:
                if comp.get_type_name() != "Transform":
                    new_comp = comp.copy()
                    new_comp.entity = clone
                    clone.components.append(new_comp)
            self.hierarchy_panel.refresh()
            self.mark_modified()

    def delete_selected(self):
        if self.selected_entity and self.current_scene:
            self.current_scene.destroy_entity(self.selected_entity)
            self.select_entity(None)
            self.hierarchy_panel.refresh()
            self.mark_modified()

    # ------------------------------------------------------------------
    # Play mode
    # ------------------------------------------------------------------

    def enter_play_mode(self):
        if not self.current_scene or self.is_playing:
            return

        self.is_playing = True
        self.console.log("Entering Play Mode...", "info")
        self.play_mode_scene_backup = self.current_scene.to_dict()
        self.play_mode_scene_path_backup = self.current_scene_path

        if self.viewport:
            self.viewport.set_play_mode(True)
            self.viewport.selected_entity = None
            self.viewport.renderer.selected_entity = None
        self.selected_entity = None
        if self.project and self.asset_db:
            try:
                self.script_host = ScriptingHost(self.current_scene, self.asset_db, str(self.project.path))
                self.script_host.load_scripts()
                self.script_host.call_start()
            except Exception as exc:
                self.console.log(f"Play mode script init failed: {exc}", "error")
                self.script_host = None

        self._play_update_loop()

    def pause_play_mode(self):
        self.is_playing = False
        self.console.log("Play Mode paused", "warning")

    def exit_play_mode(self):
        self.is_playing = False
        self.console.log("Exiting Play Mode...", "info")
        if self.viewport:
            self.viewport.set_play_mode(False)
            self.viewport.selected_entity = None
            self.viewport.renderer.selected_entity = None
        if self.play_mode_scene_backup:
            self.current_scene = Scene.from_dict(self.play_mode_scene_backup)
            self.current_scene_path = getattr(self, "play_mode_scene_path_backup", self.current_scene_path)
            self.play_mode_scene_backup = None
            self.play_mode_scene_path_backup = None
            self.script_host = None
            self.hierarchy_panel.refresh()
            if self.viewport:
                self.viewport.render_loop()
            self._update_title()

    def _play_update_loop(self):
        if not self.is_playing:
            return
        try:
            if hasattr(self, "script_host") and self.script_host:
                self.script_host.call_update(0.016)
        except Exception as exc:
            self.console.log(f"Play mode update error: {exc}", "error")
        self.root.after(16, self._play_update_loop)

    # ------------------------------------------------------------------
    # Build
    # ------------------------------------------------------------------

    def _build_scene_manifest(self):
        if not self.project:
            return {"scenes": [], "start_scene": "", "enabled_scenes": []}
        self.project.sync_build_scenes()
        scenes = self.project.settings.build_scenes
        start_scene = self.project.get_start_scene() or ""
        enabled = [s["path"] for s in scenes if s.get("enabled")]
        return {
            "scenes": scenes,
            "start_scene": start_scene,
            "enabled_scenes": enabled,
            "output_type": self.project.settings.build_output_type,
            "project_type": self.project.settings.project_type,
        }

    def build_html(self):
        if not self.project:
            messagebox.showwarning("Build", "No project is open.")
            return

        start_scene_path = self.project.get_start_scene() or self.project.active_scene
        if not start_scene_path:
            messagebox.showwarning("Build", "No start scene is set.")
            return

        scene = self._scene_from_project_path(start_scene_path)
        if not scene:
            messagebox.showwarning("Build", f"Could not load start scene:\n{start_scene_path}")
            return

        try:
            if not self.asset_db:
                self._load_project_assets()

            exporter = HTMLExporter(str(self.project.path))
            exporter.asset_db = self.asset_db
            exporter.settings = self.project.settings

            build_manifest = self._build_scene_manifest()
            build_dir = self.project.path / "Build"
            build_dir.mkdir(parents=True, exist_ok=True)
            (build_dir / "BuildSettings.json").write_text(json.dumps(build_manifest, indent=2), encoding="utf-8")

            output_name = self.project.settings.product_name or scene.name
            output_path = exporter.export(scene, output_name, self.project.settings.build_output_type)

            self.console.log(f"Build successful: {output_path}", "info")
            messagebox.showinfo("Build Complete", f"HTML exported to:\n{output_path}")
        except Exception as exc:
            self.console.log(f"Build failed: {exc}", "error")
            messagebox.showerror("Build Error", str(exc))

    # ------------------------------------------------------------------
    # Settings
    # ------------------------------------------------------------------

    def open_settings(self):
        if not self.project:
            return

        self._setting_vars = {}
        dialog = tk.Toplevel(self.root)
        dialog.title("Project Settings")
        dialog.geometry("720x760")
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.configure(background=PALETTE["bg"])

        notebook = ttk.Notebook(dialog)
        notebook.pack(fill=tk.BOTH, expand=True, padx=12, pady=12)

        tabs = {
            "Player": ttk.Frame(notebook),
            "Display": ttk.Frame(notebook),
            "Physics": ttk.Frame(notebook),
            "Input": ttk.Frame(notebook),
            "Audio": ttk.Frame(notebook),
            "Scripting": ttk.Frame(notebook),
            "Editor": ttk.Frame(notebook),
            "Rendering": ttk.Frame(notebook),
            "Build": ttk.Frame(notebook),
        }
        for name, frame in tabs.items():
            notebook.add(frame, text=name)

        self._build_settings_player(tabs["Player"])
        self._build_settings_display(tabs["Display"])
        self._build_settings_physics(tabs["Physics"])
        self._build_settings_input(tabs["Input"])
        self._build_settings_audio(tabs["Audio"])
        self._build_settings_scripting(tabs["Scripting"])
        self._build_settings_editor(tabs["Editor"])
        self._build_settings_rendering(tabs["Rendering"])
        self._build_settings_build(tabs["Build"])

        footer = ttk.Frame(dialog)
        footer.pack(fill=tk.X, padx=12, pady=(0, 12))
        ttk.Button(footer, text="Save Settings", style="Success.TButton", command=lambda: self._save_settings(dialog)).pack(side=tk.RIGHT)

    def _section(self, parent, title: str):
        frame = ttk.Labelframe(parent, text=title, padding=10)
        frame.pack(fill=tk.X, pady=6)
        return frame

    def _build_settings_player(self, parent):
        s = self.project.settings
        f = self._section(parent, "Player")
        self._setting_vars["company_name"] = tk.StringVar(value=s.company_name)
        self._entry_row(f, "Company Name", "company_name")
        self._setting_vars["product_name"] = tk.StringVar(value=s.product_name)
        self._entry_row(f, "Product Name", "product_name")
        self._setting_vars["version"] = tk.StringVar(value=s.version)
        self._entry_row(f, "Version", "version")
        self._setting_vars["project_type"] = tk.StringVar(value=s.project_type)
        self._combo_row(f, "Project Type", "project_type", ["2D", "3D", "Hybrid"])
        self._setting_vars["application_identifier"] = tk.StringVar(value=s.application_identifier)
        self._entry_row(f, "App Identifier", "application_identifier")
        self._setting_vars["project_description"] = tk.StringVar(value=s.project_description)
        self._entry_row(f, "Description", "project_description")
        self._setting_vars["startup_scene"] = tk.StringVar(value=s.startup_scene or "")
        self._entry_row(f, "Startup Scene", "startup_scene")
        self._setting_vars["show_welcome_screen"] = tk.BooleanVar(value=s.show_welcome_screen)
        ttk.Checkbutton(f, text="Show Welcome Screen", variable=self._setting_vars["show_welcome_screen"]).pack(anchor="w", pady=6)

    def _build_settings_display(self, parent):
        s = self.project.settings
        f = self._section(parent, "Display")
        self._setting_vars["width"] = tk.IntVar(value=s.default_screen_width)
        self._spin_row(f, "Resolution Width", "width", 320, 7680, 1)
        self._setting_vars["height"] = tk.IntVar(value=s.default_screen_height)
        self._spin_row(f, "Resolution Height", "height", 240, 4320, 1)
        self._setting_vars["fullscreen"] = tk.StringVar(value=s.fullscreen_mode)
        self._combo_row(f, "Fullscreen Mode", "fullscreen", ["Windowed", "Fullscreen", "Borderless"])
        self._setting_vars["window_resizable"] = tk.BooleanVar(value=s.window_resizable)
        ttk.Checkbutton(f, text="Resizable Window", variable=self._setting_vars["window_resizable"]).pack(anchor="w", pady=6)
        self._setting_vars["window_maximized"] = tk.BooleanVar(value=s.window_maximized)
        ttk.Checkbutton(f, text="Maximize On Launch", variable=self._setting_vars["window_maximized"]).pack(anchor="w", pady=6)
        self._setting_vars["color_space"] = tk.StringVar(value=s.color_space)
        self._combo_row(f, "Color Space", "color_space", ["Linear", "Gamma"])
        self._setting_vars["anti_aliasing"] = tk.IntVar(value=s.anti_aliasing)
        self._combo_row(f, "Anti-Aliasing", "anti_aliasing", [0, 2, 4, 8])
        self._setting_vars["quality_level"] = tk.StringVar(value=s.quality_level)
        self._combo_row(f, "Quality Level", "quality_level", ["Fastest", "Balanced", "Beautiful"])
        self._setting_vars["graphics_api"] = tk.StringVar(value=s.graphics_api)
        self._combo_row(f, "Graphics API", "graphics_api", ["WebGL2", "WebGL1"])
        self._setting_vars["vsync_count"] = tk.IntVar(value=s.vsync_count)
        self._spin_row(f, "VSync Count", "vsync_count", 0, 4, 1)
        self._setting_vars["target_framerate"] = tk.IntVar(value=s.target_framerate)
        self._spin_row(f, "Target Framerate", "target_framerate", 15, 240, 1)
        self._setting_vars["run_in_background"] = tk.BooleanVar(value=s.run_in_background)
        ttk.Checkbutton(f, text="Run In Background", variable=self._setting_vars["run_in_background"]).pack(anchor="w", pady=6)
        self._setting_vars["show_splash_screen"] = tk.BooleanVar(value=s.show_splash_screen)
        ttk.Checkbutton(f, text="Show Splash Screen", variable=self._setting_vars["show_splash_screen"]).pack(anchor="w", pady=6)
        self._setting_vars["splash_screen_duration"] = tk.DoubleVar(value=s.splash_screen_duration)
        self._spin_row(f, "Splash Duration", "splash_screen_duration", 0.0, 10.0, 0.1)

    def _build_settings_physics(self, parent):
        s = self.project.settings
        f = self._section(parent, "Physics")
        self._setting_vars["grav_x"] = tk.DoubleVar(value=s.gravity["x"])
        self._setting_vars["grav_y"] = tk.DoubleVar(value=s.gravity["y"])
        self._setting_vars["grav_z"] = tk.DoubleVar(value=s.gravity["z"])
        self._vector3_row(f, "Gravity", ("grav_x", "grav_y", "grav_z"))
        self._setting_vars["solver_iterations"] = tk.IntVar(value=s.default_solver_iterations)
        self._spin_row(f, "Solver Iterations", "solver_iterations", 1, 32, 1)
        self._setting_vars["fixed_timestep"] = tk.DoubleVar(value=s.fixed_timestep)
        self._spin_row(f, "Fixed Timestep", "fixed_timestep", 0.001, 0.1, 0.001)
        self._setting_vars["default_contact_offset"] = tk.DoubleVar(value=s.default_contact_offset)
        self._spin_row(f, "Contact Offset", "default_contact_offset", 0.001, 0.1, 0.001)

    def _build_settings_input(self, parent):
        s = self.project.settings
        f = self._section(parent, "Input")
        ttk.Label(f, text="Input Actions", style="Subtle.TLabel").pack(anchor="w", pady=(0, 6))
        self._setting_vars["input_actions"] = tk.StringVar(value=json.dumps(s.input_actions, indent=2))
        text = tk.Text(f, height=14, wrap=tk.NONE, bg=PALETTE["surface"], fg=PALETTE["text"], insertbackground=PALETTE["text"], relief="solid", bd=1)
        text.pack(fill=tk.BOTH, expand=True)
        text.insert("1.0", self._setting_vars["input_actions"].get())
        self._setting_vars["_input_text"] = text

    def _build_settings_audio(self, parent):
        s = self.project.settings
        f = self._section(parent, "Audio")
        self._setting_vars["global_volume"] = tk.DoubleVar(value=s.global_volume)
        self._spin_row(f, "Global Volume", "global_volume", 0.0, 1.0, 0.01)
        self._setting_vars["max_concurrent_sounds"] = tk.IntVar(value=s.max_concurrent_sounds)
        self._spin_row(f, "Max Concurrent Sounds", "max_concurrent_sounds", 1, 128, 1)
        self._setting_vars["default_sample_rate"] = tk.IntVar(value=s.default_sample_rate)
        self._spin_row(f, "Sample Rate", "default_sample_rate", 8000, 96000, 1000)
        self._setting_vars["reverb_enabled"] = tk.BooleanVar(value=s.reverb_enabled)
        ttk.Checkbutton(f, text="Enable Reverb", variable=self._setting_vars["reverb_enabled"]).pack(anchor="w", pady=6)

    def _build_settings_scripting(self, parent):
        s = self.project.settings
        f = self._section(parent, "Scripting")
        self._setting_vars["default_language"] = tk.StringVar(value=s.default_scripting_language)
        self._combo_row(f, "Default Language", "default_language", ["javascript", "csharp"])
        self._setting_vars["api_compatibility"] = tk.StringVar(value=s.api_compatibility)
        self._entry_row(f, "API Compatibility", "api_compatibility")
        self._setting_vars["allow_debugging"] = tk.BooleanVar(value=s.allow_debugging)
        ttk.Checkbutton(f, text="Allow Debugging", variable=self._setting_vars["allow_debugging"]).pack(anchor="w", pady=6)
        self._setting_vars["script_reload_on_save"] = tk.BooleanVar(value=s.script_reload_on_save)
        ttk.Checkbutton(f, text="Reload Scripts On Save", variable=self._setting_vars["script_reload_on_save"]).pack(anchor="w", pady=6)

    def _build_settings_editor(self, parent):
        s = self.project.settings
        f = self._section(parent, "Editor")
        self._setting_vars["editor_auto_save"] = tk.BooleanVar(value=s.editor_auto_save)
        ttk.Checkbutton(f, text="Auto Save", variable=self._setting_vars["editor_auto_save"]).pack(anchor="w", pady=6)
        self._setting_vars["editor_auto_save_interval"] = tk.IntVar(value=s.editor_auto_save_interval)
        self._spin_row(f, "Auto Save Interval (sec)", "editor_auto_save_interval", 10, 600, 5)
        self._setting_vars["editor_show_grid"] = tk.BooleanVar(value=s.editor_show_grid)
        ttk.Checkbutton(f, text="Show Grid by Default", variable=self._setting_vars["editor_show_grid"]).pack(anchor="w", pady=6)
        self._setting_vars["editor_show_gizmos"] = tk.BooleanVar(value=s.editor_show_gizmos)
        ttk.Checkbutton(f, text="Show Gizmos by Default", variable=self._setting_vars["editor_show_gizmos"]).pack(anchor="w", pady=6)
        self._setting_vars["editor_show_fps"] = tk.BooleanVar(value=s.editor_show_fps)
        ttk.Checkbutton(f, text="Show FPS Overlay", variable=self._setting_vars["editor_show_fps"]).pack(anchor="w", pady=6)
        self._setting_vars["editor_show_scene_info"] = tk.BooleanVar(value=s.editor_show_scene_info)
        ttk.Checkbutton(f, text="Show Scene Info", variable=self._setting_vars["editor_show_scene_info"]).pack(anchor="w", pady=6)
        self._setting_vars["scene_view_navigation_speed"] = tk.DoubleVar(value=s.scene_view_navigation_speed)
        self._spin_row(f, "Scene Nav Speed", "scene_view_navigation_speed", 0.1, 10.0, 0.1)
        self._setting_vars["viewport_zoom_sensitivity"] = tk.DoubleVar(value=s.viewport_zoom_sensitivity)
        self._spin_row(f, "Zoom Sensitivity", "viewport_zoom_sensitivity", 0.01, 1.0, 0.01)
        self._setting_vars["viewport_orbit_sensitivity"] = tk.DoubleVar(value=s.viewport_orbit_sensitivity)
        self._spin_row(f, "Orbit Sensitivity", "viewport_orbit_sensitivity", 0.01, 1.0, 0.01)
        self._setting_vars["grid_snap_enabled"] = tk.BooleanVar(value=s.grid_snap_enabled)
        ttk.Checkbutton(f, text="Snap To Grid", variable=self._setting_vars["grid_snap_enabled"]).pack(anchor="w", pady=6)
        self._setting_vars["grid_snap_increment"] = tk.DoubleVar(value=s.grid_snap_increment)
        self._spin_row(f, "Grid Snap Increment", "grid_snap_increment", 0.01, 100.0, 0.01)

    def _build_settings_rendering(self, parent):
        s = self.project.settings
        f = self._section(parent, "Rendering")
        self._setting_vars["render_scale"] = tk.DoubleVar(value=s.render_scale)
        self._spin_row(f, "Render Scale", "render_scale", 0.25, 2.0, 0.05)
        self._setting_vars["shadow_quality"] = tk.StringVar(value=s.shadow_quality)
        self._combo_row(f, "Shadow Quality", "shadow_quality", ["Low", "Medium", "High"])
        self._setting_vars["texture_filtering"] = tk.StringVar(value=s.texture_filtering)
        self._combo_row(f, "Texture Filtering", "texture_filtering", ["Point", "Bilinear", "Trilinear"])
        self._setting_vars["fog_enabled"] = tk.BooleanVar(value=s.fog_enabled)
        ttk.Checkbutton(f, text="Enable Fog", variable=self._setting_vars["fog_enabled"]).pack(anchor="w", pady=6)
        self._setting_vars["fog_density"] = tk.DoubleVar(value=s.fog_density)
        self._spin_row(f, "Fog Density", "fog_density", 0.0, 1.0, 0.01)

    def _build_settings_build(self, parent):
        s = self.project.settings
        f = self._section(parent, "Build")
        top = ttk.Frame(f)
        top.pack(fill=tk.X)

        self._setting_vars["output_type"] = tk.StringVar(value=s.build_output_type)
        self._combo_row(f, "Output Type", "output_type", ["single_html", "standard_web", "pwa"])
        self._setting_vars["compression"] = tk.IntVar(value=s.compression_level)
        self._spin_row(f, "Compression Level", "compression", 0, 9, 1)
        self._setting_vars["code_optimization"] = tk.StringVar(value=s.code_optimization)
        self._combo_row(f, "Optimization", "code_optimization", ["speed", "balanced", "size"])
        self._setting_vars["asset_bundle_splitting"] = tk.BooleanVar(value=s.asset_bundle_splitting)
        ttk.Checkbutton(f, text="Asset Bundle Splitting", variable=self._setting_vars["asset_bundle_splitting"]).pack(anchor="w", pady=6)
        self._setting_vars["include_debug_info"] = tk.BooleanVar(value=s.include_debug_info)
        ttk.Checkbutton(f, text="Include Debug Info", variable=self._setting_vars["include_debug_info"]).pack(anchor="w", pady=6)
        self._setting_vars["build_run_after_export"] = tk.BooleanVar(value=s.build_run_after_export)
        ttk.Checkbutton(f, text="Run After Export", variable=self._setting_vars["build_run_after_export"]).pack(anchor="w", pady=6)
        self._setting_vars["build_open_in_browser"] = tk.BooleanVar(value=s.build_open_in_browser)
        ttk.Checkbutton(f, text="Open In Browser", variable=self._setting_vars["build_open_in_browser"]).pack(anchor="w", pady=6)
        self._setting_vars["build_boot_timeout_seconds"] = tk.IntVar(value=s.build_boot_timeout_seconds)
        self._spin_row(f, "Boot Timeout (sec)", "build_boot_timeout_seconds", 5, 120, 1)
        self._setting_vars["build_start_scene_override"] = tk.StringVar(value=s.build_start_scene_override)
        self._entry_row(f, "Start Scene Override", "build_start_scene_override")

        scenes_box = ttk.Labelframe(parent, text="Build Scenes", padding=10)
    def _entry_row(self, parent, label, key):
        row = ttk.Frame(parent)
        row.pack(fill=tk.X, pady=4)
        ttk.Label(row, text=f"{label}:").pack(side=tk.LEFT, padx=(0, 8))
        ttk.Entry(row, textvariable=self._setting_vars[key]).pack(side=tk.LEFT, fill=tk.X, expand=True)

    def _combo_row(self, parent, label, key, values):
        row = ttk.Frame(parent)
        row.pack(fill=tk.X, pady=4)
        ttk.Label(row, text=f"{label}:").pack(side=tk.LEFT, padx=(0, 8))
        ttk.Combobox(row, textvariable=self._setting_vars[key], values=values, state="readonly").pack(side=tk.LEFT, fill=tk.X, expand=True)

    def _spin_row(self, parent, label, key, from_, to, increment):
        row = ttk.Frame(parent)
        row.pack(fill=tk.X, pady=4)
        ttk.Label(row, text=f"{label}:").pack(side=tk.LEFT, padx=(0, 8))
        ttk.Spinbox(row, from_=from_, to=to, increment=increment, textvariable=self._setting_vars[key], width=12).pack(side=tk.LEFT)

    def _vector3_row(self, parent, label, keys):
        row = ttk.Frame(parent)
        row.pack(fill=tk.X, pady=4)
        ttk.Label(row, text=f"{label}:").pack(side=tk.LEFT, padx=(0, 8))
        for axis, key in zip(("X", "Y", "Z"), keys):
            ttk.Label(row, text=axis).pack(side=tk.LEFT, padx=(0, 4))
            ttk.Spinbox(row, from_=-9999, to=9999, increment=0.1, textvariable=self._setting_vars[key], width=10).pack(side=tk.LEFT, padx=(0, 8))

    def _save_settings(self, dialog):
        s = self.project.settings
        s.company_name = self._setting_vars["company_name"].get()
        s.product_name = self._setting_vars["product_name"].get()
        s.version = self._setting_vars["version"].get()
        s.project_type = self._setting_vars["project_type"].get()
        s.application_identifier = self._setting_vars["application_identifier"].get()
        s.project_description = self._setting_vars.get("project_description", tk.StringVar(value=s.project_description)).get()
        s.startup_scene = self._setting_vars["startup_scene"].get()
        s.show_welcome_screen = self._setting_vars.get("show_welcome_screen", tk.BooleanVar(value=s.show_welcome_screen)).get()

        s.default_screen_width = self._setting_vars["width"].get()
        s.default_screen_height = self._setting_vars["height"].get()
        s.fullscreen_mode = self._setting_vars["fullscreen"].get()
        s.window_resizable = self._setting_vars.get("window_resizable", tk.BooleanVar(value=s.window_resizable)).get()
        s.window_maximized = self._setting_vars.get("window_maximized", tk.BooleanVar(value=s.window_maximized)).get()
        s.color_space = self._setting_vars["color_space"].get()
        s.anti_aliasing = self._setting_vars["anti_aliasing"].get()
        s.quality_level = self._setting_vars["quality_level"].get()
        s.graphics_api = self._setting_vars["graphics_api"].get()
        s.render_scale = self._setting_vars.get("render_scale", tk.DoubleVar(value=s.render_scale)).get()
        s.shadow_quality = self._setting_vars.get("shadow_quality", tk.StringVar(value=s.shadow_quality)).get()
        s.texture_filtering = self._setting_vars.get("texture_filtering", tk.StringVar(value=s.texture_filtering)).get()
        s.fog_enabled = self._setting_vars.get("fog_enabled", tk.BooleanVar(value=s.fog_enabled)).get()
        s.fog_density = self._setting_vars.get("fog_density", tk.DoubleVar(value=s.fog_density)).get()
        s.vsync_count = self._setting_vars["vsync_count"].get()
        s.target_framerate = self._setting_vars["target_framerate"].get()
        s.run_in_background = self._setting_vars["run_in_background"].get()
        s.show_splash_screen = self._setting_vars["show_splash_screen"].get()
        s.splash_screen_style = self._setting_vars.get("splash_screen_style", tk.StringVar(value=s.splash_screen_style)).get()
        s.splash_screen_duration = self._setting_vars.get("splash_screen_duration", tk.DoubleVar(value=s.splash_screen_duration)).get()

        s.gravity = {
            "x": self._setting_vars["grav_x"].get(),
            "y": self._setting_vars["grav_y"].get(),
            "z": self._setting_vars["grav_z"].get(),
        }
        s.default_solver_iterations = self._setting_vars["solver_iterations"].get()
        s.fixed_timestep = self._setting_vars["fixed_timestep"].get()
        s.default_contact_offset = self._setting_vars["default_contact_offset"].get()

        input_text = self._setting_vars.get("_input_text")
        if input_text:
            try:
                s.input_actions = json.loads(input_text.get("1.0", "end").strip() or "{}")
            except Exception as exc:
                messagebox.showerror("Settings", f"Invalid input action JSON: {exc}", parent=dialog)
                return

        s.global_volume = self._setting_vars["global_volume"].get()
        s.max_concurrent_sounds = self._setting_vars["max_concurrent_sounds"].get()
        s.default_sample_rate = self._setting_vars["default_sample_rate"].get()
        s.reverb_enabled = self._setting_vars["reverb_enabled"].get()

        s.default_scripting_language = self._setting_vars["default_language"].get()
        s.api_compatibility = self._setting_vars["api_compatibility"].get()
        s.allow_debugging = self._setting_vars["allow_debugging"].get()
        s.script_reload_on_save = self._setting_vars["script_reload_on_save"].get()
        s.hot_reload_scripts = self._setting_vars.get("hot_reload_scripts", tk.BooleanVar(value=s.hot_reload_scripts)).get()

        s.editor_auto_save = self._setting_vars.get("editor_auto_save", tk.BooleanVar(value=s.editor_auto_save)).get()
        s.editor_auto_save_interval = self._setting_vars.get("editor_auto_save_interval", tk.IntVar(value=s.editor_auto_save_interval)).get()
        s.editor_show_grid = self._setting_vars.get("editor_show_grid", tk.BooleanVar(value=s.editor_show_grid)).get()
        s.editor_show_gizmos = self._setting_vars.get("editor_show_gizmos", tk.BooleanVar(value=s.editor_show_gizmos)).get()
        s.editor_show_fps = self._setting_vars.get("editor_show_fps", tk.BooleanVar(value=s.editor_show_fps)).get()
        s.editor_show_scene_info = self._setting_vars.get("editor_show_scene_info", tk.BooleanVar(value=s.editor_show_scene_info)).get()
        s.scene_view_navigation_speed = self._setting_vars.get("scene_view_navigation_speed", tk.DoubleVar(value=s.scene_view_navigation_speed)).get()
        s.viewport_zoom_sensitivity = self._setting_vars.get("viewport_zoom_sensitivity", tk.DoubleVar(value=s.viewport_zoom_sensitivity)).get()
        s.viewport_orbit_sensitivity = self._setting_vars.get("viewport_orbit_sensitivity", tk.DoubleVar(value=s.viewport_orbit_sensitivity)).get()
        s.grid_snap_enabled = self._setting_vars.get("grid_snap_enabled", tk.BooleanVar(value=s.grid_snap_enabled)).get()
        s.grid_snap_increment = self._setting_vars.get("grid_snap_increment", tk.DoubleVar(value=s.grid_snap_increment)).get()

        s.build_output_type = self._setting_vars["output_type"].get()
        s.compression_level = self._setting_vars["compression"].get()
        s.code_optimization = self._setting_vars["code_optimization"].get()
        s.asset_bundle_splitting = self._setting_vars["asset_bundle_splitting"].get()
        s.include_debug_info = self._setting_vars["include_debug_info"].get()
        s.build_run_after_export = self._setting_vars.get("build_run_after_export", tk.BooleanVar(value=s.build_run_after_export)).get()
        s.build_open_in_browser = self._setting_vars.get("build_open_in_browser", tk.BooleanVar(value=s.build_open_in_browser)).get()
        s.build_boot_timeout_seconds = self._setting_vars.get("build_boot_timeout_seconds", tk.IntVar(value=s.build_boot_timeout_seconds)).get()
        s.build_start_scene_override = self._setting_vars.get("build_start_scene_override", tk.StringVar(value=s.build_start_scene_override)).get()
        self.project.sync_build_scenes()
        self.project.save()
        self._update_ui_for_project()
        self._update_title()
        dialog.destroy()
        self.console.log("Settings saved", "info")

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------

    def mark_modified(self, value: bool = True):
        self.is_modified = value
        self._update_title()

    def open_script(self, filename):
        if not self.project:
            return
        path = self.project.path / "Assets" / filename
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
            self.script_editor.open_file(str(path), content)

    def focus_console(self):
        pass

    def focus_project_browser(self):
        pass

    def undo(self):
        self.console.log("Undo not yet implemented", "warning")

    def redo(self):
        self.console.log("Redo not yet implemented", "warning")

    def show_docs(self):
        messagebox.showinfo("Documentation", "Documentation available at:\nhttps://tantans-creations.com/docs")

    def show_about(self):
        messagebox.showinfo(
            "About",
            "Tantan's Creations Web Engine v1.0\nA pastel-themed 2D/3D game engine for the web\n© 2026 Tantan's Creations",
        )

    def on_exit(self):
        if self.is_modified:
            result = messagebox.askyesnocancel("Unsaved Changes", "Save changes before exiting?")
            if result is True:
                self.save_project()
            elif result is None:
                return
        self.root.destroy()

    def run(self):
        self.root.mainloop()
