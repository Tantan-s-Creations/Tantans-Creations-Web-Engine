"""HTML5 exporter for Tantan's Creations Web Engine.
Generates functional HTML files with an embedded, dependency-free runtime.
"""
from __future__ import annotations

import base64
import json
from pathlib import Path
from typing import Dict

from ..core.ecs import Scene, Entity, Transform, MeshFilter, MeshRenderer, SpriteRenderer, Camera, Light, Script
from ..core.assets import TextureAsset
from .csharp_transpiler import transpile_csharp_to_js


class HTMLExporter:
    """Exports scenes to functional HTML5 games."""

    def __init__(self, project_path: str):
        self.project_path = Path(project_path)
        self.assets_path = self.project_path / "Assets"
        self.build_path = self.project_path / "Build"
        self.settings = None
        self.asset_db = None

    def export(self, scene: Scene, output_name="game", output_type="single_html") -> str:
        """Export scene to HTML. Returns output file path."""
        self.build_path.mkdir(parents=True, exist_ok=True)

        scene_data = self._export_scene_data(scene)
        script_sources = self._export_scripts(scene)
        asset_data = self._export_assets(scene)

        if output_type == "single_html":
            output_path = self._build_single_html(scene_data, script_sources, asset_data, output_name)
        else:
            output_path = self._build_standard_web(scene_data, script_sources, asset_data, output_name)

        return str(output_path)

    def _export_scene_data(self, scene: Scene) -> dict:
        entities_data = []
        for entity in scene.root_entities:
            entities_data.append(self._export_entity(entity))
        return {"name": scene.name, "settings": scene.settings, "entities": entities_data}

    def _export_entity(self, entity: Entity) -> dict:
        transform = entity.get_component(Transform)
        entity_data = {
            "id": entity.id,
            "name": entity.name,
            "active": entity.active,
            "transform": {
                "position": transform.position.to_dict() if transform else {"x": 0, "y": 0, "z": 0},
                "rotation": transform.rotation.to_dict() if transform else {"x": 0, "y": 0, "z": 0},
                "scale": transform.scale.to_dict() if transform else {"x": 1, "y": 1, "z": 1},
            },
            "components": [],
            "children": [self._export_entity(child) for child in entity.children],
        }

        for comp in entity.components:
            comp_data = comp.to_dict()
            if isinstance(comp, MeshFilter) and self.asset_db and comp.mesh_asset_id:
                mesh_asset = self.asset_db.get_asset_by_id(comp.mesh_asset_id)
                if mesh_asset and hasattr(mesh_asset, "mesh_data") and mesh_asset.mesh_data:
                    comp_data["mesh_data"] = mesh_asset.mesh_data
            elif isinstance(comp, SpriteRenderer) and self.asset_db and comp.texture_asset_id:
                tex_asset = self.asset_db.get_asset_by_id(comp.texture_asset_id)
                if tex_asset:
                    comp_data["texture_base64"] = self._texture_to_base64(tex_asset)
            elif isinstance(comp, Camera):
                comp_data["is_main"] = True
            entity_data["components"].append(comp_data)

        return entity_data

    def _texture_to_base64(self, tex_asset) -> str:
        try:
            abs_path = self.assets_path / tex_asset.path
            if abs_path.exists():
                data = abs_path.read_bytes()
                ext = abs_path.suffix.lower()
                mime = "image/png" if ext == ".png" else "image/jpeg" if ext in [".jpg", ".jpeg"] else "image/png"
                return f"data:{mime};base64," + base64.b64encode(data).decode()
        except Exception:
            pass
        return ""

    def _export_scripts(self, scene: Scene):
        script_sources = []
        for entity in scene.entities.values():
            script_comp = entity.get_component(Script)
            if not script_comp:
                continue

            code = ""
            if script_comp.source_code:
                code = script_comp.source_code
            elif script_comp.source_file:
                path = self.assets_path / script_comp.source_file
                if path.exists():
                    code = path.read_text(encoding="utf-8")

            if not code:
                continue

            if script_comp.language == "csharp":
                code = transpile_csharp_to_js(code)

            script_sources.append({
                "entity": entity.name,
                "language": script_comp.language,
                "code": code,
                "properties": script_comp.properties or {},
            })

        return script_sources

    def _export_assets(self, scene: Scene) -> dict:
        return {}

    def _build_single_html(self, scene_data: dict, script_sources, asset_data: dict, name: str) -> Path:
        output_path = self.build_path / f"{name}.html"
        script_sources_json = json.dumps(script_sources, indent=2)
        scene_json = json.dumps(scene_data, indent=2)
        settings_json = json.dumps(getattr(self.settings, "to_dict", lambda: {})(), indent=2) if self.settings else "{}"
        boot_timeout = getattr(self.settings, "build_boot_timeout_seconds", 15) if self.settings else 15
        width = getattr(self.settings, "default_screen_width", 1280) if self.settings else 1280
        height = getattr(self.settings, "default_screen_height", 720) if self.settings else 720
        splash_style = getattr(self.settings, "splash_screen_style", "Minimal") if self.settings else "Minimal"
        splash_duration = getattr(self.settings, "splash_screen_duration", 1.8) if self.settings else 1.8

        html = f"""<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <title>{scene_data['name']} - Tantan's Creations</title>
    <style>
        :root {{
            --bg: #231c3d;
            --panel: rgba(255,255,255,0.12);
            --panel-strong: rgba(255,255,255,0.18);
            --text: #f7f5ff;
            --muted: #d6d0f2;
            --blue: #4c78e8;
            --purple: #8459e8;
            --pastel-blue: #e6f0ff;
            --pastel-purple: #f0e7ff;
        }}
        * {{ box-sizing: border-box; }}
        html, body {{ width: 100%; height: 100%; margin: 0; overflow: hidden; background: radial-gradient(circle at top left, #4a3675 0%, var(--bg) 60%, #160f2d 100%); color: var(--text); font-family: "Bungee", "Trebuchet MS", sans-serif; }}
        #game-container {{ position: relative; width: 100vw; height: 100vh; overflow: hidden; }}
        canvas {{ display: block; width: 100%; height: 100%; }}
        #loading {{ position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; flex-direction: column; gap: 12px; background: linear-gradient(180deg, rgba(48,34,82,0.92), rgba(23,16,43,0.96)); z-index: 100; transition: opacity .35s ease, transform .35s ease; }}
        #loading.hidden {{ opacity: 0; pointer-events: none; transform: scale(1.01); }}
        .loading-card {{ width: min(560px, calc(100vw - 48px)); padding: 28px; border-radius: 28px; background: linear-gradient(180deg, rgba(255,255,255,0.15), rgba(255,255,255,0.07)); border: 1px solid rgba(255,255,255,0.14); box-shadow: 0 24px 80px rgba(0,0,0,0.28); text-align: center; }}
        .brand {{ font-size: 28px; letter-spacing: 1px; margin-bottom: 8px; color: var(--pastel-purple); }}
        .sub {{ color: var(--muted); font-size: 14px; line-height: 1.5; }}
        .bar {{ margin-top: 18px; height: 12px; border-radius: 999px; background: rgba(255,255,255,0.12); overflow: hidden; }}
        .bar > div {{ width: 42%; height: 100%; border-radius: inherit; background: linear-gradient(90deg, var(--purple), var(--blue), var(--pastel-purple)); animation: slide 1.15s ease-in-out infinite alternate; }}
        @keyframes slide {{ from {{ transform: translateX(-14%); }} to {{ transform: translateX(142%); }} }}
        #stats {{ position: absolute; left: 16px; top: 16px; z-index: 20; padding: 8px 12px; border-radius: 999px; background: rgba(255,255,255,0.12); border: 1px solid rgba(255,255,255,0.15); color: var(--text); font-size: 12px; backdrop-filter: blur(10px); }}
        #boot-error {{ position: absolute; left: 16px; right: 16px; bottom: 16px; padding: 14px 16px; border-radius: 16px; background: rgba(255,255,255,0.95); color: #2C2742; border: 1px solid rgba(142,107,232,0.24); font-family: Segoe UI, sans-serif; display: none; z-index: 120; }}
    </style>
</head>
<body>
    <div id="game-container">
        <canvas id="canvas"></canvas>
        <div id="stats">Booting...</div>
        <div id="loading">
            <div class="loading-card">
                <div class="brand">TANTAN'S CREATIONS WEB ENGINE</div>
                <div class="sub">Loading project, compiling scripts, and preparing the scene.</div>
                <div class="bar"><div></div></div>
            </div>
        </div>
    </div>
    <script>
    const SCENE_DATA = {scene_json};
    const SCRIPT_SOURCES = {script_sources_json};
    const PROJECT_SETTINGS = {settings_json};

    const canvas = document.getElementById('canvas');
    const ctx = canvas.getContext('2d');
    const loadingEl = document.getElementById('loading');
    const statsEl = document.getElementById('stats');
    const errorEl = document.createElement('div');
    errorEl.id = 'boot-error';
    errorEl.innerHTML = '<strong>Engine boot failed.</strong><div id="boot-error-text" style="margin-top:6px;white-space:pre-wrap;font-size:13px;line-height:1.35;"></div>';
    document.getElementById('game-container').appendChild(errorEl);

    function resizeCanvas() {{
        const dpr = Math.max(1, window.devicePixelRatio || 1);
        canvas.width = Math.floor(window.innerWidth * dpr);
        canvas.height = Math.floor(window.innerHeight * dpr);
        canvas.style.width = '100%';
        canvas.style.height = '100%';
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }}

    class Vector3 {{
        constructor(x=0, y=0, z=0) {{ this.x = x; this.y = y; this.z = z; }}
        add(v) {{ return new Vector3(this.x + v.x, this.y + v.y, this.z + v.z); }}
        subtract(v) {{ return new Vector3(this.x - v.x, this.y - v.y, this.z - v.z); }}
        multiply(v) {{ return v instanceof Vector3 ? new Vector3(this.x * v.x, this.y * v.y, this.z * v.z) : new Vector3(this.x * v, this.y * v, this.z * v); }}
        normalized() {{ const m = Math.hypot(this.x, this.y, this.z) || 1; return new Vector3(this.x / m, this.y / m, this.z / m); }}
    }}

    const TEngine = {{
        canvas, ctx,
        scene: null,
        entities: new Map(),
        scripts: [],
        time: 0,
        deltaTime: 0,
        fixedDeltaTime: 0.016,
        input: {{
            keys: new Set(),
            mouseDown: false,
            mousePosition: new Vector3(0, 0, 0),
            getKey(key) {{ return this.keys.has(String(key).toLowerCase()); }},
            getButton(name) {{ return this.getKey(name); }},
            getMouseButton(button) {{ return button === 0 ? this.mouseDown : false; }},
            getAxis(name) {{
                name = String(name).toLowerCase();
                const mapping = {{
                    horizontal: [['a', -1], ['arrowleft', -1], ['d', 1], ['arrowright', 1]],
                    vertical: [['s', -1], ['arrowdown', -1], ['w', 1], ['arrowup', 1]],
                }};
                let value = 0;
                for (const [key, amount] of (mapping[name] || [])) {{ if (this.getKey(key)) value += amount; }}
                return Math.max(-1, Math.min(1, value));
            }}
        }},
        mathf: {{ clamp: (v, mn, mx) => Math.min(mx, Math.max(mn, v)), lerp: (a,b,t) => a + (b-a) * t }},
        Vector3,
        findObject(name) {{ for (const ent of this.entities.values()) if (ent.name === name) return ent; return null; }},
        destroy(obj) {{ if (obj && obj.id) this.entities.delete(obj.id); }},
        application: {{ quit() {{ /* browser controlled */ }} }},
    }};

    function makeTransform(data) {{
        const pos = new Vector3(data?.position?.x || 0, data?.position?.y || 0, data?.position?.z || 0);
        const rot = new Vector3(data?.rotation?.x || 0, data?.rotation?.y || 0, data?.rotation?.z || 0);
        const scale = new Vector3(data?.scale?.x || 1, data?.scale?.y || 1, data?.scale?.z || 1);
        return {{
            position: pos,
            rotation: rot,
            scale,
            translate(x=0, y=0, z=0) {{
                if (x instanceof Vector3) this.position = this.position.add(x);
                else this.position = this.position.add(new Vector3(x, y, z));
                return this;
            }},
            rotate(x=0, y=0, z=0) {{
                if (x instanceof Vector3) this.rotation = this.rotation.add(x);
                else this.rotation = this.rotation.add(new Vector3(x, y, z));
                return this;
            }},
            get forward() {{
                const yaw = this.rotation.y * Math.PI / 180;
                const pitch = this.rotation.x * Math.PI / 180;
                return new Vector3(Math.cos(pitch) * Math.sin(yaw), -Math.sin(pitch), Math.cos(pitch) * Math.cos(yaw)).normalized();
            }},
            get right() {{
                const yaw = (this.rotation.y + 90) * Math.PI / 180;
                return new Vector3(Math.sin(yaw), 0, Math.cos(yaw)).normalized();
            }},
            get up() {{ return new Vector3(0, 1, 0); }},
            lookAt(target) {{
                const t = target instanceof Vector3 ? target : new Vector3(target?.x || 0, target?.y || 0, target?.z || 0);
                const dir = t.subtract(this.position).normalized();
                this.rotation.y = Math.atan2(dir.x, dir.z) * 180 / Math.PI;
                this.rotation.x = Math.atan2(-dir.y, Math.hypot(dir.x, dir.z)) * 180 / Math.PI;
                return this;
            }}
        }};
    }}

    function createEntity(entityData, parent=null) {{
        const entity = {{
            id: entityData.id,
            name: entityData.name,
            active: entityData.active !== false,
            transform: makeTransform(entityData.transform),
            components: entityData.components || [],
            children: [],
            parent,
            getComponent(type) {{
                return this.components.find(c => c.type === type || c.type?.toLowerCase() === String(type).toLowerCase()) || null;
            }}
        }};
        TEngine.entities.set(entity.id, entity);
        for (const child of (entityData.children || [])) {{
            entity.children.push(createEntity(child, entity));
        }}
        return entity;
    }}

    function getMainCamera() {{
        for (const entity of TEngine.entities.values()) {{
            if ((entity.components || []).some(c => c.type === 'Camera')) return entity;
        }}
        return null;
    }}

    function project(pos, camera, w, h) {{
        const cam = camera ? camera.transform.position : new Vector3(0, 0, 0);
        const sx = (pos.x - cam.x - (pos.z - cam.z)) * 46 + w / 2;
        const sy = (pos.x - cam.x + pos.z - cam.z) * 22 - (pos.y - cam.y) * 48 + h / 2;
        return [sx, sy];
    }}

    function drawGrid(camera) {{
        const w = canvas.clientWidth, h = canvas.clientHeight;
        ctx.save();
        ctx.globalAlpha = 0.18;
        ctx.strokeStyle = '#cfc3ee';
        ctx.lineWidth = 1;
        for (let x = -10; x <= 10; x++) {{
            ctx.beginPath();
            ctx.moveTo(w / 2 + x * 46, 0);
            ctx.lineTo(w / 2 + x * 46, h);
            ctx.stroke();
        }}
        for (let y = -10; y <= 10; y++) {{
            ctx.beginPath();
            ctx.moveTo(0, h / 2 + y * 46);
            ctx.lineTo(w, h / 2 + y * 46);
            ctx.stroke();
        }}
        ctx.restore();
    }}

    function drawEntity(entity, camera) {{
        if (!entity.active) return;
        const w = canvas.clientWidth, h = canvas.clientHeight;
        const [x, y] = project(entity.transform.position, camera, w, h);
        const sprite = entity.components.find(c => c.type === 'SpriteRenderer');
        const mesh = entity.components.find(c => c.type === 'MeshRenderer' || c.type === 'MeshFilter');
        const light = entity.components.find(c => c.type === 'Light');
        const selected = entity.name === (TEngine.selectedName || '');
        if (sprite) {{
            const col = sprite.color || {{ r: 1, g: 1, b: 1, a: 1 }};
            const alpha = col.a !== undefined ? col.a : 1;
            ctx.save();
            ctx.fillStyle = `rgba(${{Math.round(col.r * 255)}}, ${{Math.round(col.g * 255)}}, ${{Math.round(col.b * 255)}}, ${{alpha}})`;
            ctx.strokeStyle = selected ? '#4c78e8' : 'rgba(255,255,255,0.4)';
            ctx.lineWidth = selected ? 3 : 1;
            ctx.beginPath();
            ctx.roundRect(x - 20, y - 20, 40, 40, 10);
            ctx.fill();
            ctx.stroke();
            ctx.restore();
        }} else if (mesh) {{
            ctx.save();
            const s = entity.transform.scale;
            ctx.fillStyle = selected ? '#f0e7ff' : '#b79bff';
            ctx.strokeStyle = selected ? '#4c78e8' : 'rgba(255,255,255,0.25)';
            ctx.lineWidth = selected ? 3 : 1;
            ctx.beginPath();
            ctx.moveTo(x, y - 24 * s.y);
            ctx.lineTo(x + 24 * s.x, y - 12 * s.y);
            ctx.lineTo(x + 24 * s.x, y + 12 * s.y);
            ctx.lineTo(x, y + 24 * s.y);
            ctx.lineTo(x - 24 * s.x, y + 12 * s.y);
            ctx.lineTo(x - 24 * s.x, y - 12 * s.y);
            ctx.closePath();
            ctx.fill();
            ctx.stroke();
            ctx.restore();
        }} else if (light) {{
            ctx.save();
            ctx.fillStyle = '#ffd97a';
            ctx.beginPath();
            ctx.arc(x, y, 8, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
        }} else {{
            ctx.save();
            ctx.fillStyle = selected ? '#4c78e8' : '#ffffff';
            ctx.beginPath();
            ctx.arc(x, y, 6, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
        }}
        ctx.save();
        ctx.fillStyle = '#f7f5ff';
        ctx.font = '12px Segoe UI, sans-serif';
        ctx.fillText(entity.name, x + 10, y - 10);
        ctx.restore();
    }}

    function renderScene() {{
        const w = canvas.clientWidth, h = canvas.clientHeight;
        ctx.clearRect(0, 0, w, h);
        ctx.fillStyle = '#231c3d';
        ctx.fillRect(0, 0, w, h);
        const camera = getMainCamera();
        if ({str(True).lower()}) drawGrid(camera);
        const entities = Array.from(TEngine.entities.values()).sort((a, b) => (a.transform.position.z + a.transform.position.y) - (b.transform.position.z + b.transform.position.y));
        for (const entity of entities) drawEntity(entity, camera);
    }}

    function compileScripts() {{
        TEngine.scripts.length = 0;
        for (const scriptDef of SCRIPT_SOURCES) {{
            try {{
                const entity = Array.from(TEngine.entities.values()).find(e => e.name === scriptDef.entity) || null;
                if (!entity) continue;
                const api = {{
                    entity,
                    transform: entity.transform,
                    properties: scriptDef.properties || {{}},
                    Vector3,
                    print: (...args) => console.log(`[${{scriptDef.entity}}]`, ...args),
                    findObject: (name) => TEngine.findObject(name),
                    destroy: (obj) => TEngine.destroy(obj)
                }};
                const source = String(scriptDef.code || '');
                const factory = new Function('api', 'TEngine', 'Vector3', 'source', `
                    const {{ entity, transform, properties, print, findObject, destroy }} = api;
                    let Start = null;
                    let Update = null;
                    let FixedUpdate = null;
                    eval(source);
                    return {{
                        Start: typeof Start === 'function' ? Start : null,
                        Update: typeof Update === 'function' ? Update : null,
                        FixedUpdate: typeof FixedUpdate === 'function' ? FixedUpdate : null
                    }};
                `);
                const instance = factory(api, TEngine, Vector3, source);
                if (instance.Start || instance.Update || instance.FixedUpdate) {{
                    TEngine.scripts.push({{ api, ...instance, started: false, name: scriptDef.entity }});
                }}
            }} catch (err) {{
                console.warn(`Script failed for ${{scriptDef.entity}}:`, err);
            }}
        }}
    }}

    function bootError(message) {{
        const text = document.getElementById('boot-error-text');
        if (text) text.textContent = String(message || 'Unknown error');
        errorEl.style.display = 'block';
        loadingEl.classList.add('hidden');
        statsEl.textContent = 'Boot failed';
    }}

    function boot() {{
        try {{
            resizeCanvas();
            TEngine.scene = SCENE_DATA;
            for (const root of SCENE_DATA.entities) createEntity(root, null);
            compileScripts();
            for (const script of TEngine.scripts) {{
                try {{ if (script.Start) script.Start.call(script.api); script.started = true; }} catch (err) {{ console.warn(`Start() error on ${{script.name}}:`, err); }}
            }}
            loadingEl.classList.add('hidden');
            statsEl.textContent = 'Ready';
            animate();
        }} catch (err) {{
            bootError(err?.stack || err?.message || String(err));
        }}
    }}

    function animate() {{
        requestAnimationFrame(animate);
        const now = performance.now();
        const dt = Math.min(0.05, (now - (TEngine._lastTime || now)) / 1000);
        TEngine._lastTime = now;
        TEngine.deltaTime = dt;
        TEngine.time += dt;

        for (const script of TEngine.scripts) {{
            try {{ if (script.Update) script.Update.call(script.api); }} catch (err) {{ console.warn(`Update() error on ${{script.name}}:`, err); }}
        }}

        renderScene();
        TEngine.frameCount = (TEngine.frameCount || 0) + 1;
        if (!TEngine._fpsStart) TEngine._fpsStart = now;
        if (now - TEngine._fpsStart >= 1000) {{
            const fps = Math.round(TEngine.frameCount * 1000 / (now - TEngine._fpsStart));
            statsEl.textContent = `FPS: ${{fps}} | Entities: ${{TEngine.entities.size}}`;
            TEngine.frameCount = 0;
            TEngine._fpsStart = now;
        }}
    }}

    window.addEventListener('resize', resizeCanvas);
    window.addEventListener('error', (event) => {{ bootError(event.error?.stack || event.message || 'Unexpected error during boot.'); }});
    window.addEventListener('unhandledrejection', (event) => {{ bootError(event.reason?.stack || event.reason || 'Unhandled promise rejection during boot.'); }});
    window.addEventListener('keydown', (e) => TEngine.input.keys.add(e.key.toLowerCase()));
    window.addEventListener('keyup', (e) => TEngine.input.keys.delete(e.key.toLowerCase()));
    window.addEventListener('mousemove', (e) => {{ TEngine.input.mousePosition.x = e.clientX; TEngine.input.mousePosition.y = e.clientY; }});
    window.addEventListener('mousedown', () => TEngine.input.mouseDown = true);
    window.addEventListener('mouseup', () => TEngine.input.mouseDown = false);

    const loadWatchdog = setTimeout(() => {{ if (!TEngine._booted) bootError('Boot timed out.'); }}, Math.max(5, {int(boot_timeout)}) * 1000);
    setTimeout(() => {{ TEngine._booted = true; clearTimeout(loadWatchdog); boot(); }}, 16);
    </script>
</body>
</html>"""

        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)

        return output_path

    def _build_standard_web(self, scene_data: dict, script_sources, asset_data: dict, name: str) -> Path:
        """Build standard web output (HTML + JS + Data files)."""
        return self._build_single_html(scene_data, script_sources, asset_data, name)
