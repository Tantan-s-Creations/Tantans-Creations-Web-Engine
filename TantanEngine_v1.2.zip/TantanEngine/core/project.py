"""Project management and settings."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Any, List, Optional

from .theme import PALETTE


class ProjectSettings:
    """Unity-style project settings with scene build management."""

    def __init__(self):
        # General / player
        self.company_name = "Tantan's Creations"
        self.product_name = "New Game"
        self.version = "1.0.0"
        self.project_type = "3D"  # 2D, 3D, Hybrid
        self.application_identifier = "com.tantanscreations.newgame"
        self.project_description = ""
        self.startup_scene = ""
        self.show_welcome_screen = True

        # Window / display
        self.default_screen_width = 1280
        self.default_screen_height = 720
        self.fullscreen_mode = "Windowed"  # Windowed, Fullscreen, Borderless
        self.window_resizable = True
        self.window_maximized = False
        self.vsync_count = 1
        self.target_framerate = 60
        self.run_in_background = True
        self.show_splash_screen = True
        self.splash_screen_style = "Minimal"  # Minimal, Fullscreen, Logo
        self.splash_screen_duration = 1.8

        # Rendering / display pipeline
        self.color_space = "Linear"  # Linear or Gamma
        self.anti_aliasing = 2  # 0, 2, 4, 8
        self.anisotropic_filtering = True
        self.quality_level = "Balanced"  # Fastest, Balanced, Beautiful
        self.graphics_api = "WebGL2"
        self.render_scale = 1.0
        self.shadow_quality = "Medium"  # Low, Medium, High
        self.texture_filtering = "Bilinear"  # Point, Bilinear, Trilinear
        self.fog_enabled = False
        self.fog_density = 0.02

        # Physics
        self.gravity = {"x": 0, "y": -9.81, "z": 0}
        self.default_solver_iterations = 6
        self.fixed_timestep = 0.02
        self.default_contact_offset = 0.01

        # Input
        self.input_actions = {
            "Horizontal": {"type": "Axis", "negative": "a", "positive": "d", "alt_negative": "left", "alt_positive": "right"},
            "Vertical": {"type": "Axis", "negative": "s", "positive": "w", "alt_negative": "down", "alt_positive": "up"},
            "Jump": {"type": "Button", "key": "space"},
            "Fire": {"type": "Button", "key": "mouse0"},
            "Interact": {"type": "Button", "key": "e"},
        }

        # Audio
        self.global_volume = 1.0
        self.max_concurrent_sounds = 32
        self.default_sample_rate = 44100
        self.reverb_enabled = False

        # Scripting
        self.default_scripting_language = "javascript"
        self.api_compatibility = "WebEngine 1.0"
        self.allow_debugging = True
        self.script_reload_on_save = True
        self.hot_reload_scripts = True

        # Editor
        self.editor_auto_save = True
        self.editor_auto_save_interval = 60
        self.editor_show_grid = True
        self.editor_show_gizmos = True
        self.editor_show_fps = True
        self.editor_show_scene_info = True
        self.scene_view_navigation_speed = 1.0
        self.viewport_zoom_sensitivity = 0.1
        self.viewport_orbit_sensitivity = 0.3
        self.grid_snap_enabled = False
        self.grid_snap_increment = 0.5

        # Build
        self.build_output_type = "single_html"  # single_html, standard_web, pwa
        self.compression_level = 6
        self.code_optimization = "balanced"  # speed, size, balanced
        self.asset_bundle_splitting = False
        self.include_debug_info = False
        self.build_run_after_export = False
        self.build_open_in_browser = True
        self.build_boot_timeout_seconds = 15
        self.build_start_scene_override = ""
        self.build_scenes: List[Dict[str, Any]] = []  # [{path, enabled, is_start}]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "company_name": self.company_name,
            "product_name": self.product_name,
            "version": self.version,
            "project_type": self.project_type,
            "application_identifier": self.application_identifier,
            "project_description": self.project_description,
            "startup_scene": self.startup_scene,
            "show_welcome_screen": self.show_welcome_screen,
            "display": {
                "width": self.default_screen_width,
                "height": self.default_screen_height,
                "fullscreen_mode": self.fullscreen_mode,
                "window_resizable": self.window_resizable,
                "window_maximized": self.window_maximized,
                "vsync_count": self.vsync_count,
                "target_framerate": self.target_framerate,
                "run_in_background": self.run_in_background,
                "show_splash_screen": self.show_splash_screen,
                "splash_screen_style": self.splash_screen_style,
                "splash_screen_duration": self.splash_screen_duration,
                "color_space": self.color_space,
                "anti_aliasing": self.anti_aliasing,
                "anisotropic_filtering": self.anisotropic_filtering,
                "quality_level": self.quality_level,
                "graphics_api": self.graphics_api,
                "render_scale": self.render_scale,
                "shadow_quality": self.shadow_quality,
                "texture_filtering": self.texture_filtering,
                "fog_enabled": self.fog_enabled,
                "fog_density": self.fog_density,
            },
            "physics": {
                "gravity": self.gravity,
                "solver_iterations": self.default_solver_iterations,
                "fixed_timestep": self.fixed_timestep,
                "default_contact_offset": self.default_contact_offset,
            },
            "input": self.input_actions,
            "audio": {
                "global_volume": self.global_volume,
                "max_concurrent_sounds": self.max_concurrent_sounds,
                "default_sample_rate": self.default_sample_rate,
                "reverb_enabled": self.reverb_enabled,
            },
            "scripting": {
                "default_language": self.default_scripting_language,
                "api_compatibility": self.api_compatibility,
                "allow_debugging": self.allow_debugging,
                "script_reload_on_save": self.script_reload_on_save,
                "hot_reload_scripts": self.hot_reload_scripts,
            },
            "editor": {
                "auto_save": self.editor_auto_save,
                "auto_save_interval": self.editor_auto_save_interval,
                "show_grid": self.editor_show_grid,
                "show_gizmos": self.editor_show_gizmos,
                "show_fps": self.editor_show_fps,
                "show_scene_info": self.editor_show_scene_info,
                "scene_view_navigation_speed": self.scene_view_navigation_speed,
                "viewport_zoom_sensitivity": self.viewport_zoom_sensitivity,
                "viewport_orbit_sensitivity": self.viewport_orbit_sensitivity,
                "grid_snap_enabled": self.grid_snap_enabled,
                "grid_snap_increment": self.grid_snap_increment,
            },
            "build": {
                "output_type": self.build_output_type,
                "compression_level": self.compression_level,
                "code_optimization": self.code_optimization,
                "asset_bundle_splitting": self.asset_bundle_splitting,
                "include_debug_info": self.include_debug_info,
                "run_after_export": self.build_run_after_export,
                "open_in_browser": self.build_open_in_browser,
                "boot_timeout_seconds": self.build_boot_timeout_seconds,
                "start_scene_override": self.build_start_scene_override,
                "scenes": self.build_scenes,
            },
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ProjectSettings":
        s = cls()
        s.company_name = data.get("company_name", s.company_name)
        s.product_name = data.get("product_name", s.product_name)
        s.version = data.get("version", s.version)
        s.project_type = data.get("project_type", s.project_type)
        s.application_identifier = data.get("application_identifier", s.application_identifier)
        s.project_description = data.get("project_description", s.project_description)
        s.startup_scene = data.get("startup_scene", s.startup_scene)
        s.show_welcome_screen = data.get("show_welcome_screen", s.show_welcome_screen)

        disp = data.get("display", {})
        s.default_screen_width = disp.get("width", s.default_screen_width)
        s.default_screen_height = disp.get("height", s.default_screen_height)
        s.fullscreen_mode = disp.get("fullscreen_mode", s.fullscreen_mode)
        s.window_resizable = disp.get("window_resizable", s.window_resizable)
        s.window_maximized = disp.get("window_maximized", s.window_maximized)
        s.vsync_count = disp.get("vsync_count", s.vsync_count)
        s.target_framerate = disp.get("target_framerate", s.target_framerate)
        s.run_in_background = disp.get("run_in_background", s.run_in_background)
        s.show_splash_screen = disp.get("show_splash_screen", s.show_splash_screen)
        s.splash_screen_style = disp.get("splash_screen_style", s.splash_screen_style)
        s.splash_screen_duration = disp.get("splash_screen_duration", s.splash_screen_duration)
        s.color_space = disp.get("color_space", s.color_space)
        s.anti_aliasing = disp.get("anti_aliasing", s.anti_aliasing)
        s.anisotropic_filtering = disp.get("anisotropic_filtering", s.anisotropic_filtering)
        s.quality_level = disp.get("quality_level", s.quality_level)
        s.graphics_api = disp.get("graphics_api", s.graphics_api)
        s.render_scale = disp.get("render_scale", s.render_scale)
        s.shadow_quality = disp.get("shadow_quality", s.shadow_quality)
        s.texture_filtering = disp.get("texture_filtering", s.texture_filtering)
        s.fog_enabled = disp.get("fog_enabled", s.fog_enabled)
        s.fog_density = disp.get("fog_density", s.fog_density)

        phys = data.get("physics", {})
        s.gravity = phys.get("gravity", s.gravity)
        s.default_solver_iterations = phys.get("solver_iterations", s.default_solver_iterations)
        s.fixed_timestep = phys.get("fixed_timestep", s.fixed_timestep)
        s.default_contact_offset = phys.get("default_contact_offset", s.default_contact_offset)

        s.input_actions = data.get("input", s.input_actions)

        aud = data.get("audio", {})
        s.global_volume = aud.get("global_volume", s.global_volume)
        s.max_concurrent_sounds = aud.get("max_concurrent_sounds", s.max_concurrent_sounds)
        s.default_sample_rate = aud.get("default_sample_rate", s.default_sample_rate)
        s.reverb_enabled = aud.get("reverb_enabled", s.reverb_enabled)

        scr = data.get("scripting", {})
        s.default_scripting_language = scr.get("default_language", s.default_scripting_language)
        s.api_compatibility = scr.get("api_compatibility", s.api_compatibility)
        s.allow_debugging = scr.get("allow_debugging", s.allow_debugging)
        s.script_reload_on_save = scr.get("script_reload_on_save", s.script_reload_on_save)
        s.hot_reload_scripts = scr.get("hot_reload_scripts", s.hot_reload_scripts)

        editor = data.get("editor", {})
        s.editor_auto_save = editor.get("auto_save", s.editor_auto_save)
        s.editor_auto_save_interval = editor.get("auto_save_interval", s.editor_auto_save_interval)
        s.editor_show_grid = editor.get("show_grid", s.editor_show_grid)
        s.editor_show_gizmos = editor.get("show_gizmos", s.editor_show_gizmos)
        s.editor_show_fps = editor.get("show_fps", s.editor_show_fps)
        s.editor_show_scene_info = editor.get("show_scene_info", s.editor_show_scene_info)
        s.scene_view_navigation_speed = editor.get("scene_view_navigation_speed", s.scene_view_navigation_speed)
        s.viewport_zoom_sensitivity = editor.get("viewport_zoom_sensitivity", s.viewport_zoom_sensitivity)
        s.viewport_orbit_sensitivity = editor.get("viewport_orbit_sensitivity", s.viewport_orbit_sensitivity)
        s.grid_snap_enabled = editor.get("grid_snap_enabled", s.grid_snap_enabled)
        s.grid_snap_increment = editor.get("grid_snap_increment", s.grid_snap_increment)

        bld = data.get("build", {})
        s.build_output_type = bld.get("output_type", s.build_output_type)
        s.compression_level = bld.get("compression_level", s.compression_level)
        s.code_optimization = bld.get("code_optimization", s.code_optimization)
        s.asset_bundle_splitting = bld.get("asset_bundle_splitting", s.asset_bundle_splitting)
        s.include_debug_info = bld.get("include_debug_info", s.include_debug_info)
        s.build_run_after_export = bld.get("run_after_export", s.build_run_after_export)
        s.build_open_in_browser = bld.get("open_in_browser", s.build_open_in_browser)
        s.build_boot_timeout_seconds = bld.get("boot_timeout_seconds", s.build_boot_timeout_seconds)
        s.build_start_scene_override = bld.get("start_scene_override", s.build_start_scene_override)

        scenes = bld.get("scenes", [])
        if isinstance(scenes, list):
            s.build_scenes = []
            for item in scenes:
                if isinstance(item, dict) and item.get("path"):
                    s.build_scenes.append({
                        "path": str(item.get("path")),
                        "enabled": bool(item.get("enabled", True)),
                        "is_start": bool(item.get("is_start", False)),
                    })
                elif isinstance(item, str):
                    s.build_scenes.append({"path": item, "enabled": True, "is_start": False})

        legacy_scenes = data.get("scenes")
        if not s.build_scenes and isinstance(legacy_scenes, list):
            s.build_scenes = [{"path": p, "enabled": True, "is_start": False} for p in legacy_scenes]

        if not s.startup_scene and s.build_scenes:
            start = next((i["path"] for i in s.build_scenes if i.get("is_start")), None)
            if start:
                s.startup_scene = start
            else:
                s.startup_scene = s.build_scenes[0]["path"]
                s.build_scenes[0]["is_start"] = True

        return s


class Project:
    """Main project container."""

    def __init__(self, path: str):
        self.path = Path(path)
        self.name = self.path.name
        self.settings = ProjectSettings()
        self.scenes: List[str] = []
        self.active_scene: Optional[str] = None
        self._ensure_structure()

    def _ensure_structure(self):
        folders = [
            "Assets", "Assets/Scripts", "Assets/Scenes", "Assets/Models",
            "Assets/Textures", "Assets/Audio", "Assets/Materials",
            "Assets/Prefabs", "Library", "Build"
        ]
        for folder in folders:
            (self.path / folder).mkdir(parents=True, exist_ok=True)

    def register_scene(self, scene_path: str, *, set_active: bool = False, is_start: bool = False):
        if scene_path not in self.scenes:
            self.scenes.append(scene_path)
        self.sync_build_scenes()
        if set_active:
            self.active_scene = scene_path
        if is_start:
            self.set_start_scene(scene_path)

    def sync_build_scenes(self):
        existing = {item.get("path"): item for item in self.settings.build_scenes if item.get("path")}
        merged: List[Dict[str, Any]] = []
        for scene_path in self.scenes:
            item = existing.get(scene_path, {"path": scene_path, "enabled": True, "is_start": False})
            merged.append({
                "path": scene_path,
                "enabled": bool(item.get("enabled", True)),
                "is_start": bool(item.get("is_start", False)),
            })
        self.settings.build_scenes = merged
        if merged and not any(i["is_start"] for i in merged):
            merged[0]["is_start"] = True
            self.settings.startup_scene = merged[0]["path"]

    def set_scene_enabled(self, scene_path: str, enabled: bool):
        self.sync_build_scenes()
        for item in self.settings.build_scenes:
            if item["path"] == scene_path:
                item["enabled"] = enabled
                break

    def set_start_scene(self, scene_path: str):
        self.sync_build_scenes()
        for item in self.settings.build_scenes:
            item["is_start"] = item["path"] == scene_path
        if scene_path:
            self.settings.startup_scene = scene_path
            self.settings.build_start_scene_override = scene_path

    def get_enabled_scenes(self) -> List[str]:
        self.sync_build_scenes()
        return [item["path"] for item in self.settings.build_scenes if item.get("enabled")]

    def get_start_scene(self) -> Optional[str]:
        self.sync_build_scenes()
        if self.settings.build_start_scene_override:
            return self.settings.build_start_scene_override
        if self.settings.startup_scene:
            return self.settings.startup_scene
        for item in self.settings.build_scenes:
            if item.get("is_start"):
                return item["path"]
        return self.scenes[0] if self.scenes else None

    def save(self):
        self.sync_build_scenes()
        manifest = {
            "name": self.name,
            "settings": self.settings.to_dict(),
            "scenes": self.scenes,
            "active_scene": self.active_scene,
        }
        with open(self.path / "Project.tcproj", "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2)

    @classmethod
    def load(cls, path: str) -> "Project":
        p = cls(path)
        manifest_path = p.path / "Project.tcproj"
        if manifest_path.exists():
            with open(manifest_path, "r", encoding="utf-8") as f:
                manifest = json.load(f)
            p.settings = ProjectSettings.from_dict(manifest.get("settings", {}))
            p.scenes = manifest.get("scenes", [])
            p.active_scene = manifest.get("active_scene")
            p.sync_build_scenes()
        return p

    def create_scene(self, name: str = "New Scene", template: str = "empty", set_active: bool = True) -> str:
        scene_path = f"Assets/Scenes/{name}.tcscene"
        full_path = self.path / scene_path
        full_path.parent.mkdir(parents=True, exist_ok=True)

        from .. import templates as templates_pkg
        templates_dir = Path(templates_pkg.__file__).parent
        template_map = {
            "empty": templates_dir / "empty_3d.tcscene",
            "2d": templates_dir / "2d_platformer.tcscene",
            "3d": templates_dir / "3d_fps.tcscene",
        }
        template_path = template_map.get(template, template_map["empty"])

        if template_path.exists():
            data = template_path.read_text(encoding="utf-8")
            try:
                scene_data = json.loads(data)
                scene_data["name"] = name
            except Exception:
                scene_data = None
        else:
            scene_data = None

        if scene_data is None:
            from .ecs import Scene
            scene = Scene(name)
            scene_data = scene.to_dict()

        with open(full_path, "w", encoding="utf-8") as f:
            json.dump(scene_data, f, indent=2)

        self.register_scene(scene_path, set_active=set_active, is_start=(len(self.scenes) == 0))
        return scene_path
