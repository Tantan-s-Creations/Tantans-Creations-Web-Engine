"""Pastel editor theme and font helpers."""
from __future__ import annotations

import tkinter as tk
from tkinter import ttk
from tkinter import font as tkfont

PALETTE = {
    "bg": "#F3F0FF",
    "panel": "#ECE4FF",
    "panel_alt": "#E4ECFF",
    "surface": "#FFFFFF",
    "surface_alt": "#F7F2FF",
    "border": "#C8BAF0",
    "text": "#211D33",
    "muted": "#6A6381",
    "blue": "#4C78E8",
    "blue_soft": "#D9E5FF",
    "purple": "#8459E8",
    "purple_soft": "#E4D9FF",
    "pastel_blue": "#E6F0FF",
    "pastel_purple": "#F0E7FF",
    "pastel_blue_alt": "#D8E7FF",
    "pastel_purple_alt": "#E9DEFF",
    "success": "#67A77B",
    "success_soft": "#DCEFE1",
    "warning": "#D89A3B",
    "error": "#D46C8E",
    "green": "#5CAB78",
}


def get_font_family(root: tk.Misc, preferred: str = "Bungee", fallback: str = "Segoe UI") -> str:
    try:
        families = set(tkfont.families(root))
        if preferred in families:
            return preferred
    except Exception:
        pass
    return fallback


def apply_theme(root: tk.Misc, *, font_family: str | None = None) -> dict:
    """Apply a pastel theme to the Tk root and return the resolved theme settings."""
    resolved_font = font_family or get_font_family(root)
    title_font = (resolved_font, 13, "bold")
    body_font = (resolved_font, 10)
    ui_font = (resolved_font, 9)
    mono_font = ("Consolas", 10)

    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except Exception:
        pass

    root.option_add("*Font", ui_font)
    root.option_add("*Menu.Font", ui_font)
    root.option_add("*TCombobox*Listbox.Font", ui_font)
    root.option_add("*Text.Font", mono_font)
    root.option_add("*Toplevel.background", PALETTE["bg"])
    root.option_add("*Menu.background", PALETTE["surface"])
    root.option_add("*Menu.foreground", PALETTE["text"])
    root.option_add("*Menu.activeBackground", PALETTE["pastel_blue"])
    root.option_add("*Menu.activeForeground", PALETTE["text"])

    style.configure("TFrame", background=PALETTE["bg"])
    style.configure("TLabel", background=PALETTE["bg"], foreground=PALETTE["text"], font=ui_font)
    style.configure("Header.TLabel", background=PALETTE["bg"], foreground=PALETTE["purple"], font=title_font)
    style.configure("Subtle.TLabel", background=PALETTE["bg"], foreground=PALETTE["muted"], font=ui_font)
    style.configure("TButton", background=PALETTE["surface"], foreground=PALETTE["text"], font=ui_font, padding=(10, 6))
    style.map("TButton", background=[("active", PALETTE["pastel_blue"]), ("pressed", PALETTE["pastel_purple"])], relief=[("pressed", "sunken")])
    style.configure("Accent.TButton", background=PALETTE["blue_soft"], foreground=PALETTE["text"], font=ui_font, padding=(10, 6), bordercolor=PALETTE["blue"])
    style.map("Accent.TButton", background=[("active", PALETTE["pastel_blue_alt"])])
    style.configure("Success.TButton", background=PALETTE["success_soft"], foreground=PALETTE["text"], font=ui_font, padding=(10, 6), bordercolor=PALETTE["success"])
    style.map("Success.TButton", background=[("active", "#CFE8D8")])
    style.configure("Danger.TButton", background="#F8DDE8", foreground=PALETTE["text"], font=ui_font, padding=(10, 6))
    style.map("Danger.TButton", background=[("active", "#F4CDDA")])
    style.configure("TLabelframe", background=PALETTE["bg"], foreground=PALETTE["purple"], bordercolor=PALETTE["border"], relief="groove")
    style.configure("TLabelframe.Label", background=PALETTE["bg"], foreground=PALETTE["purple"], font=body_font)
    style.configure("TNotebook", background=PALETTE["bg"], borderwidth=0)
    style.configure("TNotebook.Tab", background=PALETTE["panel"], foreground=PALETTE["text"], padding=(12, 7))
    style.map("TNotebook.Tab", background=[("selected", PALETTE["surface"]), ("active", PALETTE["pastel_purple"])])
    style.configure("Treeview", background=PALETTE["surface"], fieldbackground=PALETTE["surface"], foreground=PALETTE["text"], rowheight=24, bordercolor=PALETTE["border"], font=ui_font)
    style.map("Treeview", background=[("selected", PALETTE["pastel_blue"])], foreground=[("selected", PALETTE["text"])])
    style.configure("Treeview.Heading", background=PALETTE["panel"], foreground=PALETTE["purple"], relief="flat", font=body_font)
    style.configure("TEntry", fieldbackground=PALETTE["surface"], foreground=PALETTE["text"])
    style.configure("TCombobox", fieldbackground=PALETTE["surface"], foreground=PALETTE["text"])
    style.configure("TCheckbutton", background=PALETTE["bg"], foreground=PALETTE["text"], font=ui_font)
    style.configure("TRadiobutton", background=PALETTE["bg"], foreground=PALETTE["text"], font=ui_font)
    style.configure("TSpinbox", fieldbackground=PALETTE["surface"], foreground=PALETTE["text"])
    style.configure("Sunk.TLabel", background=PALETTE["panel"], foreground=PALETTE["text"], padding=(8, 6))
    style.configure("TSeparator", background=PALETTE["border"])

    return {
        "font_family": resolved_font,
        "title_font": title_font,
        "body_font": body_font,
        "ui_font": ui_font,
        "mono_font": mono_font,
        "palette": PALETTE,
    }
