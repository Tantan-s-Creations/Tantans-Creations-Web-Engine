# Tantan's Creations Web Engine v1.0

A complete 2D/3D game engine for creating web-based games that export to functional HTML files.

## Features

### Core Engine
- **2D & 3D Game Creation** - Seamlessly switch between 2D sprite-based and 3D mesh-based development
- **Entity Component System (ECS)** - High-performance data-oriented architecture with OOP editor wrappers
- **Software Renderer** - Real-time 3D viewport with lighting, shadows, and gizmos
- **Asset Pipeline** - Import OBJ, FBX, PNG, JPG, WAV, MP3, CS, JS, and more
- **Prefab System** - Reusable entity templates with override tracking

### Scripting
- **Dual Language Support** - Write in C# (transpiled to JS) or native JavaScript
- **Unity-Compatible API** - Familiar MonoBehaviour lifecycle (Start, Update, FixedUpdate, OnCollisionEnter)
- **In-Engine Editor** - Syntax highlighting, line numbers, and multi-tab support
- **Live Compilation** - Scripts compile in-memory for instant playtesting

### Editor
- **Dockable Workspace** - Customizable panel layout (Hierarchy, Inspector, Project, Console, Script Editor)
- **Scene Viewport** - Orbit, pan, zoom camera controls with entity selection
- **Transform Gizmos** - Visual XYZ axis manipulation for selected objects
- **Project Settings** - Unity-style Player, Display, Physics, Input, Audio, Scripting, and Build settings
- **Console** - Filterable log output with Info, Warning, Error, and Script categories

### Export & Build
- **Single HTML Export** - One self-contained .html file with all assets embedded
- **Standard Web Export** - Separate JS and data files for hosting
- **Three.js Runtime** - Exported games run on Three.js with WebGL 2.0
- **Progressive Web App** - Optional service worker and manifest (future)
- **Asset Optimization** - Texture compression, mesh optimization, and dead code elimination

## Quick Start

### Prerequisites
- Python 3.8 or higher
- Windows 10/11, Linux, or macOS
- PIL (Pillow) and NumPy (usually included with Python)

### Windows
```batch
Launch Engine.bat
```

### Linux / macOS
```bash
chmod +x launch.sh
./launch.sh
```

### Manual Launch
```bash
python -m tantan_engine.main
```

## Creating Your First Game

1. **New Project**
   - File > New Project
   - Name your project and choose a location

2. **Create a Scene**
   - GameObject > Create Empty (or Cube, Sprite, Light, Camera)
   - Use the Inspector to set position, rotation, scale

3. **Add a Script**
   - Select your player entity
   - Inspector > Add Component > Script
   - Choose JavaScript or C#
   - Write your game logic

4. **Test in Play Mode**
   - Click the Play button (or press F5)
   - Test your game in the viewport
   - Click Stop to return to editing

5. **Export to HTML**
   - Click "Build HTML" in the toolbar
   - Find your game in the `Build/` folder
   - Open `index.html` in any browser

## Project Structure

```
MyGame/
  Project.tcproj          # Project manifest
  Assets/
    Scripts/              # C# and JavaScript files
      PlayerController.js
      EnemyAI.cs
    Scenes/               # .tcscene files
      MainScene.tcscene
      Level2.tcscene
    Models/               # 3D models
      player.obj
      level.fbx
    Textures/             # Images
      player.png
      skybox.jpg
    Audio/                # Sound files
      jump.wav
      bgm.mp3
    Materials/            # Material definitions
      player_mat.tcmat
    Prefabs/              # Reusable objects
      enemy.prefab
  Library/                # Generated cache (auto-managed)
    AssetDatabase.json
    Thumbnails/
  Build/                  # HTML output
    index.html
```

## Scripting Reference

### JavaScript API
```javascript
// Lifecycle
function Start() { }      // Called once on creation
function Update() { }     // Called every frame
function FixedUpdate() { } // Called at fixed timestep

// Input
TEngine.input.getAxis("Horizontal");     // Returns -1 to 1
TEngine.input.getButton("Jump");         // Returns true/false
TEngine.input.getKey("space");           // Key check
TEngine.input.mousePosition;             // Vector2 of mouse

// Transform
this.transform.position;                 // Vector3 position
this.transform.rotation;                 // Vector3 euler angles
this.transform.localScale;               // Vector3 scale
this.transform.translate(x, y, z);       // Move relative
this.transform.rotate(x, y, z);          // Rotate in degrees
this.transform.forward;                  // Forward direction

// Time
TEngine.deltaTime;                       // Frame time in seconds
TEngine.time;                            // Total elapsed time
TEngine.fixedDeltaTime;                  // Fixed timestep

// Math
TEngine.Vector3(x, y, z);                // Create vector
TEngine.mathf.lerp(a, b, t);             // Linear interpolation
TEngine.mathf.clamp(v, min, max);        // Clamp value

// Physics
TEngine.physics.raycast(origin, direction, maxDistance);

// GameObject
TEngine.findObject("Player");            // Find by name
TEngine.destroy(gameObject);             // Destroy object
```

### C# API (transpiled to JS)
```csharp
using TantanEngine;

public class PlayerController : MonoBehaviour
{
    public float speed = 5.0f;
    public int health = 100;

    void Start()
    {
        Debug.Log("Player started!");
    }

    void Update()
    {
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");

        Vector3 move = new Vector3(h, 0, v).normalized * speed * Time.deltaTime;
        transform.Translate(move);

        if (Input.GetButton("Jump"))
        {
            transform.Translate(0, 10 * Time.deltaTime, 0);
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.name == "Enemy")
        {
            health -= 10;
        }
    }
}
```

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| Ctrl+N | New Project |
| Ctrl+O | Open Project |
| Ctrl+S | Save Project |
| F5 | Enter Play Mode |
| Delete | Delete Selected |
| F | Focus Selected |
| Alt+LMB | Orbit Camera |
| RMB | Pan Camera |
| Scroll | Zoom Camera |

## Templates Included

- **Empty 3D** - Basic camera + light setup
- **2D Platformer** - Player controller, ground, jumping mechanics
- **3D FPS** - First-person controller, floor, walls

## Architecture

```
TantanEngine/
  core/           # Engine core (math, ECS, assets, project)
  editor/         # Editor UI (viewport, inspector, hierarchy, etc.)
  runtime/        # Play mode (renderer, scripting host)
  exporters/      # Build pipeline (C# transpiler, HTML exporter)
  templates/      # Starter project templates
```

## Performance

- **Software Renderer** - Numpy-based rasterization for editor viewport
- **Web Export** - Three.js with WebGL 2.0 for maximum browser compatibility
- **Asset Optimization** - Automatic texture compression and mesh decimation
- **Code Splitting** - Engine modules excluded if unused (e.g., no 3D = no 3D renderer)

## Future Roadmap

- [ ] WebGPU backend support
- [ ] Visual Scripting (node editor)
- [ ] Asset Store integration
- [ ] Multiplayer networking template
- [ ] Mobile touch input auto-detection
- [ ] Shader graph editor
- [ ] Animation timeline
- [ ] Particle system

## License

(c) 2026 Tantan's Creations. All rights reserved.

## Support

For documentation, tutorials, and community support:
- Website: https://tantans-creations.com
- Discord: discord.gg/tantanscreations
- Email: support@tantans-creations.com
