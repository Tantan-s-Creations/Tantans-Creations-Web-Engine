"""C# to JavaScript transpiler for Tantan's Creations Web Engine
Supports a simplified subset of C# with Unity-like MonoBehaviour patterns.
"""
import re
from typing import List, Dict, Tuple

class CSharpTranspiler:
    """Transpiles simplified C# game scripts to JavaScript"""

    API_MAPPINGS = {
        "GameObject.Find": "TEngine.findObject",
        "GameObject.Instantiate": "TEngine.instantiate",
        "Destroy": "TEngine.destroy",
        "GetComponent": "this.getComponent",
        "GetComponentInChildren": "this.getComponentInChildren",
        "GetComponentsInChildren": "this.getComponentsInChildren",
        "transform.position": "this.transform.position",
        "transform.rotation": "this.transform.rotation",
        "transform.localPosition": "this.transform.localPosition",
        "transform.localRotation": "this.transform.localRotation",
        "transform.localScale": "this.transform.localScale",
        "transform.Translate": "this.transform.translate",
        "transform.Rotate": "this.transform.rotate",
        "transform.LookAt": "this.transform.lookAt",
        "transform.forward": "this.transform.forward",
        "transform.up": "this.transform.up",
        "transform.right": "this.transform.right",
        "transform.parent": "this.transform.parent",
        "transform.SetParent": "this.transform.setParent",
        "Time.deltaTime": "TEngine.deltaTime",
        "Time.time": "TEngine.time",
        "Time.fixedDeltaTime": "TEngine.fixedDeltaTime",
        "Input.GetAxis": "TEngine.input.getAxis",
        "Input.GetButton": "TEngine.input.getButton",
        "Input.GetKey": "TEngine.input.getKey",
        "Input.GetMouseButton": "TEngine.input.getMouseButton",
        "Input.mousePosition": "TEngine.input.mousePosition",
        "Vector3": "TEngine.Vector3",
        "Vector2": "TEngine.Vector2",
        "Quaternion": "TEngine.Quaternion",
        "Mathf": "Math",
        "Mathf.Sin": "Math.sin",
        "Mathf.Cos": "Math.cos",
        "Mathf.Tan": "Math.tan",
        "Mathf.Sqrt": "Math.sqrt",
        "Mathf.Abs": "Math.abs",
        "Mathf.Min": "Math.min",
        "Mathf.Max": "Math.max",
        "Mathf.Clamp": "TEngine.mathf.clamp",
        "Mathf.Lerp": "TEngine.mathf.lerp",
        "Mathf.Deg2Rad": "(Math.PI / 180)",
        "Mathf.Rad2Deg": "(180 / Math.PI)",
        "Debug.Log": "console.log",
        "Debug.LogWarning": "console.warn",
        "Debug.LogError": "console.error",
        "Application.Quit": "TEngine.application.quit",
        "SceneManager.LoadScene": "TEngine.sceneManager.loadScene",
        "Random.Range": "TEngine.random.range",
        "Physics.Raycast": "TEngine.physics.raycast",
        "Physics.OverlapBox": "TEngine.physics.overlapBox",
        "Physics.OverlapSphere": "TEngine.physics.overlapSphere",
    }

    def __init__(self):
        self.classes = []
        self.current_class = None

    def transpile(self, csharp_code: str) -> str:
        """Main transpilation entry point"""
        lines = csharp_code.split("\n")
        js_lines = []

        # Pre-process: remove comments
        cleaned = self._remove_comments(csharp_code)

        # Tokenize and process
        tokens = self._tokenize(cleaned)
        js_lines = self._process_tokens(tokens)

        return "\n".join(js_lines)

    def _remove_comments(self, code: str) -> str:
        """Remove C# comments"""
        code = re.sub(r'//.*', '', code)
        code = re.sub(r'/\*.*?\*/', '', code, flags=re.DOTALL)
        return code

    def _tokenize(self, code: str) -> List[str]:
        """Simple tokenizer"""
        # Split by newlines and braces while preserving structure
        lines = code.split("\n")
        tokens = []
        for line in lines:
            stripped = line.strip()
            if stripped:
                tokens.append(stripped)
        return tokens

    def _process_tokens(self, tokens: List[str]) -> List[str]:
        """Process tokens and convert to JS"""
        js_lines = []
        indent = 0
        i = 0

        while i < len(tokens):
            token = tokens[i]

            # Skip using statements
            if token.startswith("using "):
                js_lines.append("// " + token)
                i += 1
                continue

            # Skip namespace
            if token.startswith("namespace "):
                i += 1
                if i < len(tokens) and tokens[i] == "{":
                    i += 1
                continue

            # Class declaration
            class_match = re.match(r'(?:public\s+|internal\s+|abstract\s+|sealed\s+)*class\s+(\w+)(?:\s*:\s*(\w+))?', token)
            if class_match:
                class_name = class_match.group(1)
                base_class = class_match.group(2) or ""
                js_lines.append(f"class {class_name} {{")
                if base_class in ["MonoBehaviour", "Behaviour"]:
                    js_lines.append("    constructor() {")
                    js_lines.append("        this.enabled = true;")
                    js_lines.append("        this.entity = null;")
                    js_lines.append("        this.transform = null;")
                    js_lines.append("    }")
                indent = 1
                i += 1
                continue

            # Method declaration
            method_match = re.match(r'(?:public|private|protected|internal|static|override|virtual|abstract)\s+(?:[\w<>,\s\[\]]+?)\s+(\w+)\s*\((.*?)\)', token)
            if method_match:
                method_name = method_match.group(1)
                params = method_match.group(2)
                js_params = self._convert_params(params)
                js_lines.append("    " + method_name + "(" + js_params + ") {")
                indent = 1
                i += 1
                continue

            # Variable declaration with access modifier
            var_match = re.match(r'(public|private|protected|internal)\s+(?:static\s+)?(?:readonly\s+)?(?:const\s+)?([\w<>,\s\[\]]+?)\s+(\w+)\s*(?:=\s*(.+?))?;', token)
            if var_match:
                access = var_match.group(1)
                var_type = var_match.group(2)
                var_name = var_match.group(3)
                value = var_match.group(4)
                js_value = self._convert_value(value, var_type) if value else self._default_value(var_type)
                if access == "public":
                    js_lines.append(f"    this.{var_name} = {js_value};")
                else:
                    js_lines.append(f"    var {var_name} = {js_value};")
                i += 1
                continue

            # Local variable declaration
            local_var_match = re.match(r'([\w<>,\s\[\]]+?)\s+(\w+)\s*(?:=\s*(.+?))?;', token)
            if local_var_match and not token.startswith("if") and not token.startswith("for") and not token.startswith("while"):
                var_type = local_var_match.group(1)
                var_name = local_var_match.group(2)
                value = local_var_match.group(3)
                js_value = self._convert_value(value, var_type) if value else self._default_value(var_type)
                js_lines.append(f"    var {var_name} = {js_value};")
                i += 1
                continue

            # Control flow
            if token.startswith("if "):
                js_lines.append(self._convert_if(token))
                i += 1
                continue

            if token == "else":
                js_lines.append("    } else {")
                i += 1
                continue

            if token.startswith("else if "):
                js_lines.append(self._convert_else_if(token))
                i += 1
                continue

            if token.startswith("for "):
                js_lines.append(self._convert_for(token))
                i += 1
                continue

            if token.startswith("foreach "):
                js_lines.append(self._convert_foreach(token))
                i += 1
                continue

            if token.startswith("while "):
                js_lines.append(self._convert_while(token))
                i += 1
                continue

            if token == "do":
                js_lines.append("    do {")
                i += 1
                continue

            if token.startswith("switch "):
                js_lines.append(self._convert_switch(token))
                i += 1
                continue

            if token.startswith("case "):
                js_lines.append(self._convert_case(token))
                i += 1
                continue

            if token == "default:":
                js_lines.append("    default:")
                i += 1
                continue

            if token == "break;":
                js_lines.append("    break;")
                i += 1
                continue

            if token == "continue;":
                js_lines.append("    continue;")
                i += 1
                continue

            if token.startswith("return ") or token == "return;":
                js_lines.append(self._convert_return(token))
                i += 1
                continue

            # Closing brace
            if token == "}":
                js_lines.append("    }")
                i += 1
                continue

            # Regular statement
            converted = self._convert_statement(token)
            js_lines.append("    " + converted)
            i += 1

        # Close class
        js_lines.append("}")

        return js_lines

    def _convert_params(self, params: str) -> str:
        if not params:
            return ""
        result = []
        for param in params.split(","):
            param = param.strip()
            parts = param.split()
            if len(parts) >= 2:
                result.append(parts[-1])
            elif parts:
                result.append(parts[0])
        return ", ".join(result)

    def _default_value(self, var_type: str) -> str:
        if var_type in ["int", "float", "double", "decimal"]:
            return "0"
        elif var_type == "bool":
            return "false"
        elif var_type == "string":
            return '""'
        elif "[]" in var_type or "List" in var_type:
            return "[]"
        else:
            return "null"

    def _convert_value(self, value: str, var_type: str) -> str:
        if value is None:
            return self._default_value(var_type)

        value = value.strip()

        if value.startswith('"') and value.endswith('"'):
            return value

        if value.startswith("'") and value.endswith("'"):
            return value

        if value.endswith('f') or value.endswith('F'):
            return value[:-1]

        if value in ["true", "false"]:
            return value

        if value == "null":
            return "null"

        return self._convert_expression(value)

    def _convert_expression(self, expr: str) -> str:
        expr = expr.strip()

        for cs_api, js_api in sorted(self.API_MAPPINGS.items(), key=lambda x: -len(x[0])):
            expr = expr.replace(cs_api, js_api)

        expr = re.sub(r'new\s+(\w+)\s*\(([^)]*)\)', r'new \1(\2)', expr)
        expr = re.sub(r'typeof\s*\(([^)]+)\)', r'"\1"', expr)
        expr = re.sub(r'(\w+)\s+is\s+(\w+)', r'(\1 instanceof \2)', expr)
        expr = re.sub(r'\bout\s+', '', expr)
        expr = re.sub(r'\bref\s+', '', expr)

        return expr

    def _convert_statement(self, line: str) -> str:
        if line.endswith(";"):
            line = line[:-1]
        converted = self._convert_expression(line)
        return converted + ";"

    def _convert_if(self, line: str) -> str:
        match = re.match(r'(.*?)if\s*\((.+)\)', line)
        if match:
            condition = self._convert_expression(match.group(2))
            return f"    if ({condition}) {{"
        return line

    def _convert_else_if(self, line: str) -> str:
        match = re.match(r'(.*?)else\s+if\s*\((.+)\)', line)
        if match:
            condition = self._convert_expression(match.group(2))
            return f"    }} else if ({condition}) {{"
        return line

    def _convert_for(self, line: str) -> str:
        match = re.match(r'(.*?)for\s*\((.+)\)', line)
        if match:
            parts = match.group(2).split(";")
            if len(parts) == 3:
                init = self._convert_statement(parts[0]).rstrip(";")
                cond = self._convert_expression(parts[1])
                incr = self._convert_statement(parts[2]).rstrip(";")
                return f"    for ({init}; {cond}; {incr}) {{"
        return line

    def _convert_foreach(self, line: str) -> str:
        match = re.match(r'(.*?)foreach\s*\((.+)\)', line)
        if match:
            parts = match.group(2).split(" in ")
            if len(parts) == 2:
                var_decl = parts[0].strip()
                collection = self._convert_expression(parts[1].strip())
                var_match = re.match(r'(?:var\s+)?([\w<>,\s\[\]]+?)\s+(\w+)', var_decl)
                if var_match:
                    var_name = var_match.group(2)
                else:
                    var_name = var_decl.split()[-1]
                return f"    for (let {var_name} of {collection}) {{"
        return line

    def _convert_while(self, line: str) -> str:
        match = re.match(r'(.*?)while\s*\((.+)\)', line)
        if match:
            condition = self._convert_expression(match.group(2))
            return f"    while ({condition}) {{"
        return line

    def _convert_switch(self, line: str) -> str:
        match = re.match(r'(.*?)switch\s*\((.+)\)', line)
        if match:
            expr = self._convert_expression(match.group(2))
            return f"    switch ({expr}) {{"
        return line

    def _convert_case(self, line: str) -> str:
        match = re.match(r'(.*?)case\s+(.+):', line)
        if match:
            value = match.group(2).strip()
            return f"    case {value}:"
        return line

    def _convert_return(self, line: str) -> str:
        match = re.match(r'(.*?)return\s*(.*)?;?', line)
        if match:
            value = match.group(2) if match.group(2) else ""
            if value:
                converted = self._convert_expression(value)
                return f"    return {converted};"
            return f"    return;"
        return line


def transpile_csharp_to_js(csharp_code: str) -> str:
    transpiler = CSharpTranspiler()
    return transpiler.transpile(csharp_code)
