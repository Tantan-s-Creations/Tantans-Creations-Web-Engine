"""HTML5 exporter for Tantan's Creations Web Engine v1.9.
Generates functional HTML files with an embedded, dependency-free runtime.
Supports both 2D and 3D project types with proper rendering.
"""
from __future__ import annotations

import base64
import json
from pathlib import Path
from typing import Dict

from ..core.ecs import Scene, Entity, Transform, MeshFilter, MeshRenderer, SpriteRenderer, Camera, Light, Script
from ..core.assets import TextureAsset
from .csharp_transpiler import transpile_csharp_to_js


class HTMLExporter:
    """Exports scenes to functional HTML5 games."""

    def __init__(self, project_path: str):
        self.project_path = Path(project_path)
        self.assets_path = self.project_path / "Assets"
        self.build_path = self.project_path / "Build"
        self.settings = None
        self.asset_db = None

    def export(self, scene: Scene, output_name="game", output_type="single_html") -> str:
        """Export scene to HTML. Returns output file path."""
        self.build_path.mkdir(parents=True, exist_ok=True)

        scene_data = self._export_scene_data(scene)
        script_sources = self._export_scripts(scene)
        asset_data = self._export_assets(scene)

        # Determine project type from settings
        project_type = "3D"
        if self.settings and hasattr(self.settings, 'project_type'):
            project_type = self.settings.project_type

        if output_type == "single_html":
            output_path = self._build_single_html(scene_data, script_sources, asset_data, output_name, project_type)
        else:
            output_path = self._build_standard_web(scene_data, script_sources, asset_data, output_name, project_type)

        return str(output_path)

    def _export_scene_data(self, scene: Scene) -> dict:
        entities_data = []
        for entity in scene.root_entities:
            entities_data.append(self._export_entity(entity))
        return {"name": scene.name, "settings": scene.settings, "entities": entities_data}

    def _export_entity(self, entity: Entity) -> dict:
        transform = entity.get_component(Transform)
        entity_data = {
            "id": entity.id,
            "name": entity.name,
            "active": entity.active,
            "transform": {
                "position": transform.position.to_dict() if transform else {"x": 0, "y": 0, "z": 0},
                "rotation": transform.rotation.to_dict() if transform else {"x": 0, "y": 0, "z": 0},
                "scale": transform.scale.to_dict() if transform else {"x": 1, "y": 1, "z": 1},
            },
            "components": [],
            "children": [self._export_entity(child) for child in entity.children],
        }

        for comp in entity.components:
            comp_data = comp.to_dict()
            if isinstance(comp, MeshFilter) and self.asset_db and comp.mesh_asset_id:
                mesh_asset = self.asset_db.get_asset_by_id(comp.mesh_asset_id)
                if mesh_asset and hasattr(mesh_asset, "mesh_data") and mesh_asset.mesh_data:
                    comp_data["mesh_data"] = mesh_asset.mesh_data
            elif isinstance(comp, SpriteRenderer) and self.asset_db and comp.texture_asset_id:
                tex_asset = self.asset_db.get_asset_by_id(comp.texture_asset_id)
                if tex_asset:
                    comp_data["texture_base64"] = self._texture_to_base64(tex_asset)
            elif isinstance(comp, Camera):
                comp_data["is_main"] = True
            entity_data["components"].append(comp_data)

        return entity_data

    def _texture_to_base64(self, tex_asset) -> str:
        try:
            abs_path = self.assets_path / tex_asset.path
            if abs_path.exists():
                data = abs_path.read_bytes()
                ext = abs_path.suffix.lower()
                mime = "image/png" if ext == ".png" else "image/jpeg" if ext in [".jpg", ".jpeg"] else "image/png"
                return f"data:{mime};base64," + base64.b64encode(data).decode()
        except Exception:
            pass
        return ""

    def _export_scripts(self, scene: Scene):
        script_sources = []
        for entity in scene.entities.values():
            script_comp = entity.get_component(Script)
            if not script_comp:
                continue

            code = ""
            if script_comp.source_code:
                code = script_comp.source_code
            elif script_comp.source_file:
                path = self.assets_path / script_comp.source_file
                if path.exists():
                    code = path.read_text(encoding="utf-8")

            if not code:
                continue

            lang = script_comp.language
            if lang == "csharp":
                code = transpile_csharp_to_js(code)
            elif lang == "java":
                code = self._transpile_java_to_js(code)

            script_sources.append({
                "entity": entity.name,
                "language": lang,
                "code": code,
                "properties": script_comp.properties or {},
            })

        return script_sources

    def _transpile_java_to_js(self, code: str) -> str:
        """Basic Java to JavaScript transpilation."""
        lines = code.split("\n")
        result = []
        in_class = False

        for line in lines:
            stripped = line.strip()
            if stripped.startswith("package ") or stripped.startswith("import "):
                continue
            if "class " in stripped and "{" in stripped:
                in_class = True
                result.append("class GameObject {")
                continue
            if not in_class:
                continue
            line = line.replace("boolean ", "let ").replace("int ", "let ").replace("float ", "let ")
            line = line.replace("String ", "let ").replace("double ", "let ")
            line = line.replace("System.out.println", "console.log").replace("System.out.print", "console.log")
            line = line.replace("public ", "").replace("private ", "").replace("protected ", "")
            result.append(line)
        result.append("}")
        return "\n".join(result)

    def _export_assets(self, scene: Scene) -> dict:
        return {}

    def _build_single_html(self, scene_data: dict, script_sources, asset_data: dict, name: str, project_type: str) -> Path:
        output_path = self.build_path / f"{name}.html"
        script_sources_json = json.dumps(script_sources, indent=2)
        scene_json = json.dumps(scene_data, indent=2)
        settings_json = json.dumps(getattr(self.settings, "to_dict", lambda: {})(), indent=2) if self.settings else "{}"
        boot_timeout = getattr(self.settings, "build_boot_timeout_seconds", 15) if self.settings else 15
        is_2d = project_type == "2D"

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{scene_data['name']} - Tantan's Creations</title>
    <style>
        :root {{
            --bg: #231c3d;
            --text: #f7f5ff;
            --muted: #d6d0f2;
            --blue: #4c78e8;
            --purple: #8459e8;
            --pastel-purple: #f0e7ff;
        }}
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        html, body {{ width: 100%; height: 100%; overflow: hidden; background: var(--bg); color: var(--text); font-family: "Segoe UI", sans-serif; }}
        #game-container {{ position: relative; width: 100vw; height: 100vh; overflow: hidden; }}
        canvas {{ display: block; width: 100%; height: 100%; }}

        /* === NON-REMOVABLE LOADING SCREEN === */
        #loading-screen {{
            position: fixed;
            inset: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            gap: 24px;
            background: linear-gradient(180deg, #302252, #17102b);
            z-index: 999999;
            transition: opacity 0.8s ease, visibility 0.8s ease;
        }}
        #loading-screen.hidden {{
            opacity: 0;
            visibility: hidden;
            pointer-events: none;
        }}
        .loading-brand {{
            font-size: 22px;
            font-weight: 700;
            letter-spacing: 2px;
            color: var(--pastel-purple);
            text-shadow: 0 0 20px rgba(132,89,232,0.4);
            text-align: center;
        }}
        .loading-sub {{
            color: var(--muted);
            font-size: 13px;
            text-align: center;
            max-width: 400px;
            line-height: 1.5;
        }}
        .spinner-container {{
            position: relative;
            width: 80px;
            height: 80px;
        }}
        .spinner-dot {{
            position: absolute;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--purple), var(--blue));
            top: 50%;
            left: 50%;
            margin-top: -6px;
            margin-left: -6px;
            animation: orbit 1.2s linear infinite;
            box-shadow: 0 0 8px rgba(132,89,232,0.5);
        }}
        .spinner-dot:nth-child(1) {{ animation-delay: 0s; }}
        .spinner-dot:nth-child(2) {{ animation-delay: -0.24s; }}
        .spinner-dot:nth-child(3) {{ animation-delay: -0.48s; }}
        .spinner-dot:nth-child(4) {{ animation-delay: -0.72s; }}
        .spinner-dot:nth-child(5) {{ animation-delay: -0.96s; }}
        @keyframes orbit {{
            0% {{ transform: rotate(0deg) translateX(30px) rotate(0deg); }}
            100% {{ transform: rotate(360deg) translateX(30px) rotate(-360deg); }}
        }}
        .loading-bar {{
            width: 200px;
            height: 4px;
            background: rgba(255,255,255,0.1);
            border-radius: 2px;
            overflow: hidden;
        }}
        .loading-bar-fill {{
            width: 0%;
            height: 100%;
            background: linear-gradient(90deg, var(--purple), var(--blue));
            border-radius: 2px;
            animation: loadProgress 2s ease-in-out infinite;
        }}
        @keyframes loadProgress {{
            0% {{ width: 0%; }}
            50% {{ width: 70%; }}
            100% {{ width: 100%; }}
        }}
        #stats {{
            position: absolute;
            left: 16px;
            top: 16px;
            z-index: 20;
            padding: 8px 12px;
            border-radius: 999px;
            background: rgba(255,255,255,0.12);
            border: 1px solid rgba(255,255,255,0.15);
            color: var(--text);
            font-size: 12px;
            backdrop-filter: blur(10px);
            font-family: "Segoe UI", sans-serif;
        }}
        #boot-error {{
            position: absolute;
            left: 16px;
            right: 16px;
            bottom: 16px;
            padding: 14px 16px;
            border-radius: 16px;
            background: rgba(255,255,255,0.95);
            color: #2C2742;
            border: 1px solid rgba(142,107,232,0.24);
            font-family: "Segoe UI", sans-serif;
            display: none;
            z-index: 120;
            max-height: 200px;
            overflow-y: auto;
        }}
    </style>
</head>
<body>
    <div id="game-container">
        <canvas id="canvas"></canvas>
        <div id="stats">Booting...</div>
        <div id="loading-screen">
            <div class="spinner-container">
                <div class="spinner-dot"></div>
                <div class="spinner-dot"></div>
                <div class="spinner-dot"></div>
                <div class="spinner-dot"></div>
                <div class="spinner-dot"></div>
            </div>
            <div class="loading-brand">Made with Tantan's Creations Web Engine</div>
            <div class="loading-sub">Loading project, compiling scripts, and preparing the scene...</div>
            <div class="loading-bar"><div class="loading-bar-fill"></div></div>
        </div>
    </div>
    <script>
    (function() {{
    "use strict";

    const IS_2D = {str(is_2d).lower()};
    const SCENE_DATA = {scene_json};
    const SCRIPT_SOURCES = {script_sources_json};
    const PROJECT_SETTINGS = {settings_json};

    const canvas = document.getElementById('canvas');
    const ctx = canvas.getContext('2d');
    const loadingScreen = document.getElementById('loading-screen');
    const statsEl = document.getElementById('stats');
    const errorEl = document.createElement('div');
    errorEl.id = 'boot-error';
    errorEl.innerHTML = '<strong style="font-size:14px;">Engine Boot Failed</strong><div id="boot-error-text" style="margin-top:6px;white-space:pre-wrap;font-size:13px;line-height:1.35;"></div>';
    document.getElementById('game-container').appendChild(errorEl);

    function resizeCanvas() {{
        const dpr = Math.max(1, window.devicePixelRatio || 1);
        const w = window.innerWidth;
        const h = window.innerHeight;
        canvas.width = Math.floor(w * dpr);
        canvas.height = Math.floor(h * dpr);
        canvas.style.width = w + 'px';
        canvas.style.height = h + 'px';
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        return {{ w, h }};
    }}

    class Vector3 {{
        constructor(x=0, y=0, z=0) {{ this.x = x; this.y = y; this.z = z; }}
        add(v) {{ return new Vector3(this.x + v.x, this.y + v.y, this.z + v.z); }}
        subtract(v) {{ return new Vector3(this.x - v.x, this.y - v.y, this.z - v.z); }}
        multiply(v) {{ return v instanceof Vector3 ? new Vector3(this.x * v.x, this.y * v.y, this.z * v.z) : new Vector3(this.x * v, this.y * v, this.z * v); }}
        dot(v) {{ return this.x * v.x + this.y * v.y + this.z * v.z; }}
        normalized() {{ const m = Math.hypot(this.x, this.y, this.z) || 1; return new Vector3(this.x / m, this.y / m, this.z / m); }}
    }}

    const TEngine = {{
        canvas, ctx,
        scene: null,
        entities: new Map(),
        scripts: [],
        time: 0,
        deltaTime: 0,
        fixedDeltaTime: 0.016,
        input: {{
            keys: new Set(),
            mouseDown: false,
            mousePosition: new Vector3(0, 0, 0),
            getKey(key) {{ return this.keys.has(String(key).toLowerCase()); }},
            getButton(name) {{ return this.getKey(name); }},
            getMouseButton(button) {{ return button === 0 ? this.mouseDown : false; }},
            getAxis(name) {{
                name = String(name).toLowerCase();
                const mapping = {{
                    horizontal: [['a', -1], ['arrowleft', -1], ['d', 1], ['arrowright', 1]],
                    vertical: [['s', -1], ['arrowdown', -1], ['w', 1], ['arrowup', 1]],
                }};
                let value = 0;
                for (const [key, amount] of (mapping[name] || [])) {{ if (this.getKey(key)) value += amount; }}
                return Math.max(-1, Math.min(1, value));
            }}
        }},
        mathf: {{ clamp: (v, mn, mx) => Math.min(mx, Math.max(mn, v)), lerp: (a,b,t) => a + (b-a) * t }},
        Vector3,
        findObject(name) {{ for (const ent of this.entities.values()) if (ent.name === name) return ent; return null; }},
        destroy(obj) {{ if (obj && obj.id) this.entities.delete(obj.id); }},
        application: {{ quit() {{}} }},
    }};

    function makeTransform(data) {{
        const pos = new Vector3(data?.position?.x || 0, data?.position?.y || 0, data?.position?.z || 0);
        const rot = new Vector3(data?.rotation?.x || 0, data?.rotation?.y || 0, data?.rotation?.z || 0);
        const scale = new Vector3(data?.scale?.x || 1, data?.scale?.y || 1, data?.scale?.z || 1);
        return {{
            position: pos, rotation: rot, scale,
            translate(x=0, y=0, z=0) {{
                if (x instanceof Vector3) this.position = this.position.add(x);
                else this.position = this.position.add(new Vector3(x, y, z));
                return this;
            }},
            rotate(x=0, y=0, z=0) {{
                if (x instanceof Vector3) this.rotation = this.rotation.add(x);
                else this.rotation = this.rotation.add(new Vector3(x, y, z));
                return this;
            }},
            get forward() {{
                const yaw = this.rotation.y * Math.PI / 180;
                const pitch = this.rotation.x * Math.PI / 180;
                return new Vector3(Math.cos(pitch) * Math.sin(yaw), -Math.sin(pitch), Math.cos(pitch) * Math.cos(yaw)).normalized();
            }},
            get right() {{
                const yaw = (this.rotation.y + 90) * Math.PI / 180;
                return new Vector3(Math.sin(yaw), 0, Math.cos(yaw)).normalized();
            }},
            get up() {{ return new Vector3(0, 1, 0); }},
            lookAt(target) {{
                const t = target instanceof Vector3 ? target : new Vector3(target?.x || 0, target?.y || 0, target?.z || 0);
                const dir = t.subtract(this.position).normalized();
                this.rotation.y = Math.atan2(dir.x, dir.z) * 180 / Math.PI;
                this.rotation.x = Math.atan2(-dir.y, Math.hypot(dir.x, dir.z)) * 180 / Math.PI;
                return this;
            }}
        }};
    }}

    function createEntity(entityData, parent=null) {{
        const entity = {{
            id: entityData.id,
            name: entityData.name,
            active: entityData.active !== false,
            transform: makeTransform(entityData.transform),
            components: entityData.components || [],
            children: [],
            parent,
            getComponent(type) {{
                return this.components.find(c => c.type === type || c.type?.toLowerCase() === String(type).toLowerCase()) || null;
            }}
        }};
        TEngine.entities.set(entity.id, entity);
        for (const child of (entityData.children || [])) {{
            entity.children.push(createEntity(child, entity));
        }}
        return entity;
    }}

    function getMainCamera() {{
        for (const entity of TEngine.entities.values()) {{
            if ((entity.components || []).some(c => c.type === 'Camera')) return entity;
        }}
        return null;
    }}

    function getCameraComponent(cameraEntity) {{
        if (!cameraEntity) return null;
        return cameraEntity.components.find(c => c.type === 'Camera') || null;
    }}

    function degToRad(deg) {{ return deg * Math.PI / 180; }}

    // ========== 3D MATH ==========
    function mat4Multiply(a, b) {{
        const out = new Float32Array(16);
        for (let i = 0; i < 4; i++) {{
            for (let j = 0; j < 4; j++) {{
                out[i * 4 + j] = 0;
                for (let k = 0; k < 4; k++) {{
                    out[i * 4 + j] += a[i * 4 + k] * b[k * 4 + j];
                }}
            }}
        }}
        return out;
    }}

    function lookAt(eye, target, up) {{
        const z = eye.subtract(target).normalized();
        const x = up.cross(z).normalized();
        const y = z.cross(x);  // Fixed: should be z.cross(x) for right-handed
        return new Float32Array([
            x.x, x.y, x.z, -x.dot(eye),
            y.x, y.y, y.z, -y.dot(eye),
            z.x, z.y, z.z, -z.dot(eye),
            0, 0, 0, 1
        ]);
    }}

    function perspective(fovDeg, aspect, near, far) {{
        const f = 1.0 / Math.tan(degToRad(fovDeg) / 2);
        const nf = 1.0 / (near - far);
        return new Float32Array([
            f / aspect, 0, 0, 0,
            0, f, 0, 0,
            0, 0, (far + near) * nf, 2 * far * near * nf,
            0, 0, -1, 0
        ]);
    }}

    function orthographic(size, aspect, near, far) {{
        const r = size * aspect, l = -r, t = size, b = -t;
        return new Float32Array([
            2 / (r - l), 0, 0, -(r + l) / (r - l),
            0, 2 / (t - b), 0, -(t + b) / (t - b),
            0, 0, -2 / (far - near), -(far + near) / (far - near),
            0, 0, 0, 1
        ]);
    }}

    function transformPoint(v, m) {{
        const x = v.x, y = v.y, z = v.z;
        const w = m[3] * x + m[7] * y + m[11] * z + m[15];
        if (w < 0.001) return null;
        return new Vector3(
            (m[0] * x + m[4] * y + m[8] * z + m[12]) / w,
            (m[1] * x + m[5] * y + m[9] * z + m[13]) / w,
            (m[2] * x + m[6] * y + m[10] * z + m[14]) / w
        );
    }}

    function buildViewProj(cameraEntity, w, h) {{
        const camComp = getCameraComponent(cameraEntity);
        const transform = cameraEntity ? cameraEntity.transform : {{ position: new Vector3(0,0,0), rotation: new Vector3(0,0,0) }};
        const eye = transform.position;
        const yaw = degToRad(transform.rotation.y);
        const pitch = degToRad(transform.rotation.x);
        const forward = new Vector3(
            Math.cos(pitch) * Math.sin(yaw),
            -Math.sin(pitch),
            Math.cos(pitch) * Math.cos(yaw)
        );
        const target = eye.add(forward);
        const up = new Vector3(0, 1, 0);
        const view = lookAt(eye, target, up);
        const aspect = w / h;
        let proj;
        if (camComp && camComp.is_orthographic) {{
            proj = orthographic(camComp.orthographic_size || 5, aspect, camComp.near_clip || 0.1, camComp.far_clip || 1000);
        }} else {{
            proj = perspective(camComp ? camComp.fov || 60 : 60, aspect, camComp ? camComp.near_clip || 0.1 : 0.1, camComp ? camComp.far_clip || 1000 : 1000);
        }}
        return mat4Multiply(proj, view);
    }}

    function project3D(pos, viewProj, w, h) {{
        const ndc = transformPoint(pos, viewProj);
        if (!ndc) return null;
        return [
            (ndc.x * 0.5 + 0.5) * w,
            (1.0 - (ndc.y * 0.5 + 0.5)) * h,
            ndc.z
        ];
    }}

    // Cross product for Vector3
    Vector3.prototype.cross = function(v) {{
        return new Vector3(
            this.y * v.z - this.z * v.y,
            this.z * v.x - this.x * v.z,
            this.x * v.y - this.y * v.x
        );
    }};

    // ========== BACKFACE CULLING & PAINTER'S ALGORITHM ==========
    function isBackface(v0, v1, v2) {{
        // Compute cross product of edges to get normal
        const edge1 = {{ x: v1[0] - v0[0], y: v1[1] - v0[1] }};
        const edge2 = {{ x: v2[0] - v0[0], y: v2[1] - v0[1] }};
        const crossZ = edge1.x * edge2.y - edge1.y * edge2.x;
        // In canvas Y-down coordinates, negative Z means facing camera
        return crossZ > 0;
    }}

    function getFaceDepth(faceVerts) {{
        let sum = 0;
        for (const v of faceVerts) sum += v[2];
        return sum / faceVerts.length;
    }}

    // ========== 3D CUBE RENDERING (FIXED) ==========
    function drawCube3D(center, size, viewProj, w, h, selected) {{
        const hx = size.x / 2, hy = size.y / 2, hz = size.z / 2;
        // Vertices: standard cube layout
        const verts = [
            new Vector3(-hx, -hy, -hz), new Vector3( hx, -hy, -hz), new Vector3( hx,  hy, -hz), new Vector3(-hx,  hy, -hz),  // front (z=-hz)
            new Vector3(-hx, -hy,  hz), new Vector3( hx, -hy,  hz), new Vector3( hx,  hy,  hz), new Vector3(-hx,  hy,  hz)   // back (z=hz)
        ];
        const worldVerts = verts.map(v => new Vector3(v.x + center.x, v.y + center.y, v.z + center.z));

        // Faces defined as quads with CCW winding when viewed from OUTSIDE
        // Each face: [v0, v1, v2, v3] where looking from outside, v0->v1->v2 is CCW
        const faces = [
            {{ indices: [0, 1, 2, 3], name: "front",  color: 'rgba(210,210,220,0.9)' }},   // front face  (z=-hz), CCW from outside
            {{ indices: [5, 4, 7, 6], name: "back",   color: 'rgba(160,160,170,0.9)' }},   // back face   (z=+hz), CCW from outside
            {{ indices: [4, 0, 3, 7], name: "left",   color: 'rgba(180,180,190,0.9)' }},   // left face   (x=-hx), CCW from outside
            {{ indices: [1, 5, 6, 2], name: "right",  color: 'rgba(190,190,200,0.9)' }},   // right face  (x=+hx), CCW from outside
            {{ indices: [3, 2, 6, 7], name: "top",    color: 'rgba(200,200,210,0.9)' }},   // top face    (y=+hy), CCW from outside
            {{ indices: [4, 5, 1, 0], name: "bottom", color: 'rgba(170,170,180,0.9)' }}    // bottom face (y=-hy), CCW from outside
        ];

        // Project all vertices first
        const projected = [];
        for (let i = 0; i < worldVerts.length; i++) {{
            projected[i] = project3D(worldVerts[i], viewProj, w, h);
        }}

        // Build face data with depth for sorting
        const faceData = [];
        for (let fi = 0; fi < faces.length; fi++) {{
            const face = faces[fi];
            const screenVerts = [];
            let valid = true;
            for (const idx of face.indices) {{
                const sv = projected[idx];
                if (!sv) {{ valid = false; break; }}
                screenVerts.push(sv);
            }}
            if (!valid || screenVerts.length < 3) continue;

            // Backface culling: skip if facing away
            if (isBackface(screenVerts[0], screenVerts[1], screenVerts[2])) continue;

            const depth = getFaceDepth(screenVerts);
            faceData.push({{ verts: screenVerts, depth, color: face.color, face }});
        }}

        // Painter's algorithm: sort back-to-front (farther first = smaller depth value drawn first)
        // Actually in NDC, smaller z = closer. So we want to draw larger z (farther) first.
        faceData.sort((a, b) => b.depth - a.depth);

        // Draw faces back-to-front
        for (const fd of faceData) {{
            ctx.save();
            ctx.fillStyle = selected ? '#f0e7ff' : fd.color;
            ctx.strokeStyle = selected ? '#4c78e8' : 'rgba(255,255,255,0.3)';
            ctx.lineWidth = selected ? 2 : 1;
            ctx.beginPath();
            ctx.moveTo(fd.verts[0][0], fd.verts[0][1]);
            for (let i = 1; i < fd.verts.length; i++) {{
                ctx.lineTo(fd.verts[i][0], fd.verts[i][1]);
            }}
            ctx.closePath();
            ctx.fill();
            ctx.stroke();
            ctx.restore();
        }}
    }}

    function drawGrid3D(viewProj, w, h) {{
        ctx.save();
        ctx.globalAlpha = 0.18;
        ctx.strokeStyle = '#cfc3ee';
        ctx.lineWidth = 1;
        const size = 20, spacing = 1.0;
        const half = Math.floor(size / 2);
        for (let i = -half; i <= half; i++) {{
            const p1 = project3D(new Vector3(i * spacing, 0, -half * spacing), viewProj, w, h);
            const p2 = project3D(new Vector3(i * spacing, 0, half * spacing), viewProj, w, h);
            if (p1 && p2) {{
                ctx.beginPath(); ctx.moveTo(p1[0], p1[1]); ctx.lineTo(p2[0], p2[1]); ctx.stroke();
            }}
            const p3 = project3D(new Vector3(-half * spacing, 0, i * spacing), viewProj, w, h);
            const p4 = project3D(new Vector3(half * spacing, 0, i * spacing), viewProj, w, h);
            if (p3 && p4) {{
                ctx.beginPath(); ctx.moveTo(p3[0], p3[1]); ctx.lineTo(p4[0], p4[1]); ctx.stroke();
            }}
        }}
        ctx.restore();
    }}

    function drawEntity3D(entity, viewProj, w, h) {{
        if (!entity.active) return;
        const sprite = entity.components.find(c => c.type === 'SpriteRenderer');
        const meshFilter = entity.components.find(c => c.type === 'MeshFilter');
        const meshRenderer = entity.components.find(c => c.type === 'MeshRenderer');
        const light = entity.components.find(c => c.type === 'Light');
        const selected = entity.name === (TEngine.selectedName || '');
        const pos = entity.transform.position;
        const scale = entity.transform.scale;

        if (meshFilter || meshRenderer) {{
            drawCube3D(pos, scale, viewProj, w, h, selected);
        }} else if (sprite) {{
            const sp = project3D(pos, viewProj, w, h);
            if (!sp) return;
            const col = sprite.color || {{ r: 1, g: 1, b: 1, a: 1 }};
            const alpha = col.a !== undefined ? col.a : 1;
            const s = Math.max(10, 30 / Math.max(0.1, sp[2] + 1));
            ctx.save();
            ctx.fillStyle = `rgba(${{Math.round(col.r * 255)}}, ${{Math.round(col.g * 255)}}, ${{Math.round(col.b * 255)}}, ${{alpha}})`;
            ctx.strokeStyle = selected ? '#4c78e8' : 'rgba(255,255,255,0.4)';
            ctx.lineWidth = selected ? 3 : 1;
            ctx.beginPath();
            ctx.roundRect(sp[0] - s, sp[1] - s, s * 2, s * 2, 6);
            ctx.fill();
            ctx.stroke();
            ctx.restore();
        }} else if (light) {{
            const sp = project3D(pos, viewProj, w, h);
            if (!sp) return;
            ctx.save();
            ctx.fillStyle = '#ffd97a';
            ctx.beginPath();
            ctx.arc(sp[0], sp[1], 8, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
        }} else {{
            const sp = project3D(pos, viewProj, w, h);
            if (!sp) return;
            ctx.save();
            ctx.fillStyle = selected ? '#4c78e8' : '#ffffff';
            ctx.beginPath();
            ctx.arc(sp[0], sp[1], 5, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
        }}

        // Draw label
        const sp = project3D(pos, viewProj, w, h);
        if (sp) {{
            ctx.save();
            ctx.fillStyle = '#f7f5ff';
            ctx.font = '12px Segoe UI, sans-serif';
            ctx.fillText(entity.name, sp[0] + 10, sp[1] - 10);
            ctx.restore();
        }}
    }}

    // ========== 2D RENDERING ==========
    function drawEntity2D(entity, w, h) {{
        if (!entity.active) return;
        const sprite = entity.components.find(c => c.type === 'SpriteRenderer');
        const pos = entity.transform.position;
        const scale = entity.transform.scale;
        const selected = entity.name === (TEngine.selectedName || '');

        // In 2D, z is used for sorting order (layering)
        // Position is in world units, convert to screen pixels
        // Assume 1 world unit = 50 pixels, center at screen center
        const pixelsPerUnit = 50;
        const screenX = w / 2 + pos.x * pixelsPerUnit;
        const screenY = h / 2 - pos.y * pixelsPerUnit;  // Y is up in world, down on screen
        const sizeX = Math.abs(scale.x) * pixelsPerUnit;
        const sizeY = Math.abs(scale.y) * pixelsPerUnit;

        if (sprite) {{
            const col = sprite.color || {{ r: 1, g: 1, b: 1, a: 1 }};
            const alpha = col.a !== undefined ? col.a : 1;
            ctx.save();
            ctx.fillStyle = `rgba(${{Math.round(col.r * 255)}}, ${{Math.round(col.g * 255)}}, ${{Math.round(col.b * 255)}}, ${{alpha}})`;
            ctx.strokeStyle = selected ? '#4c78e8' : 'rgba(255,255,255,0.4)';
            ctx.lineWidth = selected ? 3 : 1;
            ctx.translate(screenX, screenY);
            // Apply rotation around Z axis
            ctx.rotate(-entity.transform.rotation.z * Math.PI / 180);
            ctx.beginPath();
            ctx.roundRect(-sizeX / 2, -sizeY / 2, sizeX, sizeY, 4);
            ctx.fill();
            ctx.stroke();
            ctx.restore();
        }} else {{
            // Default: draw a circle for entities without sprite
            ctx.save();
            ctx.fillStyle = selected ? '#4c78e8' : '#ffffff';
            ctx.beginPath();
            ctx.arc(screenX, screenY, Math.max(5, sizeX / 4), 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
        }}

        // Draw label
        ctx.save();
        ctx.fillStyle = '#f7f5ff';
        ctx.font = '12px Segoe UI, sans-serif';
        ctx.fillText(entity.name, screenX + 10, screenY - 10);
        ctx.restore();
    }}

    function drawGrid2D(w, h) {{
        ctx.save();
        ctx.globalAlpha = 0.15;
        ctx.strokeStyle = '#cfc3ee';
        ctx.lineWidth = 1;
        const pixelsPerUnit = 50;
        const offsetX = w / 2;
        const offsetY = h / 2;
        const size = 20;
        const half = Math.floor(size / 2);
        for (let i = -half; i <= half; i++) {{
            const x = offsetX + i * pixelsPerUnit;
            ctx.beginPath(); ctx.moveTo(x, offsetY - half * pixelsPerUnit); ctx.lineTo(x, offsetY + half * pixelsPerUnit); ctx.stroke();
            const y = offsetY - i * pixelsPerUnit;
            ctx.beginPath(); ctx.moveTo(offsetX - half * pixelsPerUnit, y); ctx.lineTo(offsetX + half * pixelsPerUnit, y); ctx.stroke();
        }}
        ctx.restore();
    }}

    // ========== MAIN RENDER ==========
    function renderScene() {{
        const {{ w, h }} = resizeCanvas();
        ctx.clearRect(0, 0, w, h);
        const camera = getMainCamera();
        const camComp = getCameraComponent(camera);

        if (IS_2D) {{
            // ===== 2D RENDERING =====
            const clearColor = camComp ? camComp.clear_color : {{ r: 0.1, g: 0.1, b: 0.15, a: 1 }};
            ctx.fillStyle = `rgb(${{Math.round(clearColor.r * 255)}}, ${{Math.round(clearColor.g * 255)}}, ${{Math.round(clearColor.b * 255)}})`;
            ctx.fillRect(0, 0, w, h);

            if (PROJECT_SETTINGS && PROJECT_SETTINGS.editor && PROJECT_SETTINGS.editor.show_grid !== false)
                drawGrid2D(w, h);

            // Sort entities by Z for proper 2D layering
            const entities = Array.from(TEngine.entities.values());
            entities.sort((a, b) => (a.transform.position.z || 0) - (b.transform.position.z || 0));
            for (const entity of entities) drawEntity2D(entity, w, h);
        }} else {{
            // ===== 3D RENDERING =====
            const clearColor = camComp ? camComp.clear_color : {{ r: 0.15, g: 0.15, b: 0.18, a: 1 }};
            ctx.fillStyle = `rgb(${{Math.round(clearColor.r * 255)}}, ${{Math.round(clearColor.g * 255)}}, ${{Math.round(clearColor.b * 255)}})`;
            ctx.fillRect(0, 0, w, h);

            const viewProj = buildViewProj(camera, w, h);
            if (PROJECT_SETTINGS && PROJECT_SETTINGS.editor && PROJECT_SETTINGS.editor.show_grid !== false)
                drawGrid3D(viewProj, w, h);

            // Sort entities by distance from camera for proper layering
            const entities = Array.from(TEngine.entities.values());
            const camPos = camera ? camera.transform.position : new Vector3(0, 0, 0);
            entities.sort((a, b) => {{
                const da = a.transform.position.subtract(camPos);
                const db = b.transform.position.subtract(camPos);
                return (db.x*db.x + db.y*db.y + db.z*db.z) - (da.x*da.x + da.y*da.y + da.z*da.z);
            }});
            for (const entity of entities) drawEntity3D(entity, viewProj, w, h);
        }}
    }}

    // ========== SCRIPTS ==========
    function compileScripts() {{
        TEngine.scripts.length = 0;
        for (const scriptDef of SCRIPT_SOURCES) {{
            try {{
                const entity = Array.from(TEngine.entities.values()).find(e => e.name === scriptDef.entity) || null;
                if (!entity) continue;
                const api = {{
                    entity,
                    transform: entity.transform,
                    properties: scriptDef.properties || {{}},
                    Vector3,
                    print: (...args) => console.log(`[${{scriptDef.entity}}]`, ...args),
                    findObject: (name) => TEngine.findObject(name),
                    destroy: (obj) => TEngine.destroy(obj)
                }};
                const source = String(scriptDef.code || '');
                const factory = new Function('api', 'TEngine', 'Vector3', 'source', `
                    const {{ entity, transform, properties, print, findObject, destroy }} = api;
                    let Start = null;
                    let Update = null;
                    let FixedUpdate = null;
                    eval(source);
                    return {{
                        Start: typeof Start === 'function' ? Start : null,
                        Update: typeof Update === 'function' ? Update : null,
                        FixedUpdate: typeof FixedUpdate === 'function' ? FixedUpdate : null
                    }};
                `);
                const instance = factory(api, TEngine, Vector3, source);
                if (instance.Start || instance.Update || instance.FixedUpdate) {{
                    TEngine.scripts.push({{ api, ...instance, started: false, name: scriptDef.entity }});
                }}
            }} catch (err) {{
                console.warn(`Script failed for ${{scriptDef.entity}}:`, err);
            }}
        }}
    }}

    function bootError(message) {{
        const text = document.getElementById('boot-error-text');
        if (text) text.textContent = String(message || 'Unknown error');
        errorEl.style.display = 'block';
        loadingScreen.classList.add('hidden');
        statsEl.textContent = 'Boot failed';
    }}

    function boot() {{
        try {{
            resizeCanvas();
            TEngine.scene = SCENE_DATA;
            if (!SCENE_DATA || !SCENE_DATA.entities) {{
                throw new Error('Scene data is missing or corrupted. Check build output.');
            }}
            for (const root of SCENE_DATA.entities) createEntity(root, null);
            compileScripts();
            for (const script of TEngine.scripts) {{
                try {{ if (script.Start) script.Start.call(script.api); script.started = true; }} catch (err) {{ console.warn(`Start() error on ${{script.name}}:`, err); }}
            }}
            setTimeout(() => {{ loadingScreen.classList.add('hidden'); }}, 1500);
            statsEl.textContent = 'Ready';
            animate();
        }} catch (err) {{
            bootError(err?.stack || err?.message || String(err));
        }}
    }}

    function animate() {{
        requestAnimationFrame(animate);
        const now = performance.now();
        const dt = Math.min(0.05, (now - (TEngine._lastTime || now)) / 1000);
        TEngine._lastTime = now;
        TEngine.deltaTime = dt;
        TEngine.time += dt;

        for (const script of TEngine.scripts) {{
            try {{ if (script.Update) script.Update.call(script.api); }} catch (err) {{ console.warn(`Update() error on ${{script.name}}:`, err); }}
        }}

        renderScene();
        TEngine.frameCount = (TEngine.frameCount || 0) + 1;
        if (!TEngine._fpsStart) TEngine._fpsStart = now;
        if (now - TEngine._fpsStart >= 1000) {{
            const fps = Math.round(TEngine.frameCount * 1000 / (now - TEngine._fpsStart));
            statsEl.textContent = `FPS: ${{fps}} | Entities: ${{TEngine.entities.size}}`;
            TEngine.frameCount = 0;
            TEngine._fpsStart = now;
        }}
    }}

    window.addEventListener('resize', resizeCanvas);
    window.addEventListener('error', (event) => {{ bootError(event.error?.stack || event.message || 'Unexpected error during boot.'); }});
    window.addEventListener('unhandledrejection', (event) => {{ bootError(event.reason?.stack || event.reason || 'Unhandled promise rejection during boot.'); }});
    window.addEventListener('keydown', (e) => TEngine.input.keys.add(e.key.toLowerCase()));
    window.addEventListener('keyup', (e) => TEngine.input.keys.delete(e.key.toLowerCase()));
    window.addEventListener('mousemove', (e) => {{ TEngine.input.mousePosition.x = e.clientX; TEngine.input.mousePosition.y = e.clientY; }});
    window.addEventListener('mousedown', () => TEngine.input.mouseDown = true);
    window.addEventListener('mouseup', () => TEngine.input.mouseDown = false);

    const loadWatchdog = setTimeout(() => {{ if (!TEngine._booted) bootError('Boot timed out after ' + {int(boot_timeout)} + ' seconds.'); }}, Math.max(5, {int(boot_timeout)}) * 1000);

    if (document.readyState === 'loading') {{
        document.addEventListener('DOMContentLoaded', () => {{ TEngine._booted = true; clearTimeout(loadWatchdog); boot(); }});
    }} else {{
        TEngine._booted = true; clearTimeout(loadWatchdog); setTimeout(boot, 50);
    }}
    }})();
    </script>
</body>
</html>"""

        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)

        return output_path

    def _build_standard_web(self, scene_data: dict, script_sources, asset_data: dict, name: str, project_type: str) -> Path:
        """Build standard web output (HTML + JS + Data files)."""
        return self._build_single_html(scene_data, script_sources, asset_data, name, project_type)
