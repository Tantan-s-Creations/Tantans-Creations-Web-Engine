"""Console / log output panel"""
import tkinter as tk
from tkinter import ttk
from datetime import datetime

from ..core.theme import PALETTE


class ConsolePanel(ttk.Frame):
    """Log console with filtering."""
    def __init__(self, parent, engine, **kwargs):
        super().__init__(parent, **kwargs)
        self.engine = engine

        toolbar = ttk.Frame(self)
        toolbar.pack(fill=tk.X, pady=2)

        self.filter_var = tk.StringVar(value="All")
        ttk.Combobox(toolbar, textvariable=self.filter_var, values=["All", "Info", "Warning", "Error", "Script"],
                    state="readonly", width=10).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="🗑 Clear", command=self.clear).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="📋 Copy", command=self.copy).pack(side=tk.LEFT, padx=2)

        self.text = tk.Text(
            self,
            wrap=tk.WORD,
            state="disabled",
            font=("Consolas", 10),
            bg=PALETTE["surface"],
            fg=PALETTE["text"],
            insertbackground=PALETTE["text"],
            relief="solid",
            bd=1,
            highlightthickness=0,
        )
        self.text.pack(fill=tk.BOTH, expand=True, pady=(2, 0))

        scrollbar = ttk.Scrollbar(self.text, orient="vertical", command=self.text.yview)
        self.text.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.text.tag_configure("info", foreground=PALETTE["blue"])
        self.text.tag_configure("warning", foreground=PALETTE["warning"])
        self.text.tag_configure("error", foreground=PALETTE["error"])
        self.text.tag_configure("script", foreground=PALETTE["green"])
        self.text.tag_configure("timestamp", foreground=PALETTE["purple"])

        self.logs = []

    def log(self, message, level="info"):
        timestamp = datetime.now().strftime("%H:%M:%S")
        entry = {"time": timestamp, "message": str(message), "level": level}
        self.logs.append(entry)

        self.text.config(state="normal")
        self.text.insert(tk.END, f"[{timestamp}] ", "timestamp")
        self.text.insert(tk.END, f"{message}\n", level)
        self.text.see(tk.END)
        self.text.config(state="disabled")

    def clear(self):
        self.text.config(state="normal")
        self.text.delete("1.0", tk.END)
        self.text.config(state="disabled")
        self.logs.clear()

    def copy(self):
        self.clipboard_clear()
        text = "\n".join(f"[{l['time']}] {l['message']}" for l in self.logs)
        self.clipboard_append(text)
