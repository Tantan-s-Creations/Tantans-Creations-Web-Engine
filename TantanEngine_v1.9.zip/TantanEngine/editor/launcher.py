"""Startup launcher for browsing and creating projects."""
from __future__ import annotations

import json
import os
import time
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from ..core.project import Project
from ..core.theme import apply_theme, PALETTE, get_font_family


RECENTS_FILE = Path.home() / ".tantan_engine_recent_projects.json"


class ProjectWizardDialog(tk.Toplevel):
    """Project creation wizard used by the launcher and editor."""

    def __init__(self, parent):
        super().__init__(parent)
        self.title("Create Project")
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()
        self.result = None

        self._theme = apply_theme(self)
        self.configure(background=PALETTE["bg"])

        font_family = get_font_family(self)

        frame = tk.Frame(self, bg=PALETTE["bg"], bd=4, relief="solid",
                         highlightbackground=PALETTE["border"], highlightthickness=4)
        frame.pack(fill=tk.BOTH, expand=True, padx=12, pady=12)

        inner = ttk.Frame(frame, padding=18)
        inner.pack(fill=tk.BOTH, expand=True)

        tk.Label(inner, text="New Project", bg=PALETTE["bg"], fg=PALETTE["heading"],
                font=(font_family, 13, "bold")).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 8))
        tk.Label(inner, text="Create a project, choose a template, and set the startup scene.",
                bg=PALETTE["bg"], fg=PALETTE["muted"], font=(font_family, 9)).grid(row=1, column=0, columnspan=3, sticky="w", pady=(0, 10))

        self.name_var = tk.StringVar(value="MyGame")
        self.location_var = tk.StringVar(value=str(Path.home() / "TantanEngine Projects"))
        self.type_var = tk.StringVar(value="3D")
        self.template_var = tk.StringVar(value="3D FPS")
        self.scene_var = tk.StringVar(value="MainScene")
        self.company_var = tk.StringVar(value="Tantan's Creations")
        self.product_var = tk.StringVar(value="My Game")
        self.description_var = tk.StringVar(value="")

        self._field(inner, 2, "Project name", self.name_var)
        self._field(inner, 3, "Location", self.location_var, browse=True)
        self._combo(inner, 4, "Project type", self.type_var, ["2D", "3D", "Hybrid"])
        self._combo(inner, 5, "Template", self.template_var, ["Empty", "2D Platformer", "3D FPS"])
        self._field(inner, 6, "Startup scene", self.scene_var)
        self._field(inner, 7, "Company", self.company_var)
        self._field(inner, 8, "Product", self.product_var)
        self._field(inner, 9, "Description", self.description_var)

        button_row = ttk.Frame(inner)
        button_row.grid(row=10, column=0, columnspan=3, sticky="e", pady=(14, 0))
        ttk.Button(button_row, text="Cancel", command=self._cancel).pack(side=tk.RIGHT, padx=(8, 0))
        ttk.Button(button_row, text="Create", style="Success.TButton", command=self._confirm).pack(side=tk.RIGHT)

        self.bind("<Return>", lambda e: self._confirm())
        self.bind("<Escape>", lambda e: self._cancel())
        self.protocol("WM_DELETE_WINDOW", self._cancel)

        inner.columnconfigure(1, weight=1)
        self.update_idletasks()
        self.geometry(f"{min(580, self.winfo_reqwidth())}x{self.winfo_reqheight()}")

    def _field(self, parent, row, label, variable, browse=False):
        font_family = get_font_family(self)
        tk.Label(parent, text=f"{label}:", bg=PALETTE["bg"], fg=PALETTE["text"],
                font=(font_family, 9)).grid(row=row, column=0, sticky="w", pady=5, padx=(0, 10))
        entry = ttk.Entry(parent, textvariable=variable, width=42)
        entry.grid(row=row, column=1, sticky="ew", pady=5)
        if browse:
            ttk.Button(parent, text="Browse", command=self._browse).grid(row=row, column=2, sticky="e", padx=(8, 0))
        parent.columnconfigure(1, weight=1)

    def _combo(self, parent, row, label, variable, values):
        font_family = get_font_family(self)
        tk.Label(parent, text=f"{label}:", bg=PALETTE["bg"], fg=PALETTE["text"],
                font=(font_family, 9)).grid(row=row, column=0, sticky="w", pady=5, padx=(0, 10))
        box = ttk.Combobox(parent, textvariable=variable, values=values, state="readonly")
        box.grid(row=row, column=1, columnspan=2, sticky="ew", pady=5)

    def _browse(self):
        path = filedialog.askdirectory(title="Choose project folder")
        if path:
            self.location_var.set(path)

    def _confirm(self):
        name = self.name_var.get().strip()
        location = self.location_var.get().strip()
        if not name:
            messagebox.showwarning("Create Project", "Project name is required.", parent=self)
            return
        if not location:
            messagebox.showwarning("Create Project", "Project location is required.", parent=self)
            return
        self.result = {
            "name": name,
            "location": location,
            "project_type": self.type_var.get(),
            "template": self.template_var.get(),
            "scene_name": self.scene_var.get().strip() or "MainScene",
            "company": self.company_var.get().strip() or "Tantan's Creations",
            "product": self.product_var.get().strip() or name,
            "description": self.description_var.get().strip(),
        }
        self.destroy()

    def _cancel(self):
        self.result = None
        self.destroy()


class ProjectCard(tk.Frame):
    """Polished Unity-style project card widget with 4px borders."""
    def __init__(self, parent, project_info, on_open, on_remove=None, **kwargs):
        super().__init__(parent, bg=PALETTE["surface"], bd=4, relief="solid",
                         highlightbackground=PALETTE["border"], highlightthickness=4, **kwargs)
        self.project_info = project_info
        self.on_open = on_open
        self.on_remove = on_remove

        font_family = get_font_family(parent)

        # Thumbnail / icon area with border
        thumb_frame = tk.Frame(self, bg=PALETTE["surface_alt"], bd=2, relief="solid",
                               highlightbackground=PALETTE["border"], highlightthickness=2)
        thumb_frame.pack(fill=tk.X, pady=(8, 8), padx=8)
        thumb_frame.pack_propagate(False)
        thumb_frame.configure(width=180, height=120)

        ptype = project_info.get("project_type", "3D")
        type_colors = {"2D": "#5fb85f", "3D": "#674ea7", "Hybrid": "#8459e8"}
        bg_color = type_colors.get(ptype, "#674ea7")

        thumb_canvas = tk.Canvas(thumb_frame, bg=bg_color, highlightthickness=0)
        thumb_canvas.pack(fill=tk.BOTH, expand=True)
        thumb_canvas.create_text(90, 60, text=ptype, fill="white",
                                font=(font_family, 24, "bold"))

        # Project name
        name = project_info.get("display_name", "Unknown")
        tk.Label(self, text=name, bg=PALETTE["surface"], fg=PALETTE["heading"],
                font=(font_family, 11, "bold")).pack(anchor="w", padx=8)

        # Path
        path = project_info.get("path", "")
        tk.Label(self, text=path, bg=PALETTE["surface"], fg=PALETTE["muted"],
                font=(font_family, 8)).pack(anchor="w", padx=8, pady=(2, 0))

        # Last opened
        last_opened = project_info.get("last_opened", "")
        if last_opened:
            tk.Label(self, text=f"Last opened: {last_opened}",
                    bg=PALETTE["surface"], fg=PALETTE["muted"],
                    font=(font_family, 8)).pack(anchor="w", padx=8, pady=(2, 0))

        # Buttons with 4px border
        btn_frame = tk.Frame(self, bg=PALETTE["surface"])
        btn_frame.pack(fill=tk.X, pady=(8, 8), padx=8)

        open_btn = tk.Button(btn_frame, text="Open", bg=PALETTE["blue_soft"], fg=PALETTE["heading"],
                            font=(font_family, 9), bd=2, relief="raised",
                            activebackground=PALETTE["pastel_blue"],
                            command=lambda: self.on_open(path))
        open_btn.pack(side=tk.LEFT, padx=(0, 4))

        if self.on_remove:
            rem_btn = tk.Button(btn_frame, text="Remove", bg=PALETTE["surface_alt"],
                               fg=PALETTE["text"], font=(font_family, 9), bd=2, relief="raised",
                               activebackground=PALETTE["blue_soft"],
                               command=lambda: self.on_remove(path))
            rem_btn.pack(side=tk.LEFT)


class ProjectLauncher(tk.Tk):
    """Polished Unity-style startup window with 4px borders and Bungee font."""

    def __init__(self):
        super().__init__()
        self.title("Tantan's Creations Web Engine v1.9")
        self.geometry("1200x800")
        self.minsize(900, 600)

        self._theme = apply_theme(self)
        self.configure(background=PALETTE["bg"])

        # Ensure Bungee font is loaded
        self._font_family = get_font_family(self)

        self.recents = self._load_recents()
        self._build_ui()
        self._refresh_projects()

        self.protocol("WM_DELETE_WINDOW", self.destroy)

    def _build_ui(self):
        font_family = self._font_family

        # Top toolbar with 4px border
        toolbar = tk.Frame(self, bg=PALETTE["bg"], bd=4, relief="solid",
                          highlightbackground=PALETTE["border"], highlightthickness=4)
        toolbar.pack(fill=tk.X, padx=12, pady=(12, 6))

        tk.Label(toolbar, text="Tantan's Creations Web Engine",
                bg=PALETTE["bg"], fg=PALETTE["heading"],
                font=(font_family, 18, "bold")).pack(side=tk.LEFT, padx=10, pady=8)

        new_btn = tk.Button(toolbar, text="New Project", bg=PALETTE["success_soft"],
                           fg=PALETTE["success"], font=(font_family, 10, "bold"),
                           bd=2, relief="raised", activebackground="#b5e8d0",
                           command=self.create_project)
        new_btn.pack(side=tk.RIGHT, padx=(0, 10), pady=8)

        open_btn = tk.Button(toolbar, text="Open Project...", bg=PALETTE["blue_soft"],
                            fg=PALETTE["heading"], font=(font_family, 10),
                            bd=2, relief="raised", activebackground=PALETTE["pastel_blue"],
                            command=self.open_project_dialog)
        open_btn.pack(side=tk.RIGHT, padx=(0, 8), pady=8)

        refresh_btn = tk.Button(toolbar, text="Refresh", bg=PALETTE["surface"],
                               fg=PALETTE["text"], font=(font_family, 10),
                               bd=2, relief="raised", activebackground=PALETTE["blue_soft"],
                               command=self.refresh_projects)
        refresh_btn.pack(side=tk.RIGHT, padx=(0, 8), pady=8)

        # Notebook with 4px border
        notebook_frame = tk.Frame(self, bg=PALETTE["bg"], bd=4, relief="solid",
                                 highlightbackground=PALETTE["border"], highlightthickness=4)
        notebook_frame.pack(fill=tk.BOTH, expand=True, padx=12, pady=(6, 12))

        self.notebook = ttk.Notebook(notebook_frame, padding=(10, 8))
        self.notebook.pack(fill=tk.BOTH, expand=True)

        # Recent Projects tab
        self.recent_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.recent_frame, text="Recent Projects")

        # All Projects tab
        self.all_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.all_frame, text="All Projects")

        # Build scrollable grid for both tabs
        self._build_scrollable_grid(self.recent_frame, "recent")
        self._build_scrollable_grid(self.all_frame, "all")

    def _build_scrollable_grid(self, parent, tag):
        """Build a scrollable grid of project cards."""
        canvas = tk.Canvas(parent, bg=PALETTE["bg"], highlightthickness=0)
        scrollbar = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)

        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Container frame inside canvas - this will hold the grid
        container = tk.Frame(canvas, bg=PALETTE["bg"])
        canvas_window = canvas.create_window((0, 0), window=container, anchor="nw", width=parent.winfo_width())

        # Store references
        setattr(self, f"_{tag}_canvas", canvas)
        setattr(self, f"_{tag}_container", container)
        setattr(self, f"_{tag}_window", canvas_window)

        # Mouse wheel scrolling
        def on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        canvas.bind("<MouseWheel>", on_mousewheel)
        container.bind("<MouseWheel>", on_mousewheel)

        def on_configure(event):
            canvas.configure(scrollregion=canvas.bbox("all"))
            canvas.itemconfig(canvas_window, width=event.width)
        container.bind("<Configure>", on_configure)
        canvas.bind("<Configure>", lambda e: canvas.itemconfig(canvas_window, width=e.width))

    def _load_recents(self):
        if RECENTS_FILE.exists():
            try:
                data = json.loads(RECENTS_FILE.read_text(encoding="utf-8"))
                if isinstance(data, list):
                    return [str(Path(p)) for p in data if p]
            except Exception:
                pass
        return []

    def _save_recents(self):
        RECENTS_FILE.parent.mkdir(parents=True, exist_ok=True)
        RECENTS_FILE.write_text(json.dumps(self.recents[:12], indent=2), encoding="utf-8")

    def _remember_project(self, path: str):
        norm = str(Path(path))
        self.recents = [p for p in self.recents if p != norm]
        self.recents.insert(0, norm)
        self._save_recents()

    def _remove_from_recents(self, path: str):
        norm = str(Path(path))
        self.recents = [p for p in self.recents if p != norm]
        self._save_recents()
        self._refresh_projects()

    def _get_project_info(self, path: str) -> dict:
        """Get project info from a path."""
        proj_path = Path(path)
        info = {
            "path": str(path),
            "display_name": proj_path.name,
            "project_type": "3D",
            "last_opened": "",
        }
        manifest = proj_path / "Project.tcproj"
        if manifest.exists():
            try:
                data = json.loads(manifest.read_text(encoding="utf-8"))
                info["display_name"] = data.get("name", proj_path.name)
                settings = data.get("settings", {})
                info["project_type"] = settings.get("project_type", "3D")
            except Exception:
                pass
        try:
            mtime = proj_path.stat().st_mtime
            info["last_opened"] = time.strftime("%Y-%m-%d %H:%M", time.localtime(mtime))
        except Exception:
            pass
        return info

    def _refresh_projects(self):
        """Refresh both project grids."""
        self._fill_grid("recent", self.recents)
        self._fill_grid("all", self.recents)

    def _fill_grid(self, tag, project_paths):
        container = getattr(self, f"_{tag}_container")
        font_family = self._font_family

        # Clear existing cards
        for widget in container.winfo_children():
            widget.destroy()

        if not project_paths:
            msg = tk.Label(container, text="No projects found. Click 'New Project' to create one.",
                          bg=PALETTE["bg"], fg=PALETTE["muted"], font=(font_family, 10))
            msg.pack(pady=40)
            return

        # Create grid of cards (3 columns)
        row, col = 0, 0
        for path in project_paths:
            info = self._get_project_info(path)
            card = ProjectCard(
                container, info,
                on_open=self.launch_editor,
                on_remove=self._remove_from_recents if tag == "recent" else None
            )
            card.grid(row=row, column=col, padx=8, pady=8, sticky="nw")
            col += 1
            if col >= 3:
                col = 0
                row += 1

        for c in range(3):
            container.columnconfigure(c, weight=1, uniform="col")

    def refresh_projects(self):
        self.recents = self._load_recents()
        self._refresh_projects()

    def open_project_dialog(self):
        path = filedialog.askdirectory(title="Open Project Folder")
        if path:
            self.launch_editor(path)

    def create_project(self):
        dialog = ProjectWizardDialog(self)
        self.wait_window(dialog)
        if not dialog.result:
            return

        info = dialog.result
        project_path = Path(info["location"]) / info["name"]

        if project_path.exists():
            if not messagebox.askyesno("Project Exists",
                f'Folder "{project_path}" already exists.\nOverwrite existing project?', parent=self):
                return
            try:
                import shutil
                shutil.rmtree(str(project_path), ignore_errors=True)
            except Exception:
                pass

        try:
            parent = project_path.parent
            for attempt in range(5):
                try:
                    parent.mkdir(parents=True, exist_ok=True)
                    break
                except PermissionError:
                    if attempt < 4:
                        import time
                        time.sleep(0.1 * (attempt + 1))
                    else:
                        raise

            project = Project(str(project_path))
            project.settings.project_type = info["project_type"]
            project.settings.company_name = info["company"]
            project.settings.product_name = info["product"]
            project.settings.project_description = info.get("description", "")

            template_map = {
                "Empty": "empty",
                "2D Platformer": "2d",
                "3D FPS": "3d",
            }
            scene_path = project.create_scene(
                info["scene_name"],
                template=template_map.get(info["template"], "empty"),
                set_active=True
            )
            project.settings.startup_scene = scene_path
            project.set_start_scene(scene_path)
            project.save()

            self._remember_project(str(project_path))
            self.launch_editor(str(project_path))
        except PermissionError as exc:
            messagebox.showerror("Create Project",
                f"Access denied creating project.\n\n"
                f"Try one of these solutions:\n"
                f"1. Run the engine as Administrator\n"
                f"2. Choose a different location (e.g., Documents folder)\n"
                f"3. Check if antivirus is blocking file creation\n\n"
                f"Error: {exc}")
        except Exception as exc:
            messagebox.showerror("Create Project", f"Failed to create project:\n{exc}")

    def launch_editor(self, project_path: str):
        self._remember_project(project_path)
        self.destroy()

        from .main_window import MainWindow
        app = MainWindow(project_path=project_path)
        app.run()

    def run(self):
        self.mainloop()
