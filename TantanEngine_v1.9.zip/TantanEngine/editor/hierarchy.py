"""Scene hierarchy panel with drag-and-drop parenting."""
import tkinter as tk
from tkinter import ttk, messagebox
from ..core.ecs import Entity, Transform

class HierarchyPanel(ttk.Frame):
    """Scene hierarchy tree view with drag-and-drop parenting."""
    def __init__(self, parent, engine, **kwargs):
        super().__init__(parent, **kwargs)
        self.engine = engine

        # Toolbar
        toolbar = ttk.Frame(self)
        toolbar.pack(fill=tk.X, pady=2)

        ttk.Button(toolbar, text="➕", width=3, command=self.add_entity).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="🗑", width=3, command=self.delete_selected).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="🔍", width=3, command=self.focus_selected).pack(side=tk.LEFT, padx=2)

        # Tree
        self.tree = ttk.Treeview(self, columns=("type",), show="tree", selectmode="browse")
        self.tree.heading("#0", text="Hierarchy")
        self.tree.column("#0", width=200)

        scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)

        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # Bindings
        self.tree.bind("<<TreeviewSelect>>", self.on_select)
        self.tree.bind("<Button-3>", self.show_context_menu)

        # Drag and drop bindings
        self.tree.bind("<ButtonPress-1>", self.on_drag_start)
        self.tree.bind("<B1-Motion>", self.on_drag_motion)
        self.tree.bind("<ButtonRelease-1>", self.on_drag_release)

        # Keyboard shortcuts
        self.tree.bind("<Delete>", lambda e: self.delete_selected())
        self.tree.bind("<F2>", lambda e: self.rename_selected())

        self.entity_map = {}  # tree iid -> entity id
        self._refresh_pending = False

        # Drag state
        self._drag_source = None
        self._drag_target = None
        self._drag_indicator = None

    def refresh(self):
        """Refresh the hierarchy tree"""
        if self._refresh_pending:
            return
        self._refresh_pending = True
        self.after(50, self._do_refresh)

    def _do_refresh(self):
        self._refresh_pending = False

        # Save selection and expanded state
        selected = self.tree.selection()
        selected_id = self.entity_map.get(selected[0]) if selected else None
        expanded = set()
        for iid in self.entity_map:
            try:
                if self.tree.item(iid, "open"):
                    expanded.add(iid)
            except Exception:
                pass

        # Clear
        for item in self.tree.get_children():
            self.tree.delete(item)
        self.entity_map.clear()

        if not self.engine.current_scene:
            return

        # Populate
        for entity in self.engine.current_scene.root_entities:
            self._add_entity_to_tree(entity, "")

        # Restore expanded state
        for iid in expanded:
            try:
                self.tree.item(iid, open=True)
            except Exception:
                pass

        # Restore selection
        if selected_id:
            for iid, eid in self.entity_map.items():
                if eid == selected_id:
                    self.tree.selection_set(iid)
                    self.tree.see(iid)
                    break

    def _add_entity_to_tree(self, entity, parent_iid):
        icon = "📦"
        if entity.get_component(Transform):
            icon = "🧊"

        iid = self.tree.insert(parent_iid, "end", text=f"{icon} {entity.name}", open=True)
        self.entity_map[iid] = entity.id

        for child in entity.children:
            self._add_entity_to_tree(child, iid)

    def on_select(self, event):
        selected = self.tree.selection()
        if selected:
            entity_id = self.entity_map.get(selected[0])
            if entity_id and self.engine.current_scene:
                entity = self.engine.current_scene.entities.get(entity_id)
                if entity:
                    self.engine.select_entity(entity)

    # ---- Drag & Drop ----
    def on_drag_start(self, event):
        """Start drag operation"""
        item = self.tree.identify_row(event.y)
        if item:
            self._drag_source = item
            self.tree.selection_set(item)

    def on_drag_motion(self, event):
        """Show drag indicator during motion"""
        target = self.tree.identify_row(event.y)
        if target and target != self._drag_source:
            self._drag_target = target
            # Highlight the target
            self.tree.selection_set(target)
        else:
            self._drag_target = None

    def on_drag_release(self, event):
        """Complete drag - reparent entity"""
        if not self._drag_source or not self._drag_target:
            self._drag_source = None
            self._drag_target = None
            return

        if self._drag_source == self._drag_target:
            self._drag_source = None
            self._drag_target = None
            return

        # Get entities
        source_id = self.entity_map.get(self._drag_source)
        target_id = self.entity_map.get(self._drag_target)

        if not source_id or not target_id:
            self._drag_source = None
            self._drag_target = None
            return

        if not self.engine.current_scene:
            self._drag_source = None
            self._drag_target = None
            return

        source_entity = self.engine.current_scene.entities.get(source_id)
        target_entity = self.engine.current_scene.entities.get(target_id)

        if not source_entity or not target_entity:
            self._drag_source = None
            self._drag_target = None
            return

        # Check for circular parenting (can't drag parent onto its own child)
        current = target_entity
        while current.parent:
            if current.parent == source_entity:
                messagebox.showwarning("Hierarchy", "Cannot parent an object to its own child.")
                self._drag_source = None
                self._drag_target = None
                return
            current = current.parent

        # Perform reparent
        # Remove from old parent's children list
        if source_entity.parent:
            source_entity.parent.children.remove(source_entity)
        else:
            if source_entity in self.engine.current_scene.root_entities:
                self.engine.current_scene.root_entities.remove(source_entity)

        # Add to new parent
        source_entity.parent = target_entity
        target_entity.children.append(source_entity)

        # Refresh
        self.refresh()
        self.engine.mark_modified()

        self._drag_source = None
        self._drag_target = None

    def add_entity(self):
        if self.engine.current_scene:
            entity = self.engine.current_scene.create_entity("New Entity")
            self.refresh()
            self.engine.mark_modified()

    def delete_selected(self):
        selected = self.tree.selection()
        if selected:
            entity_id = self.entity_map.get(selected[0])
            if entity_id and self.engine.current_scene:
                entity = self.engine.current_scene.entities.get(entity_id)
                if entity:
                    self.engine.current_scene.destroy_entity(entity)
                    self.refresh()
                    self.engine.select_entity(None)
                    self.engine.mark_modified()

    def focus_selected(self):
        if self.engine.viewport:
            self.engine.viewport.focus_selected()

    def rename_selected(self):
        selected = self.tree.selection()
        if selected:
            entity_id = self.entity_map.get(selected[0])
            if entity_id and self.engine.current_scene:
                entity = self.engine.current_scene.entities.get(entity_id)
                if entity:
                    from tkinter import simpledialog
                    new_name = simpledialog.askstring("Rename", "New name:", initialvalue=entity.name, parent=self)
                    if new_name:
                        entity.name = new_name
                        self.refresh()
                        self.engine.mark_modified()

    def show_context_menu(self, event):
        item = self.tree.identify_row(event.y)
        if item:
            self.tree.selection_set(item)
            menu = tk.Menu(self, tearoff=0, bg="#231D33", fg="#615FFF", activebackground="#4A3F6B", activeforeground="#5EE9B5")
            menu.add_command(label="Duplicate", command=lambda: self.duplicate_entity(item))
            menu.add_command(label="Rename", command=lambda: self.rename_entity(item))
            menu.add_separator()
            menu.add_command(label="Create Empty Child", command=lambda: self.add_child(item))
            menu.add_separator()
            menu.add_command(label="Delete", command=self.delete_selected)
            menu.tk_popup(event.x_root, event.y_root)

    def duplicate_entity(self, item):
        entity_id = self.entity_map.get(item)
        if entity_id and self.engine.current_scene:
            original = self.engine.current_scene.entities.get(entity_id)
            if original:
                # Clone
                clone = self.engine.current_scene.create_entity(original.name + " (Copy)")
                # Copy components
                for comp in original.components:
                    if comp.get_type_name() != "Transform":
                        new_comp = comp.copy()
                        new_comp.entity = clone
                        clone.components.append(new_comp)
                # Copy transform values
                orig_transform = original.get_component(Transform)
                clone_transform = clone.get_component(Transform)
                if orig_transform and clone_transform:
                    clone_transform.position = orig_transform.position.copy()
                    clone_transform.rotation = orig_transform.rotation.copy()
                    clone_transform.scale = orig_transform.scale.copy()
                self.refresh()
                self.engine.mark_modified()

    def rename_entity(self, item):
        entity_id = self.entity_map.get(item)
        if entity_id and self.engine.current_scene:
            entity = self.engine.current_scene.entities.get(entity_id)
            if entity:
                from tkinter import simpledialog
                new_name = simpledialog.askstring("Rename", "New name:", initialvalue=entity.name, parent=self)
                if new_name:
                    entity.name = new_name
                    self.refresh()
                    self.engine.mark_modified()

    def add_child(self, item):
        entity_id = self.entity_map.get(item)
        if entity_id and self.engine.current_scene:
            parent = self.engine.current_scene.entities.get(entity_id)
            if parent:
                child = self.engine.current_scene.create_entity("New Entity", parent)
                self.refresh()
                self.engine.mark_modified()
