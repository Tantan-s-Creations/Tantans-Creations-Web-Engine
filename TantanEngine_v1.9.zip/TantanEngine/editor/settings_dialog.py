"""Comprehensive project settings dialog."""
from __future__ import annotations

import tkinter as tk
from tkinter import ttk, filedialog, colorchooser, messagebox
from ..core.theme import PALETTE


class SettingsDialog(tk.Toplevel):
    """Unity-style project settings dialog with multiple categories."""

    def __init__(self, parent, engine, **kwargs):
        super().__init__(parent, **kwargs)
        self.title("Project Settings")
        self.geometry("900x700")
        self.minsize(700, 500)
        self.transient(parent)
        self.grab_set()

        self.engine = engine
        self.settings = engine.project.settings if engine.project else None

        self.configure(background=PALETTE["bg"])

        # Main layout
        self.paned = ttk.PanedWindow(self, orient=tk.HORIZONTAL)
        self.paned.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Left sidebar with categories
        self.sidebar = ttk.Frame(self.paned, width=180)
        self.paned.add(self.sidebar, weight=0)

        ttk.Label(self.sidebar, text="Settings", style="Header.TLabel").pack(pady=(10, 5), padx=10, anchor="w")

        self.category_var = tk.StringVar(value="general")
        categories = [
            ("general", "General"),
            ("display", "Display"),
            ("graphics", "Graphics"),
            ("physics", "Physics"),
            ("input", "Input"),
            ("audio", "Audio"),
            ("scripting", "Scripting"),
            ("editor", "Editor"),
            ("build", "Build"),
            ("advanced", "Advanced"),
            ("network", "Network"),
            ("accessibility", "Accessibility"),
        ]

        for cat_id, cat_name in categories:
            btn = ttk.Radiobutton(
                self.sidebar, text=cat_name, variable=self.category_var, value=cat_id,
                command=self._switch_category
            )
            btn.pack(fill=tk.X, padx=5, pady=2)

        # Right content area
        self.content_frame = ttk.Frame(self.paned)
        self.paned.add(self.content_frame, weight=1)

        # Scrollable content
        self.canvas = tk.Canvas(self.content_frame, bg=PALETTE["bg"], highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.content_frame, orient="vertical", command=self.canvas.yview)
        self.scroll_frame = ttk.Frame(self.canvas)

        self.canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.canvas_window = self.canvas.create_window((0, 0), window=self.scroll_frame, anchor="nw", width=self.content_frame.winfo_width())

        self.scroll_frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.content_frame.bind("<Configure>", lambda e: self.canvas.itemconfig(self.canvas_window, width=e.width))

        # Bottom buttons
        btn_frame = ttk.Frame(self)
        btn_frame.pack(fill=tk.X, padx=10, pady=(0, 10))

        ttk.Button(btn_frame, text="Revert", command=self._revert).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(btn_frame, text="Apply", command=self._apply).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(btn_frame, text="OK", style="Success.TButton", command=self._ok).pack(side=tk.RIGHT)
        ttk.Button(btn_frame, text="Cancel", command=self.destroy).pack(side=tk.RIGHT, padx=(0, 5))

        # Build all category frames
        self._build_all_categories()
        self._switch_category()

        self.bind("<Escape>", lambda e: self.destroy())

    def _build_all_categories(self):
        self._frames = {}

        # General
        self._frames["general"] = self._build_general()
        # Display
        self._frames["display"] = self._build_display()
        # Graphics
        self._frames["graphics"] = self._build_graphics()
        # Physics
        self._frames["physics"] = self._build_physics()
        # Input
        self._frames["input"] = self._build_input()
        # Audio
        self._frames["audio"] = self._build_audio()
        # Scripting
        self._frames["scripting"] = self._build_scripting()
        # Editor
        self._frames["editor"] = self._build_editor()
        # Build
        self._frames["build"] = self._build_build()
        # Advanced
        self._frames["advanced"] = self._build_advanced()
        # Network
        self._frames["network"] = self._build_network()
        # Accessibility
        self._frames["accessibility"] = self._build_accessibility()

    def _section(self, parent, title):
        frame = ttk.LabelFrame(parent, text=title, padding=10)
        frame.pack(fill=tk.X, pady=5, padx=5)
        return frame

    def _field(self, parent, label, widget_factory, **kwargs):
        row = ttk.Frame(parent)
        row.pack(fill=tk.X, pady=3)
        ttk.Label(row, text=f"{label}:", width=25, anchor="w").pack(side=tk.LEFT)
        widget = widget_factory(row, **kwargs)
        widget.pack(side=tk.LEFT, fill=tk.X, expand=True)
        return widget

    def _build_general(self):
        f = ttk.Frame(self.scroll_frame)
        s = self.settings

        sec = self._section(f, "Project Info")
        self._field(sec, "Company", lambda p: ttk.Entry(p, textvariable=tk.StringVar(value=s.company_name if s else "")))
        self._field(sec, "Product", lambda p: ttk.Entry(p, textvariable=tk.StringVar(value=s.product_name if s else "")))
        self._field(sec, "Version", lambda p: ttk.Entry(p, textvariable=tk.StringVar(value=s.version if s else "1.0.0")))
        self._field(sec, "Description", lambda p: ttk.Entry(p, textvariable=tk.StringVar(value=s.project_description if s else "")))
        self._field(sec, "Project Type", lambda p: ttk.Combobox(p, values=["2D", "3D", "Hybrid"], state="readonly", textvariable=tk.StringVar(value=s.project_type if s else "3D")))

        sec2 = self._section(f, "Application")
        self._field(sec2, "Identifier", lambda p: ttk.Entry(p, textvariable=tk.StringVar(value=s.application_identifier if s else "")))
        self._field(sec2, "Show Welcome", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.show_welcome_screen if s else True)))

        return f

    def _build_display(self):
        f = ttk.Frame(self.scroll_frame)
        s = self.settings

        sec = self._section(f, "Window")
        self._field(sec, "Width", lambda p: ttk.Spinbox(p, from_=320, to=7680, textvariable=tk.StringVar(value=str(s.default_screen_width if s else 1280))))
        self._field(sec, "Height", lambda p: ttk.Spinbox(p, from_=240, to=4320, textvariable=tk.StringVar(value=str(s.default_screen_height if s else 720))))
        self._field(sec, "Fullscreen", lambda p: ttk.Combobox(p, values=["Windowed", "Fullscreen", "Borderless"], state="readonly", textvariable=tk.StringVar(value=s.fullscreen_mode if s else "Windowed")))
        self._field(sec, "Resizable", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.window_resizable if s else True)))
        self._field(sec, "VSync", lambda p: ttk.Spinbox(p, from_=0, to=4, textvariable=tk.StringVar(value=str(s.vsync_count if s else 1))))
        self._field(sec, "Target FPS", lambda p: ttk.Spinbox(p, from_=15, to=240, textvariable=tk.StringVar(value=str(s.target_framerate if s else 60))))

        sec2 = self._section(f, "Splash Screen")
        self._field(sec2, "Show Splash", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.show_splash_screen if s else True)))
        self._field(sec2, "Style", lambda p: ttk.Combobox(p, values=["Minimal", "Fullscreen", "Logo"], state="readonly", textvariable=tk.StringVar(value=s.splash_screen_style if s else "Minimal")))
        self._field(sec2, "Duration", lambda p: ttk.Spinbox(p, from_=0, to=10, increment=0.1, textvariable=tk.StringVar(value=str(s.splash_screen_duration if s else 1.8))))

        return f

    def _build_graphics(self):
        f = ttk.Frame(self.scroll_frame)
        s = self.settings

        sec = self._section(f, "Rendering")
        self._field(sec, "Color Space", lambda p: ttk.Combobox(p, values=["Linear", "Gamma"], state="readonly", textvariable=tk.StringVar(value=s.color_space if s else "Linear")))
        self._field(sec, "Anti Aliasing", lambda p: ttk.Combobox(p, values=["0", "2", "4", "8"], state="readonly", textvariable=tk.StringVar(value=str(s.anti_aliasing if s else 2))))
        self._field(sec, "Anisotropic", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.anisotropic_filtering if s else True)))
        self._field(sec, "Quality", lambda p: ttk.Combobox(p, values=["Fastest", "Balanced", "Beautiful"], state="readonly", textvariable=tk.StringVar(value=s.quality_level if s else "Balanced")))
        self._field(sec, "Graphics API", lambda p: ttk.Combobox(p, values=["WebGL2", "WebGPU"], state="readonly", textvariable=tk.StringVar(value=s.graphics_api if s else "WebGL2")))
        self._field(sec, "Render Scale", lambda p: ttk.Spinbox(p, from_=0.25, to=2.0, increment=0.25, textvariable=tk.StringVar(value=str(s.render_scale if s else 1.0))))

        sec2 = self._section(f, "Shadows & Fog")
        self._field(sec2, "Shadow Quality", lambda p: ttk.Combobox(p, values=["None", "Low", "Medium", "High", "Ultra"], state="readonly", textvariable=tk.StringVar(value=s.shadow_quality if s else "Medium")))
        self._field(sec2, "Texture Filter", lambda p: ttk.Combobox(p, values=["Point", "Bilinear", "Trilinear"], state="readonly", textvariable=tk.StringVar(value=s.texture_filtering if s else "Trilinear")))
        self._field(sec2, "Fog Enabled", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.fog_enabled if s else False)))
        self._field(sec2, "Fog Density", lambda p: ttk.Spinbox(p, from_=0, to=1, increment=0.01, textvariable=tk.StringVar(value=str(s.fog_density if s else 0.01))))

        return f

    def _build_physics(self):
        f = ttk.Frame(self.scroll_frame)
        s = self.settings

        sec = self._section(f, "Physics")
        self._field(sec, "Gravity X", lambda p: ttk.Spinbox(p, from_=-50, to=50, increment=0.1, textvariable=tk.StringVar(value=str(s.gravity[0] if s else 0))))
        self._field(sec, "Gravity Y", lambda p: ttk.Spinbox(p, from_=-50, to=50, increment=0.1, textvariable=tk.StringVar(value=str(s.gravity[1] if s else -9.81))))
        self._field(sec, "Gravity Z", lambda p: ttk.Spinbox(p, from_=-50, to=50, increment=0.1, textvariable=tk.StringVar(value=str(s.gravity[2] if s else 0))))
        self._field(sec, "Solver Iterations", lambda p: ttk.Spinbox(p, from_=1, to=50, textvariable=tk.StringVar(value=str(s.default_solver_iterations if s else 6))))
        self._field(sec, "Fixed Timestep", lambda p: ttk.Spinbox(p, from_=0.001, to=0.1, increment=0.001, textvariable=tk.StringVar(value=str(s.fixed_timestep if s else 0.02))))
        self._field(sec, "Contact Offset", lambda p: ttk.Spinbox(p, from_=0.001, to=1, increment=0.001, textvariable=tk.StringVar(value=str(s.default_contact_offset if s else 0.01))))

        return f

    def _build_input(self):
        f = ttk.Frame(self.scroll_frame)
        s = self.settings

        sec = self._section(f, "Input Actions")
        ttk.Label(sec, text="Input actions are defined in the Input Manager.", style="Subtle.TLabel").pack(pady=5)

        return f

    def _build_audio(self):
        f = ttk.Frame(self.scroll_frame)
        s = self.settings

        sec = self._section(f, "General")
        self._field(sec, "Global Volume", lambda p: ttk.Spinbox(p, from_=0, to=1, increment=0.01, textvariable=tk.StringVar(value=str(s.global_volume if s else 1.0))))
        self._field(sec, "Max Sounds", lambda p: ttk.Spinbox(p, from_=1, to=128, textvariable=tk.StringVar(value=str(s.max_concurrent_sounds if s else 32))))
        self._field(sec, "Sample Rate", lambda p: ttk.Combobox(p, values=["22050", "44100", "48000", "96000"], state="readonly", textvariable=tk.StringVar(value=str(s.default_sample_rate if s else 44100))))
        self._field(sec, "Reverb", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.reverb_enabled if s else False)))

        sec2 = self._section(f, "Advanced")
        self._field(sec2, "Master Volume", lambda p: ttk.Spinbox(p, from_=0, to=1, increment=0.01, textvariable=tk.StringVar(value=str(s.master_volume if s else 1.0))))
        self._field(sec2, "Music Volume", lambda p: ttk.Spinbox(p, from_=0, to=1, increment=0.01, textvariable=tk.StringVar(value=str(s.music_volume if s else 0.8))))
        self._field(sec2, "SFX Volume", lambda p: ttk.Spinbox(p, from_=0, to=1, increment=0.01, textvariable=tk.StringVar(value=str(s.sfx_volume if s else 1.0))))
        self._field(sec2, "Voice Volume", lambda p: ttk.Spinbox(p, from_=0, to=1, increment=0.01, textvariable=tk.StringVar(value=str(s.voice_volume if s else 1.0))))
        self._field(sec2, "Spatialization", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.enable_audio_spatialization if s else True)))
        self._field(sec2, "Distance Model", lambda p: ttk.Combobox(p, values=["inverse", "linear", "exponential"], state="readonly", textvariable=tk.StringVar(value=s.audio_distance_model if s else "inverse")))

        return f

    def _build_scripting(self):
        f = ttk.Frame(self.scroll_frame)
        s = self.settings

        sec = self._section(f, "Scripting")
        self._field(sec, "Default Language", lambda p: ttk.Combobox(p, values=["javascript", "csharp", "java"], state="readonly", textvariable=tk.StringVar(value=s.default_scripting_language if s else "javascript")))
        self._field(sec, "API Version", lambda p: ttk.Entry(p, textvariable=tk.StringVar(value=s.api_compatibility if s else "WebEngine 1.0")))
        self._field(sec, "Allow Debugging", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.allow_debugging if s else True)))
        self._field(sec, "Reload on Save", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.script_reload_on_save if s else True)))
        self._field(sec, "Hot Reload", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.hot_reload_scripts if s else True)))

        return f

    def _build_editor(self):
        f = ttk.Frame(self.scroll_frame)
        s = self.settings

        sec = self._section(f, "Editor Preferences")
        self._field(sec, "Auto Save", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.editor_auto_save if s else True)))
        self._field(sec, "Auto Save Interval", lambda p: ttk.Spinbox(p, from_=10, to=600, textvariable=tk.StringVar(value=str(s.editor_auto_save_interval if s else 60))))
        self._field(sec, "Show Grid", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.editor_show_grid if s else True)))
        self._field(sec, "Show Gizmos", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.editor_show_gizmos if s else True)))
        self._field(sec, "Show FPS", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.editor_show_fps if s else True)))
        self._field(sec, "Show Scene Info", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.editor_show_scene_info if s else True)))
        self._field(sec, "Nav Speed", lambda p: ttk.Spinbox(p, from_=0.1, to=10, increment=0.1, textvariable=tk.StringVar(value=str(s.scene_view_navigation_speed if s else 1.0))))
        self._field(sec, "Zoom Sensitivity", lambda p: ttk.Spinbox(p, from_=0.01, to=1, increment=0.01, textvariable=tk.StringVar(value=str(s.viewport_zoom_sensitivity if s else 0.1))))
        self._field(sec, "Orbit Sensitivity", lambda p: ttk.Spinbox(p, from_=0.1, to=2, increment=0.1, textvariable=tk.StringVar(value=str(s.viewport_orbit_sensitivity if s else 0.3))))
        self._field(sec, "Grid Snap", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.grid_snap_enabled if s else False)))
        self._field(sec, "Snap Increment", lambda p: ttk.Spinbox(p, from_=0.01, to=10, increment=0.01, textvariable=tk.StringVar(value=str(s.grid_snap_increment if s else 0.5))))

        return f

    def _build_build(self):
        f = ttk.Frame(self.scroll_frame)
        s = self.settings

        sec = self._section(f, "Build Settings")
        self._field(sec, "Output Type", lambda p: ttk.Combobox(p, values=["single_html", "standard_web", "pwa"], state="readonly", textvariable=tk.StringVar(value=s.build_output_type if s else "single_html")))
        self._field(sec, "Compression", lambda p: ttk.Spinbox(p, from_=0, to=9, textvariable=tk.StringVar(value=str(s.compression_level if s else 6))))
        self._field(sec, "Optimization", lambda p: ttk.Combobox(p, values=["speed", "size", "balanced"], state="readonly", textvariable=tk.StringVar(value=s.code_optimization if s else "balanced")))
        self._field(sec, "Bundle Splitting", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.asset_bundle_splitting if s else False)))
        self._field(sec, "Debug Info", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.include_debug_info if s else False)))
        self._field(sec, "Run After Export", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.build_run_after_export if s else False)))
        self._field(sec, "Open Browser", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.build_open_in_browser if s else True)))
        self._field(sec, "Boot Timeout", lambda p: ttk.Spinbox(p, from_=5, to=60, textvariable=tk.StringVar(value=str(s.build_boot_timeout_seconds if s else 15))))

        return f

    def _build_advanced(self):
        f = ttk.Frame(self.scroll_frame)
        s = self.settings

        sec = self._section(f, "Advanced")
        self._field(sec, "Scripting Backend", lambda p: ttk.Combobox(p, values=["JavaScript", "WebAssembly", "Both"], state="readonly", textvariable=tk.StringVar(value=s.scripting_backend if s else "JavaScript")))
        self._field(sec, "Memory Limit (MB)", lambda p: ttk.Spinbox(p, from_=128, to=4096, textvariable=tk.StringVar(value=str(s.memory_limit_mb if s else 512))))
        self._field(sec, "Multithreading", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.enable_multithreading if s else False)))
        self._field(sec, "WebXR", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.enable_webxr if s else False)))
        self._field(sec, "Gamepad", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.enable_gamepad if s else True)))
        self._field(sec, "Touch", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.enable_touch if s else True)))
        self._field(sec, "Keyboard", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.enable_keyboard if s else True)))
        self._field(sec, "Mouse", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.enable_mouse if s else True)))
        self._field(sec, "Custom Cursor", lambda p: ttk.Entry(p, textvariable=tk.StringVar(value=s.custom_cursor if s else "")))
        self._field(sec, "Loading Text", lambda p: ttk.Entry(p, textvariable=tk.StringVar(value=s.loading_screen_text if s else "Loading...")))
        self._field(sec, "Loading Spinner", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.loading_screen_spinner if s else True)))
        self._field(sec, "Analytics", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.enable_analytics if s else False)))
        self._field(sec, "Analytics ID", lambda p: ttk.Entry(p, textvariable=tk.StringVar(value=s.analytics_id if s else "")))
        self._field(sec, "Service Worker", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.enable_service_worker if s else True)))
        self._field(sec, "Cache Size (MB)", lambda p: ttk.Spinbox(p, from_=10, to=1000, textvariable=tk.StringVar(value=str(s.offline_cache_size_mb if s else 100))))
        self._field(sec, "PWA Install", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.enable_pwa_install_prompt if s else True)))
        self._field(sec, "Theme Color", lambda p: ttk.Entry(p, textvariable=tk.StringVar(value=s.pwa_theme_color if s else "#A684FF")))
        self._field(sec, "BG Color", lambda p: ttk.Entry(p, textvariable=tk.StringVar(value=s.pwa_background_color if s else "#1A1625")))
        self._field(sec, "Display Mode", lambda p: ttk.Combobox(p, values=["standalone", "fullscreen", "minimal-ui"], state="readonly", textvariable=tk.StringVar(value=s.pwa_display_mode if s else "standalone")))
        self._field(sec, "Orientation", lambda p: ttk.Combobox(p, values=["any", "portrait", "landscape"], state="readonly", textvariable=tk.StringVar(value=s.pwa_orientation if s else "any")))

        return f

    def _build_network(self):
        f = ttk.Frame(self.scroll_frame)
        s = self.settings

        sec = self._section(f, "Multiplayer")
        self._field(sec, "Enable Multiplayer", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.enable_multiplayer if s else False)))
        self._field(sec, "Transport", lambda p: ttk.Combobox(p, values=["WebSocket", "WebRTC"], state="readonly", textvariable=tk.StringVar(value=s.network_transport if s else "WebSocket")))
        self._field(sec, "Max Players", lambda p: ttk.Spinbox(p, from_=2, to=100, textvariable=tk.StringVar(value=str(s.max_players if s else 16))))
        self._field(sec, "Tick Rate", lambda p: ttk.Spinbox(p, from_=10, to=120, textvariable=tk.StringVar(value=str(s.server_tick_rate if s else 30))))
        self._field(sec, "Client Prediction", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.client_prediction if s else True)))
        self._field(sec, "Server Reconciliation", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.server_reconciliation if s else True)))
        self._field(sec, "Interpolation (ms)", lambda p: ttk.Spinbox(p, from_=0, to=500, textvariable=tk.StringVar(value=str(s.interpolation_delay_ms if s else 100))))

        return f

    def _build_accessibility(self):
        f = ttk.Frame(self.scroll_frame)
        s = self.settings

        sec = self._section(f, "Accessibility")
        self._field(sec, "Screen Reader", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.enable_screen_reader if s else False)))
        self._field(sec, "High Contrast", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.enable_high_contrast if s else False)))
        self._field(sec, "Large Text", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.enable_large_text if s else False)))
        self._field(sec, "Subtitle Language", lambda p: ttk.Combobox(p, values=["en", "es", "fr", "de", "ja", "zh", "ko", "pt", "ru", "it"], state="readonly", textvariable=tk.StringVar(value=s.subtitle_language if s else "en")))
        self._field(sec, "Colorblind Mode", lambda p: ttk.Checkbutton(p, variable=tk.BooleanVar(value=s.enable_colorblind_mode if s else False)))
        self._field(sec, "Colorblind Type", lambda p: ttk.Combobox(p, values=["deuteranopia", "protanopia", "tritanopia"], state="readonly", textvariable=tk.StringVar(value=s.colorblind_type if s else "deuteranopia")))

        return f

    def _switch_category(self):
        cat = self.category_var.get()
        # Hide all frames
        for frame in self._frames.values():
            frame.pack_forget()
        # Show selected
        if cat in self._frames:
            self._frames[cat].pack(fill=tk.BOTH, expand=True)

    def _revert(self):
        if self.engine.project:
            self.engine.project.load()
            self._build_all_categories()
            self._switch_category()

    def _apply(self):
        if self.engine.project:
            self.engine.project.save()

    def _ok(self):
        self._apply()
        self.destroy()
