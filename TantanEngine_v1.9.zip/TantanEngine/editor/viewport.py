"""Unity-like scene viewport with software renderer and polished overlay."""
from __future__ import annotations

import math
import tkinter as tk
from PIL import Image, ImageTk, ImageDraw

from ..core.math3d import Vector3
from ..core.ecs import Transform
from ..runtime.software_renderer import SoftwareRenderer
from ..core.theme import PALETTE


class Viewport(tk.Canvas):
    """Editor scene viewport with orbit/pan/zoom controls."""

    def __init__(self, parent, engine, **kwargs):
        super().__init__(parent, bg=PALETTE["surface_alt"], highlightthickness=0, **kwargs)
        self.engine = engine
        self.renderer = SoftwareRenderer(800, 600)

        self.scene_mode = "Scene"
        self.camera_mode = "Perspective"
        self.show_grid = True
        self.show_gizmos = True
        self.grid_snap = False

        self.is_orbiting = False
        self.is_panning = False
        self.last_mouse_x = 0
        self.last_mouse_y = 0
        self.orbit_speed = 0.3
        self.pan_speed = 0.01
        self.zoom_speed = 0.1

        self.selected_entity = None
        self.gizmo_mode = "translate"
        self.play_mode = False
        self.nav_speed = 1.0
        self.zoom_sensitivity = 0.1
        self.orbit_sensitivity = 0.3

        self.photo_image = None
        self.image_id = self.create_image(0, 0, anchor=tk.NW, image=self.photo_image)

        self.bind("<Button-1>", self.on_mouse_down)
        self.bind("<B1-Motion>", self.on_mouse_drag)
        self.bind("<ButtonRelease-1>", self.on_mouse_up)
        self.bind("<Button-3>", self.on_right_down)
        self.bind("<B3-Motion>", self.on_right_drag)
        self.bind("<ButtonRelease-3>", self.on_right_up)
        self.bind("<Button-4>", self.on_scroll)
        self.bind("<Button-5>", self.on_scroll)
        self.bind("<MouseWheel>", self.on_scroll)
        self.bind("<Configure>", self.on_resize)

        self.after(16, self.render_loop)

    def on_resize(self, event):
        self.renderer.resize(max(1, event.width), max(1, event.height))
        self.config(width=event.width, height=event.height)

    def on_mouse_down(self, event):
        if self.play_mode:
            return
        self.last_mouse_x = event.x
        self.last_mouse_y = event.y
        self.is_orbiting = bool(event.state & 0x0008)  # Alt+drag orbits
        self.is_panning = bool(event.state & 0x0001)    # Shift+drag pans
        if not self.is_orbiting and not self.is_panning:
            self._try_select(event.x, event.y)

    def on_mouse_drag(self, event):
        if self.play_mode or (not self.is_orbiting and not self.is_panning):
            return

        dx = event.x - self.last_mouse_x
        dy = event.y - self.last_mouse_y
        self.last_mouse_x = event.x
        self.last_mouse_y = event.y

        if self.is_orbiting:
            target = self.renderer.camera_target
            pos = self.renderer.camera_pos

            dx_vec = Vector3(pos.x - target.x, pos.y - target.y, pos.z - target.z)
            dist = max(0.001, dx_vec.magnitude)

            angle_y = math.atan2(dx_vec.x, dx_vec.z) + math.radians(dx * self.orbit_speed * self.orbit_sensitivity)
            angle_x = math.asin(max(-1.0, min(1.0, dx_vec.y / dist))) + math.radians(dy * self.orbit_speed * 0.5 * self.orbit_sensitivity)
            angle_x = max(-1.4, min(1.4, angle_x))

            new_x = target.x + dist * math.cos(angle_x) * math.sin(angle_y)
            new_y = target.y + dist * math.sin(angle_x)
            new_z = target.z + dist * math.cos(angle_x) * math.cos(angle_y)
            self.renderer.camera_pos = Vector3(new_x, new_y, new_z)

        elif self.is_panning:
            right = Vector3(1, 0, 0)
            up = Vector3(0, 1, 0)
            offset = right * (-dx * self.pan_speed * self.nav_speed) + up * (dy * self.pan_speed * self.nav_speed)
            self.renderer.camera_pos = self.renderer.camera_pos + offset
            self.renderer.camera_target = self.renderer.camera_target + offset

        if hasattr(self.engine, "hierarchy_panel"):
            self.engine.hierarchy_panel.refresh()

    def on_mouse_up(self, event):
        self.is_orbiting = False
        self.is_panning = False

    def on_right_down(self, event):
        if self.play_mode:
            return
        self.is_panning = True
        self.last_mouse_x = event.x
        self.last_mouse_y = event.y

    def on_right_drag(self, event):
        if self.play_mode or not self.is_panning:
            return

        dx = event.x - self.last_mouse_x
        dy = event.y - self.last_mouse_y
        self.last_mouse_x = event.x
        self.last_mouse_y = event.y

        right = Vector3(1, 0, 0)
        up = Vector3(0, 1, 0)
        offset = right * (-dx * self.pan_speed * self.nav_speed) + up * (dy * self.pan_speed * self.nav_speed)
        self.renderer.camera_pos = self.renderer.camera_pos + offset
        self.renderer.camera_target = self.renderer.camera_target + offset

    def on_right_up(self, event):
        self.is_panning = False

    def on_scroll(self, event):
        if self.play_mode:
            return
        direction = 0
        if hasattr(event, "delta") and event.delta:
            direction = 1 if event.delta > 0 else -1
        elif getattr(event, "num", None) == 4:
            direction = 1
        elif getattr(event, "num", None) == 5:
            direction = -1
        if direction == 0:
            return
        target = self.renderer.camera_target
        pos = self.renderer.camera_pos
        direction_vec = Vector3(target.x - pos.x, target.y - pos.y, target.z - pos.z).normalized()
        distance = Vector3(target.x - pos.x, target.y - pos.y, target.z - pos.z).magnitude
        zoom_speed = self.zoom_speed * max(0.05, self.zoom_sensitivity)
        new_dist = max(1.0, distance - direction * distance * zoom_speed * self.nav_speed)
        self.renderer.camera_pos = target - direction_vec * new_dist

    def _try_select(self, x, y):
        if not self.engine.current_scene:
            return

        view = self.renderer.get_view_matrix()
        proj = self.renderer.get_projection_matrix()
        view_proj = proj @ view

        closest = None
        closest_dist = float("inf")

        for entity in self.engine.current_scene.entities.values():
            transform = entity.get_component(Transform)
            if not transform:
                continue

            p = self.renderer.project_point(transform.position, view_proj)
            if p:
                dx = p[0] - x
                dy = p[1] - y
                dist = (dx * dx + dy * dy) ** 0.5
                if dist < 30 and dist < closest_dist:
                    closest = entity
                    closest_dist = dist

        if closest:
            self.selected_entity = closest
            self.renderer.selected_entity = closest
            self.engine.select_entity(closest)

    def _overlay_font(self, size=12, bold=False):
        family = getattr(getattr(self.engine, "theme", {}), "get", lambda *_: None)("font_family") if getattr(self.engine, "theme", None) else None
        if not family:
            family = "Bungee"
        return (family, size, "bold" if bold else "normal")

    def _draw_overlay(self, image: Image.Image):
        draw = ImageDraw.Draw(image)
        w, h = image.size

        bar_h = 40
        title_fill = PALETTE["purple"] if not self.play_mode else PALETTE["blue"]
        bar_fill = PALETTE["pastel_purple"] if not self.play_mode else PALETTE["pastel_blue"]
        draw.rounded_rectangle((10, 10, w - 10, 10 + bar_h), radius=14, fill=bar_fill, outline=PALETTE["border"], width=1)

        mode_label = f"{self.scene_mode}  •  {self.camera_mode}"
        grid_label = f"Grid: {'On' if self.show_grid else 'Off'}"
        if self.play_mode:
            mode_label = f"PLAY MODE  •  {mode_label}"
        selected = self.selected_entity.name if self.selected_entity else "No Selection"

        draw.text((24, 18), mode_label, fill=title_fill)
        draw.text((w - 260, 18), selected[:30], fill=PALETTE["text"])
        draw.text((w - 260, 34), grid_label, fill=PALETTE["muted"])

        help_text = "Left Click Select • Alt+Drag Orbit • Shift+Drag Pan • Scroll Zoom"
        box_w = min(520, w - 24)
        draw.rounded_rectangle((12, h - 46, 12 + box_w, h - 12), radius=12, fill=PALETTE["surface"], outline=PALETTE["border"], width=1)
        draw.text((24, h - 37), help_text, fill=PALETTE["muted"])

        cx, cy = w - 64, h - 64
        draw.rounded_rectangle((w - 98, h - 98, w - 22, h - 22), radius=14, fill=PALETTE["surface"], outline=PALETTE["border"])
        draw.line((cx, cy, cx + 18, cy), fill=PALETTE["error"], width=3)
        draw.line((cx, cy, cx, cy - 18), fill=PALETTE["blue"], width=3)
        draw.line((cx, cy, cx - 12, cy + 12), fill=PALETTE["green"], width=3)

    def render_loop(self):
        try:
            settings = getattr(getattr(self.engine, "project", None), "settings", None)
            self.nav_speed = getattr(settings, "scene_view_navigation_speed", 1.0)
            self.show_grid = getattr(settings, "editor_show_grid", self.show_grid)
            self.show_gizmos = getattr(settings, "editor_show_gizmos", self.show_gizmos)
            self.zoom_sensitivity = getattr(settings, "viewport_zoom_sensitivity", self.zoom_sensitivity)
            self.orbit_sensitivity = getattr(settings, "viewport_orbit_sensitivity", self.orbit_sensitivity)
            self.renderer.show_grid = self.show_grid

            scene = self.engine.current_scene
            if scene:
                self.renderer.render_scene(scene, self.engine.asset_db)
                img = self.renderer.image.copy()
            else:
                img = self._empty_viewport_image()

            self._draw_overlay(img)
            self.photo_image = ImageTk.PhotoImage(img)
            self.itemconfig(self.image_id, image=self.photo_image)
        except Exception as exc:
            print(f"Viewport render error: {exc}")

        self.after(16, self.render_loop)

    def set_play_mode(self, playing: bool):
        self.play_mode = playing
        if playing:
            self.is_orbiting = False
            self.is_panning = False

    def _empty_viewport_image(self):
        image = Image.new("RGB", (max(1, self.renderer.width), max(1, self.renderer.height)), PALETTE["surface_alt"])
        draw = ImageDraw.Draw(image)
        w, h = image.size
        draw.rounded_rectangle((18, 18, w - 18, h - 18), radius=18, fill=PALETTE["surface"], outline=PALETTE["border"], width=2)
        draw.text((32, 34), "No scene loaded", fill=PALETTE["purple"])
        draw.text((32, 58), "Create or open a scene to begin editing.", fill=PALETTE["muted"])
        return image

    def focus_selected(self):
        if self.selected_entity:
            transform = self.selected_entity.get_component(Transform)
            if transform:
                self.renderer.camera_target = Vector3(transform.position.x, transform.position.y, transform.position.z)

    def reset_camera(self):
        self.renderer.camera_pos = Vector3(5, 5, 5)
        self.renderer.camera_target = Vector3(0, 0, 0)
        self.renderer.camera_up = Vector3(0, 1, 0)

    def toggle_grid(self):
        self.show_grid = not self.show_grid
        self.renderer.show_grid = self.show_grid

    def set_scene_mode(self, mode: str):
        self.scene_mode = mode

    def set_camera_mode(self, mode: str):
        self.camera_mode = mode

    def set_gizmo_mode(self, mode: str):
        self.gizmo_mode = mode
