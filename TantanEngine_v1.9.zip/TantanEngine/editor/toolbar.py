"""Main toolbar with play controls and tools."""
from __future__ import annotations

import tkinter as tk
from tkinter import ttk

from ..core.theme import PALETTE


class EditorToolbar(ttk.Frame):
    """Main editor toolbar."""

    def __init__(self, parent, engine, **kwargs):
        super().__init__(parent, **kwargs)
        self.engine = engine

        # Play controls
        play_frame = ttk.LabelFrame(self, text="Play Mode", padding=5)
        play_frame.pack(side=tk.LEFT, padx=5, pady=2)

        self.play_btn = ttk.Button(play_frame, text="▶ Play", width=8, command=self.on_play)
        self.play_btn.pack(side=tk.LEFT, padx=2)

        self.pause_btn = ttk.Button(play_frame, text="⏸ Pause", width=8, command=self.on_pause, state="disabled")
        self.pause_btn.pack(side=tk.LEFT, padx=2)

        self.stop_btn = ttk.Button(play_frame, text="⏹ Stop", width=8, command=self.on_stop, state="disabled")
        self.stop_btn.pack(side=tk.LEFT, padx=2)

        # Transform tools
        tool_frame = ttk.LabelFrame(self, text="Tools", padding=5)
        tool_frame.pack(side=tk.LEFT, padx=5, pady=2)

        self.tool_var = tk.StringVar(value="translate")
        ttk.Radiobutton(tool_frame, text="Move", variable=self.tool_var, value="translate", command=self._sync_tool).pack(side=tk.LEFT, padx=2)
        ttk.Radiobutton(tool_frame, text="Rotate", variable=self.tool_var, value="rotate", command=self._sync_tool).pack(side=tk.LEFT, padx=2)
        ttk.Radiobutton(tool_frame, text="Scale", variable=self.tool_var, value="scale", command=self._sync_tool).pack(side=tk.LEFT, padx=2)

        # View controls
        view_frame = ttk.LabelFrame(self, text="View", padding=5)
        view_frame.pack(side=tk.LEFT, padx=5, pady=2)

        ttk.Button(view_frame, text="🔍 Focus", width=8, command=self.on_focus).pack(side=tk.LEFT, padx=2)
        ttk.Button(view_frame, text="🔄 Reset", width=8, command=self.on_reset_view).pack(side=tk.LEFT, padx=2)
        ttk.Separator(view_frame, orient="vertical").pack(side=tk.LEFT, fill=tk.Y, padx=6)
        ttk.Button(view_frame, text="Scene", width=7, command=lambda: self.on_view_mode("Scene")).pack(side=tk.LEFT, padx=2)
        ttk.Button(view_frame, text="Game", width=7, command=lambda: self.on_view_mode("Game")).pack(side=tk.LEFT, padx=2)
        ttk.Button(view_frame, text="Grid", width=7, command=self.on_toggle_grid).pack(side=tk.LEFT, padx=2)

        # Build / settings
        build_frame = ttk.Frame(self)
        build_frame.pack(side=tk.RIGHT, padx=10)

        ttk.Button(build_frame, text="📦 Build HTML", command=self.on_build).pack(side=tk.LEFT, padx=2)
        ttk.Button(build_frame, text="⚙ Settings", command=self.on_settings).pack(side=tk.LEFT, padx=2)

        # Status
        self.status_label = ttk.Label(self, text="Ready", relief=tk.SUNKEN)
        self.status_label.pack(side=tk.RIGHT, padx=5)

    def _sync_tool(self):
        if hasattr(self.engine, "viewport") and self.engine.viewport:
            self.engine.viewport.gizmo_mode = self.tool_var.get()

    def on_play(self):
        self.engine.enter_play_mode()
        if hasattr(self.engine, "viewport") and self.engine.viewport:
            self.engine.viewport.set_play_mode(True)
        self.play_btn.config(state="disabled")
        self.pause_btn.config(state="normal")
        self.stop_btn.config(state="normal")
        self.status_label.config(text="Playing", foreground=PALETTE["blue"])

    def on_pause(self):
        self.engine.pause_play_mode()
        self.status_label.config(text="Paused", foreground=PALETTE["purple"])

    def on_stop(self):
        self.engine.exit_play_mode()
        if hasattr(self.engine, "viewport") and self.engine.viewport:
            self.engine.viewport.set_play_mode(False)
        self.play_btn.config(state="normal")
        self.pause_btn.config(state="disabled")
        self.stop_btn.config(state="disabled")
        self.status_label.config(text="Ready", foreground=PALETTE["text"])

    def on_focus(self):
        if self.engine.viewport:
            self.engine.viewport.focus_selected()

    def on_reset_view(self):
        if self.engine.viewport:
            self.engine.viewport.reset_camera()

    def on_view_mode(self, mode):
        if self.engine.viewport:
            self.engine.viewport.set_scene_mode(mode)

    def on_toggle_grid(self):
        if self.engine.viewport:
            self.engine.viewport.toggle_grid()

    def on_build(self):
        self.engine.build_html()

    def on_settings(self):
        self.engine.open_settings()
