"""Project browser / asset browser panel"""
import tkinter as tk
from tkinter import ttk
from pathlib import Path

class ProjectBrowser(ttk.Frame):
    """File browser for project assets"""
    def __init__(self, parent, engine, **kwargs):
        super().__init__(parent, **kwargs)
        self.engine = engine

        # Toolbar
        toolbar = ttk.Frame(self)
        toolbar.pack(fill=tk.X, pady=2)

        ttk.Button(toolbar, text="📁 Import", command=self.import_asset).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="🔄 Refresh", command=self.refresh).pack(side=tk.LEFT, padx=2)
        ttk.Entry(toolbar, width=20).pack(side=tk.RIGHT, padx=5)
        ttk.Label(toolbar, text="Search:").pack(side=tk.RIGHT)

        # Tree
        self.tree = ttk.Treeview(self, columns=("type", "size"), show="tree headings")
        self.tree.heading("#0", text="Project")
        self.tree.heading("type", text="Type")
        self.tree.heading("size", text="Size")
        self.tree.column("#0", width=250)
        self.tree.column("type", width=80)
        self.tree.column("size", width=60)

        scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)

        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.tree.bind("<Double-1>", self.on_double_click)
        self.tree.bind("<Button-3>", self.show_context_menu)

        self.refresh()

    def refresh(self):
        for item in self.tree.get_children():
            self.tree.delete(item)

        if not self.engine.project:
            return

        assets_path = self.engine.project.path / "Assets"
        if not assets_path.exists():
            return

        root_node = self.tree.insert("", "end", text="Assets", open=True)
        self._populate_tree(root_node, assets_path)

    def _populate_tree(self, parent_node, path):
        try:
            for item in sorted(path.iterdir(), key=lambda x: (x.is_file(), x.name.lower())):
                if item.is_dir():
                    node = self.tree.insert(parent_node, "end", text=f"📁 {item.name}", open=False)
                    self._populate_tree(node, item)
                else:
                    size = item.stat().st_size
                    size_str = self._format_size(size)
                    ext = item.suffix.lower()
                    type_name = self._get_type_name(ext)
                    icon = self._get_icon(ext)
                    self.tree.insert(parent_node, "end", text=f"{icon} {item.name}",
                                    values=(type_name, size_str))
        except PermissionError:
            pass

    def _format_size(self, size):
        if size < 1024:
            return f"{size} B"
        elif size < 1024*1024:
            return f"{size/1024:.1f} KB"
        else:
            return f"{size/(1024*1024):.1f} MB"

    def _get_type_name(self, ext):
        types = {
            ".png": "Texture", ".jpg": "Texture", ".jpeg": "Texture", ".bmp": "Texture",
            ".obj": "Mesh", ".fbx": "Mesh", ".gltf": "Mesh", ".glb": "Mesh",
            ".wav": "Audio", ".mp3": "Audio", ".ogg": "Audio",
            ".cs": "C# Script", ".js": "JS Script", ".ts": "TS Script",
            ".tcscene": "Scene", ".tcmat": "Material",
        }
        return types.get(ext, "File")

    def _get_icon(self, ext):
        icons = {
            ".png": "🖼", ".jpg": "🖼", ".jpeg": "🖼",
            ".obj": "🧊", ".fbx": "🧊",
            ".wav": "🔊", ".mp3": "🔊", ".ogg": "🔊",
            ".cs": "📜", ".js": "📜", ".ts": "📜",
            ".tcscene": "🎬",
        }
        return icons.get(ext, "📄")

    def import_asset(self):
        from tkinter import filedialog
        files = filedialog.askopenfilenames(
            title="Import Assets",
            filetypes=[
                ("Images", "*.png *.jpg *.jpeg *.bmp"),
                ("3D Models", "*.obj *.fbx"),
                ("Audio", "*.wav *.mp3 *.ogg"),
                ("Scripts", "*.cs *.js *.ts"),
                ("All Files", "*.*")
            ]
        )
        if files and self.engine.project:
            assets_path = self.engine.project.path / "Assets"
            for src in files:
                src_path = Path(src)
                dst = assets_path / src_path.name
                try:
                    import shutil
                    shutil.copy2(src_path, dst)
                except Exception as e:
                    print(f"Import error: {e}")

            if self.engine.asset_db:
                self.engine.asset_db.scan_assets()
            self.refresh()

    def on_double_click(self, event):
        item = self.tree.identify_row(event.y)
        if item:
            text = self.tree.item(item, "text")
            name = text[2:] if text.startswith("🖼 ") or text.startswith("🧊 ") or text.startswith("📜 ") else text
            if name.endswith(".cs") or name.endswith(".js") or name.endswith(".ts"):
                self.engine.open_script(name)

    def show_context_menu(self, event):
        item = self.tree.identify_row(event.y)
        if item:
            menu = tk.Menu(self, tearoff=0)
            menu.add_command(label="Show in Explorer", command=lambda: self._show_in_explorer(item))
            menu.add_command(label="Delete", command=lambda: self._delete_item(item))
            menu.tk_popup(event.x_root, event.y_root)

    def _show_in_explorer(self, item):
        # Platform-specific folder opening
        pass

    def _delete_item(self, item):
        text = self.tree.item(item, "text")
        name = text[2:] if len(text) > 2 and text[1] == " " else text
        if self.engine.project:
            path = self.engine.project.path / "Assets" / name
            if path.exists():
                try:
                    if path.is_file():
                        path.unlink()
                    else:
                        import shutil
                        shutil.rmtree(path)
                    self.refresh()
                except Exception as e:
                    print(f"Delete error: {e}")
