"""Script editor with syntax highlighting and tabs"""
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox

from ..core.theme import PALETTE


class ScriptEditor(ttk.Frame):
    """Multi-tab script editor."""
    def __init__(self, parent, engine, **kwargs):
        super().__init__(parent, **kwargs)
        self.engine = engine
        self.tabs = {}
        self.editors = {}
        self.current_file = None

        toolbar = ttk.Frame(self)
        toolbar.pack(fill=tk.X, pady=2)

        ttk.Button(toolbar, text="💾 Save", command=self.save_current).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="🔄 Reload", command=self.reload_current).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="✕ Close", command=self.close_current).pack(side=tk.LEFT, padx=2)
        ttk.Separator(toolbar, orient="vertical").pack(side=tk.LEFT, fill=tk.Y, padx=5)
        ttk.Button(toolbar, text="▶ Run Test", command=self.test_script).pack(side=tk.LEFT, padx=2)

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill=tk.BOTH, expand=True)
        self.notebook.bind("<<NotebookTabChanged>>", self.on_tab_changed)

        self.status = ttk.Label(self, text="Ready", style="Sunk.TLabel")
        self.status.pack(fill=tk.X, side=tk.BOTTOM)

    def open_file(self, filepath, content=""):
        if filepath in self.tabs:
            self.notebook.select(self.tabs[filepath])
            return

        frame = ttk.Frame(self.notebook)
        self.tabs[filepath] = frame

        text_frame = ttk.Frame(frame)
        text_frame.pack(fill=tk.BOTH, expand=True)

        linenum = tk.Text(
            text_frame,
            width=4,
            padx=4,
            takefocus=0,
            border=0,
            background=PALETTE["panel"],
            foreground=PALETTE["purple"],
            state="disabled",
            font=("Consolas", 10),
        )
        linenum.pack(side=tk.LEFT, fill=tk.Y)

        editor = tk.Text(
            text_frame,
            wrap=tk.NONE,
            undo=True,
            font=("Consolas", 11),
            bg=PALETTE["surface"],
            fg=PALETTE["text"],
            insertbackground=PALETTE["text"],
            selectbackground=PALETTE["pastel_blue"],
            tabs="    ",
            relief="solid",
            bd=1,
            highlightthickness=0,
        )
        editor.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        vscroll = ttk.Scrollbar(text_frame, orient="vertical", command=editor.yview)
        vscroll.pack(side=tk.RIGHT, fill=tk.Y)
        editor.configure(yscrollcommand=vscroll.set)

        hscroll = ttk.Scrollbar(frame, orient="horizontal", command=editor.xview)
        hscroll.pack(fill=tk.X)
        editor.configure(xscrollcommand=hscroll.set)

        if content:
            editor.insert("1.0", content)

        editor.bind("<KeyRelease>", lambda e: self.on_editor_change(filepath, linenum, editor))
        editor.bind("<Control-s>", lambda e: self.save_current())

        tab_name = filepath.split("/")[-1] if "/" in filepath else filepath
        self.notebook.add(frame, text=tab_name)
        self.notebook.select(frame)
        self.editors[filepath] = editor
        self.current_file = filepath

        self.update_line_numbers(linenum, editor)
        self.apply_syntax_highlighting(editor)

    def update_line_numbers(self, linenum, editor):
        linenum.config(state="normal")
        linenum.delete("1.0", tk.END)
        line_count = int(editor.index("end-1c").split(".")[0])
        linenum.insert("1.0", "\n".join(str(i) for i in range(1, line_count + 1)))
        linenum.config(state="disabled")

    def apply_syntax_highlighting(self, editor):
        editor.tag_configure("keyword", foreground=PALETTE["purple"])
        editor.tag_configure("string", foreground=PALETTE["green"])
        editor.tag_configure("comment", foreground=PALETTE["muted"])
        editor.tag_configure("number", foreground=PALETTE["blue"])
        editor.tag_configure("function", foreground=PALETTE["blue"])

    def on_editor_change(self, filepath, linenum, editor):
        self.update_line_numbers(linenum, editor)
        self.engine.mark_modified()

        tab_id = self.tabs[filepath]
        current_text = self.notebook.tab(tab_id, "text")
        if not current_text.startswith("● "):
            self.notebook.tab(tab_id, text="● " + current_text)

    def on_tab_changed(self, event):
        tab_id = self.notebook.select()
        for path, frame in self.tabs.items():
            if str(frame) == str(tab_id):
                self.current_file = path
                break

    def save_current(self):
        if not self.current_file or self.current_file not in self.editors:
            return

        editor = self.editors[self.current_file]
        content = editor.get("1.0", tk.END)

        try:
            with open(self.current_file, "w", encoding="utf-8") as f:
                f.write(content)

            tab_id = self.tabs[self.current_file]
            tab_name = self.current_file.split("/")[-1]
            self.notebook.tab(tab_id, text=tab_name)
            self.status.config(text=f"Saved: {self.current_file}")
        except Exception as e:
            messagebox.showerror("Save Error", str(e))

    def reload_current(self):
        if not self.current_file:
            return
        try:
            with open(self.current_file, "r", encoding="utf-8") as f:
                content = f.read()
            editor = self.editors.get(self.current_file)
            if editor:
                editor.delete("1.0", tk.END)
                editor.insert("1.0", content)
        except Exception as e:
            messagebox.showerror("Reload Error", str(e))

    def close_current(self):
        if not self.current_file:
            return
        tab_id = self.tabs[self.current_file]
        self.notebook.forget(tab_id)
        del self.tabs[self.current_file]
        del self.editors[self.current_file]
        self.current_file = None

    def test_script(self):
        if not self.current_file:
            return

        editor = self.editors.get(self.current_file)
        if not editor:
            return

        content = editor.get("1.0", tk.END)

        if self.current_file.endswith(".cs"):
            from ..exporters.csharp_transpiler import transpile_csharp_to_js
            try:
                js = transpile_csharp_to_js(content)
                self.engine.console.log("C# Transpilation Test:")
                self.engine.console.log(js[:500] + "..." if len(js) > 500 else js)
            except Exception as e:
                self.engine.console.log(f"Transpilation error: {e}", "error")
        else:
            self.engine.console.log("JavaScript syntax appears valid (basic check)")

    def new_file(self, default_name="NewScript.js"):
        from tkinter import simpledialog
        name = simpledialog.askstring("New Script", "Script name:", initialvalue=default_name)
        if name and self.engine.project:
            path = self.engine.project.path / "Assets" / "Scripts" / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text("// New script\n", encoding="utf-8")
            self.open_file(str(path), "// New script\n")
