"""Cross-platform font loading for Tkinter."""
import os
import platform
import tkinter as tk
from tkinter import font as tkfont


class FontLoader:
    """Handles loading custom TTF fonts into Tkinter across platforms."""

    _loaded = {}  # path -> family_name mapping

    @classmethod
    def load(cls, root: tk.Misc, font_path: str) -> str | None:
        """Load a font file and return its family name."""
        if not os.path.exists(font_path):
            return None

        # Already loaded?
        if font_path in cls._loaded:
            return cls._loaded[font_path]

        # Method 1: tkinter.font.Font(file=...) - most reliable
        family = cls._load_via_tkfont(root, font_path)
        if family:
            cls._loaded[font_path] = family
            return family

        # Method 2: Platform-specific
        system = platform.system()
        if system == "Windows":
            cls._load_windows(font_path)
        elif system == "Linux":
            cls._load_linux(font_path)
        elif system == "Darwin":
            cls._load_macos(font_path)

        # Check if font is now available
        root.update_idletasks()
        family = cls._find_family(root, font_path)
        if family:
            cls._loaded[font_path] = family
            return family

        return None

    @classmethod
    def _load_via_tkfont(cls, root: tk.Misc, font_path: str) -> str | None:
        """Primary method: use tkinter.font.Font to load the file."""
        try:
            # Create a temporary font object to register the file
            temp_font = tkfont.Font(root=root, file=font_path, size=10)
            family = temp_font.actual("family")
            if family:
                return family
        except Exception:
            pass
        return None

    @classmethod
    def _load_windows(cls, font_path: str) -> None:
        """Windows: use GDI32 to add font resource."""
        try:
            import ctypes
            from ctypes import wintypes

            gdi32 = ctypes.WinDLL("gdi32")
            FR_PRIVATE = 0x10

            path_buffer = ctypes.create_unicode_buffer(os.path.abspath(font_path))
            result = gdi32.AddFontResourceExW(ctypes.byref(path_buffer), FR_PRIVATE, 0)

            if result > 0:
                HWND_BROADCAST = 0xFFFF
                WM_FONTCHANGE = 0x001D
                ctypes.windll.user32.SendMessageW(HWND_BROADCAST, WM_FONTCHANGE, 0, 0)
        except Exception:
            pass

    @classmethod
    def _load_linux(cls, font_path: str) -> None:
        """Linux: copy to ~/.fonts/."""
        try:
            import shutil
            fonts_dir = os.path.expanduser("~/.fonts")
            os.makedirs(fonts_dir, exist_ok=True)
            dest = os.path.join(fonts_dir, os.path.basename(font_path))
            if not os.path.exists(dest):
                shutil.copy2(font_path, dest)
            try:
                import subprocess
                subprocess.run(["fc-cache", "-f"], capture_output=True, timeout=5)
            except Exception:
                pass
        except Exception:
            pass

    @classmethod
    def _load_macos(cls, font_path: str) -> None:
        """macOS: copy to ~/Library/Fonts/."""
        try:
            import shutil
            fonts_dir = os.path.expanduser("~/Library/Fonts")
            os.makedirs(fonts_dir, exist_ok=True)
            dest = os.path.join(fonts_dir, os.path.basename(font_path))
            if not os.path.exists(dest):
                shutil.copy2(font_path, dest)
        except Exception:
            pass

    @classmethod
    def _find_family(cls, root: tk.Misc, font_path: str) -> str | None:
        """Find the font family name after loading."""
        basename = os.path.splitext(os.path.basename(font_path))[0]
        families = set(tkfont.families(root))

        # Exact match
        if basename in families:
            return basename

        # Case-insensitive
        for fam in families:
            if fam.lower() == basename.lower():
                return fam

        # Partial match
        for fam in families:
            if basename.lower() in fam.lower():
                return fam

        return None


def get_bungee_font_family(root: tk.Misc) -> str:
    """Load Bungee font and return its family name."""
    # Check if already available
    families = set(tkfont.families(root))
    for fam in families:
        if "bungee" in fam.lower():
            return fam

    # Try to load from assets
    font_dir = os.path.join(os.path.dirname(__file__), "..", "assets", "fonts")
    bungee_path = os.path.join(font_dir, "Bungee-Regular.ttf")

    if os.path.exists(bungee_path):
        family = FontLoader.load(root, bungee_path)
        if family:
            return family

    # Check for any Bungee variant
    for fam in families:
        if "bungee" in fam.lower():
            return fam

    return "Segoe UI"
