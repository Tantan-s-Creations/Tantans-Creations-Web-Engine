"""Asset database and import pipeline"""
import os
import json
import uuid
import shutil
from pathlib import Path
from PIL import Image
from typing import Dict, List, Optional

class Asset:
    """Base asset class"""
    def __init__(self, name="", path=""):
        self.id = str(uuid.uuid4())
        self.name = name
        self.path = path  # Relative to Assets folder
        self.type = "Unknown"
        self.import_settings = {}
        self.thumbnail_path = ""

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "path": self.path,
            "type": self.type,
            "import_settings": self.import_settings
        }

class TextureAsset(Asset):
    def __init__(self, name="", path=""):
        super().__init__(name, path)
        self.type = "Texture"
        self.width = 0
        self.height = 0
        self.format = "RGBA"
        self.is_sprite = False
        self.sprite_rect = None

    def load_metadata(self, abs_path):
        try:
            with Image.open(abs_path) as img:
                self.width, self.height = img.size
                self.format = img.mode
        except Exception as e:
            print(f"Error loading texture metadata: {e}")

class MeshAsset(Asset):
    def __init__(self, name="", path=""):
        super().__init__(name, path)
        self.type = "Mesh"
        self.vertex_count = 0
        self.triangle_count = 0
        self.has_uv = False
        self.has_normals = False
        self.bounding_box = {"min": [0,0,0], "max": [1,1,1]}
        self.mesh_data = None  # Parsed mesh data

    def load_obj(self, abs_path):
        """Parse OBJ file"""
        vertices = []
        uvs = []
        normals = []
        faces = []

        try:
            with open(abs_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line.startswith('v '):
                        parts = line.split()[1:]
                        vertices.append([float(p) for p in parts[:3]])
                    elif line.startswith('vt '):
                        parts = line.split()[1:]
                        uvs.append([float(p) for p in parts[:2]])
                    elif line.startswith('vn '):
                        parts = line.split()[1:]
                        normals.append([float(p) for p in parts[:3]])
                    elif line.startswith('f '):
                        face = []
                        for part in line.split()[1:]:
                            indices = part.split('/')
                            v_idx = int(indices[0]) - 1 if indices[0] else 0
                            vt_idx = int(indices[1]) - 1 if len(indices) > 1 and indices[1] else -1
                            vn_idx = int(indices[2]) - 1 if len(indices) > 2 and indices[2] else -1
                            face.append((v_idx, vt_idx, vn_idx))
                        faces.append(face)
        except Exception as e:
            print(f"Error parsing OBJ: {e}")
            return

        self.vertex_count = len(vertices)
        self.triangle_count = len(faces)
        self.has_uv = len(uvs) > 0
        self.has_normals = len(normals) > 0

        # Calculate bounding box
        if vertices:
            mins = [min(v[i] for v in vertices) for i in range(3)]
            maxs = [max(v[i] for v in vertices) for i in range(3)]
            self.bounding_box = {"min": mins, "max": maxs}

        self.mesh_data = {
            "vertices": vertices,
            "uvs": uvs,
            "normals": normals,
            "faces": faces
        }

class MaterialAsset(Asset):
    def __init__(self, name="", path=""):
        super().__init__(name, path)
        self.type = "Material"
        self.shader = "Standard"
        self.properties = {
            "color": {"r": 1.0, "g": 1.0, "b": 1.0, "a": 1.0},
            "metallic": 0.0,
            "roughness": 0.5,
            "emission": {"r": 0.0, "g": 0.0, "b": 0.0},
            "main_texture": "",
            "normal_map": "",
            "tiling": {"x": 1, "y": 1},
            "offset": {"x": 0, "y": 0}
        }

class AudioAsset(Asset):
    def __init__(self, name="", path=""):
        super().__init__(name, path)
        self.type = "Audio"
        self.duration = 0.0
        self.sample_rate = 44100
        self.channels = 2

class ScriptAsset(Asset):
    def __init__(self, name="", path=""):
        super().__init__(name, path)
        self.type = "Script"
        self.language = "javascript"  # or "csharp"
        self.class_name = ""

class AssetDatabase:
    """Manages all project assets"""
    def __init__(self, project_path):
        self.project_path = Path(project_path)
        self.assets_path = self.project_path / "Assets"
        self.library_path = self.project_path / "Library"
        self.assets: Dict[str, Asset] = {}
        self.path_to_id: Dict[str, str] = {}

        self.assets_path.mkdir(parents=True, exist_ok=True)
        self.library_path.mkdir(parents=True, exist_ok=True)

    def scan_assets(self):
        """Scan Assets folder and import new files"""
        if not self.assets_path.exists():
            return

        for file_path in self.assets_path.rglob("*"):
            if file_path.is_file():
                rel_path = str(file_path.relative_to(self.assets_path)).replace("\\", "/")
                if rel_path not in self.path_to_id:
                    self.import_asset(file_path, rel_path)

    def import_asset(self, abs_path: Path, rel_path: str) -> Asset:
        """Import a single asset file"""
        ext = abs_path.suffix.lower()
        name = abs_path.stem

        asset = None
        if ext in ['.png', '.jpg', '.jpeg', '.bmp', '.tga', '.gif']:
            asset = TextureAsset(name, rel_path)
            asset.load_metadata(str(abs_path))
        elif ext in ['.obj', '.fbx']:
            asset = MeshAsset(name, rel_path)
            if ext == '.obj':
                asset.load_obj(str(abs_path))
        elif ext in ['.wav', '.mp3', '.ogg']:
            asset = AudioAsset(name, rel_path)
        elif ext in ['.cs', '.js', '.ts']:
            asset = ScriptAsset(name, rel_path)
            asset.language = "csharp" if ext == ".cs" else "javascript"
        elif ext in ['.mat', '.tcmat']:
            asset = MaterialAsset(name, rel_path)
        else:
            asset = Asset(name, rel_path)

        if asset:
            self.assets[asset.id] = asset
            self.path_to_id[rel_path] = asset.id

        return asset

    def get_asset_by_id(self, asset_id: str) -> Optional[Asset]:
        return self.assets.get(asset_id)

    def get_asset_by_path(self, rel_path: str) -> Optional[Asset]:
        aid = self.path_to_id.get(rel_path)
        if aid:
            return self.assets.get(aid)
        return None

    def save_database(self):
        db_path = self.library_path / "AssetDatabase.json"
        data = {"assets": [a.to_dict() for a in self.assets.values()]}
        with open(db_path, 'w') as f:
            json.dump(data, f, indent=2)

    def load_database(self):
        db_path = self.library_path / "AssetDatabase.json"
        if db_path.exists():
            with open(db_path, 'r') as f:
                data = json.load(f)
            for ad in data.get("assets", []):
                # Reconstruct asset based on type
                pass  # Simplified for now
