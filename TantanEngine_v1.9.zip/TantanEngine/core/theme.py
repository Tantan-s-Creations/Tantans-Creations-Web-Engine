"""Light editor theme and font helpers."""
from __future__ import annotations

import os
import tkinter as tk
from tkinter import ttk
from tkinter import font as tkfont

# New 3-color palette per user request
PALETTE = {
    # Backgrounds
    "bg": "#9fc5e8",
    "panel": "#9fc5e8",
    "panel_alt": "#9fc5e8",
    "surface": "#b8d4ec",
    "surface_alt": "#c5ddf0",
    "border": "#674ea7",
    # Text
    "text": "#674ea7",
    "muted": "#674ea7",
    "heading": "#674ea7",
    # Body text
    "body": "#9900ff",
    # Accents
    "blue": "#674ea7",
    "blue_soft": "#b8a8d8",
    "purple": "#674ea7",
    "purple_soft": "#c5b8e0",
    "pastel_blue": "#9fc5e8",
    "pastel_purple": "#674ea7",
    "pastel_blue_alt": "#9fc5e8",
    "pastel_purple_alt": "#674ea7",
    "success": "#5EE9B5",
    "success_soft": "#d5f5e8",
    "warning": "#D89A3B",
    "error": "#E95E7A",
    "green": "#5EE9B5",
}


def get_font_family(root: tk.Misc) -> str:
    """Get the best available font family, preferring Bungee."""
    try:
        from .font_utils import get_bungee_font_family
        return get_bungee_font_family(root)
    except Exception:
        pass

    try:
        families = set(tkfont.families(root))
        if "Bungee" in families:
            return "Bungee"
        for fam in families:
            if "bungee" in fam.lower():
                return fam
    except Exception:
        pass

    return "Segoe UI"


def apply_theme(root: tk.Misc, *, font_family: str | None = None) -> dict:
    """Apply a light theme to the Tk root and return the resolved theme settings."""
    resolved_font = font_family or get_font_family(root)

    title_font = tkfont.Font(family=resolved_font, size=13, weight="bold")
    body_font = tkfont.Font(family=resolved_font, size=10)
    ui_font = tkfont.Font(family=resolved_font, size=9)
    mono_font = tkfont.Font(family="Consolas", size=10)

    root._tantan_fonts = {
        "title": title_font,
        "body": body_font,
        "ui": ui_font,
        "mono": mono_font,
    }

    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except Exception:
        pass

    # Global font settings
    root.option_add("*Font", ui_font)
    root.option_add("*Menu.Font", ui_font)
    root.option_add("*TCombobox*Listbox.Font", ui_font)
    root.option_add("*Text.Font", mono_font)
    root.option_add("*Toplevel.background", PALETTE["bg"])
    root.option_add("*Menu.background", PALETTE["surface"])
    root.option_add("*Menu.foreground", PALETTE["text"])
    root.option_add("*Menu.activeBackground", PALETTE["blue_soft"])
    root.option_add("*Menu.activeForeground", PALETTE["heading"])

    # Frame
    style.configure("TFrame", background=PALETTE["bg"])

    # Labels
    style.configure("TLabel", background=PALETTE["bg"], foreground=PALETTE["text"], font=(resolved_font, 9))
    style.configure("Header.TLabel", background=PALETTE["bg"], foreground=PALETTE["heading"], font=(resolved_font, 13, "bold"))
    style.configure("Subtle.TLabel", background=PALETTE["bg"], foreground=PALETTE["muted"], font=(resolved_font, 9))
    style.configure("Body.TLabel", background=PALETTE["bg"], foreground=PALETTE["body"], font=(resolved_font, 9))

    # Buttons with 4px borders
    style.configure("TButton", background=PALETTE["surface"], foreground=PALETTE["text"], font=(resolved_font, 9), padding=(10, 6))
    style.map("TButton", background=[("active", PALETTE["blue_soft"]), ("pressed", PALETTE["purple_soft"])], relief=[("pressed", "sunken")])
    style.configure("Accent.TButton", background=PALETTE["blue_soft"], foreground=PALETTE["heading"], font=(resolved_font, 9), padding=(10, 6))
    style.map("Accent.TButton", background=[("active", PALETTE["pastel_blue_alt"])])
    style.configure("Success.TButton", background=PALETTE["success_soft"], foreground=PALETTE["success"], font=(resolved_font, 9), padding=(10, 6))
    style.map("Success.TButton", background=[("active", "#b5e8d0")])
    style.configure("Danger.TButton", background="#ffe0e5", foreground=PALETTE["error"], font=(resolved_font, 9), padding=(10, 6))
    style.map("Danger.TButton", background=[("active", "#ffd0d8")])

    # Labelframe with 4px border
    style.configure("TLabelframe", background=PALETTE["bg"], foreground=PALETTE["heading"], bordercolor=PALETTE["border"], relief="solid", borderwidth=4)
    style.configure("TLabelframe.Label", background=PALETTE["bg"], foreground=PALETTE["heading"], font=(resolved_font, 10))

    # Notebook with 4px border
    style.configure("TNotebook", background=PALETTE["bg"], borderwidth=4)
    style.configure("TNotebook.Tab", background=PALETTE["panel"], foreground=PALETTE["text"], padding=(12, 7), font=(resolved_font, 9))
    style.map("TNotebook.Tab", background=[("selected", PALETTE["surface"]), ("active", PALETTE["pastel_purple"])])

    # Treeview with 4px border
    style.configure("Treeview", background=PALETTE["surface"], fieldbackground=PALETTE["surface"], foreground=PALETTE["text"], rowheight=24, bordercolor=PALETTE["border"], font=(resolved_font, 9), borderwidth=4)
    style.map("Treeview", background=[("selected", PALETTE["blue_soft"])], foreground=[("selected", PALETTE["heading"])])
    style.configure("Treeview.Heading", background=PALETTE["panel"], foreground=PALETTE["heading"], relief="flat", font=(resolved_font, 10))

    # Entry / Combobox / Spinbox with 4px border
    style.configure("TEntry", fieldbackground=PALETTE["surface_alt"], foreground=PALETTE["text"], insertcolor=PALETTE["text"], font=(resolved_font, 9), borderwidth=4)
    style.configure("TCombobox", fieldbackground=PALETTE["surface_alt"], foreground=PALETTE["text"], font=(resolved_font, 9), borderwidth=4)
    style.map("TCombobox", fieldbackground=[("readonly", PALETTE["surface_alt"])])
    style.configure("TCheckbutton", background=PALETTE["bg"], foreground=PALETTE["text"], font=(resolved_font, 9))
    style.configure("TRadiobutton", background=PALETTE["bg"], foreground=PALETTE["text"], font=(resolved_font, 9))
    style.configure("TSpinbox", fieldbackground=PALETTE["surface_alt"], foreground=PALETTE["text"], font=(resolved_font, 9), borderwidth=4)

    # Misc
    style.configure("Sunk.TLabel", background=PALETTE["panel"], foreground=PALETTE["text"], padding=(8, 6))
    style.configure("TSeparator", background=PALETTE["border"])

    # Progressbar
    style.configure("Horizontal.TProgressbar", background=PALETTE["blue"], troughcolor=PALETTE["surface_alt"], bordercolor=PALETTE["border"])

    # Scale
    style.configure("TScale", background=PALETTE["bg"], troughcolor=PALETTE["surface_alt"])

    return {
        "font_family": resolved_font,
        "title_font": title_font,
        "body_font": body_font,
        "ui_font": ui_font,
        "mono_font": mono_font,
        "palette": PALETTE,
    }
