"""Entity Component System for Tantan's Creations Web Engine"""
import uuid
import json
from typing import Dict, List, Any, Optional
from .math3d import Vector3, Quaternion, Vector2

class Component:
    """Base class for all components"""
    def __init__(self):
        self.entity = None
        self.enabled = True

    def get_type_name(self):
        return self.__class__.__name__

    def to_dict(self) -> dict:
        return {"type": self.get_type_name(), "enabled": self.enabled}

    @classmethod
    def from_dict(cls, data: dict) -> "Component":
        c = cls()
        c.enabled = data.get("enabled", True)
        return c

    def copy(self):
        return self.from_dict(self.to_dict())

class Transform(Component):
    """Transform component - position, rotation, scale"""
    def __init__(self):
        super().__init__()
        self.position = Vector3(0, 0, 0)
        self.rotation = Vector3(0, 0, 0)  # Euler angles in degrees
        self.scale = Vector3(1, 1, 1)

    @property
    def forward(self):
        from math import radians, cos, sin
        yaw = radians(self.rotation.y)
        pitch = radians(self.rotation.x)
        return Vector3(
            cos(pitch) * sin(yaw),
            -sin(pitch),
            cos(pitch) * cos(yaw),
        ).normalized()

    @property
    def right(self):
        from math import radians, cos, sin
        yaw = radians(self.rotation.y + 90.0)
        return Vector3(sin(yaw), 0.0, cos(yaw)).normalized()

    @property
    def up(self):
        return Vector3(0, 1, 0)

    def translate(self, x=0.0, y=0.0, z=0.0):
        if isinstance(x, Vector3):
            self.position = self.position + x
        else:
            self.position = self.position + Vector3(x, y, z)
        return self

    def rotate(self, x=0.0, y=0.0, z=0.0):
        if isinstance(x, Vector3):
            self.rotation = self.rotation + x
        else:
            self.rotation = self.rotation + Vector3(x, y, z)
        return self

    def look_at(self, target):
        if not isinstance(target, Vector3):
            target = Vector3.from_dict(target if isinstance(target, dict) else {})
        direction = (target - self.position).normalized()
        # Basic yaw/pitch approximation.
        import math
        self.rotation.y = math.degrees(math.atan2(direction.x, direction.z))
        self.rotation.x = math.degrees(math.atan2(-direction.y, (direction.x ** 2 + direction.z ** 2) ** 0.5))
        return self

    def get_matrix(self):
        from .math3d import Matrix4
        t = Matrix4.translation(self.position.x, self.position.y, self.position.z)
        rx = Matrix4.rotation_x(self.rotation.x)
        ry = Matrix4.rotation_y(self.rotation.y)
        rz = Matrix4.rotation_z(self.rotation.z)
        s = Matrix4.scale(self.scale.x, self.scale.y, self.scale.z)
        return t @ rx @ ry @ rz @ s

    def to_dict(self):
        d = super().to_dict()
        d["position"] = self.position.to_dict()
        d["rotation"] = self.rotation.to_dict()
        d["scale"] = self.scale.to_dict()
        return d

    @classmethod
    def from_dict(cls, data):
        c = super().from_dict(data)
        c.position = Vector3.from_dict(data.get("position", {}))
        c.rotation = Vector3.from_dict(data.get("rotation", {}))
        c.scale = Vector3.from_dict(data.get("scale", {}))
        return c

class MeshFilter(Component):
    """Reference to a mesh asset"""
    def __init__(self):
        super().__init__()
        self.mesh_asset_id = ""  # GUID reference to asset

    def to_dict(self):
        d = super().to_dict()
        d["mesh_asset_id"] = self.mesh_asset_id
        return d

    @classmethod
    def from_dict(cls, data):
        c = super().from_dict(data)
        c.mesh_asset_id = data.get("mesh_asset_id", "")
        return c

class MeshRenderer(Component):
    """Rendering settings for a mesh"""
    def __init__(self):
        super().__init__()
        self.material_asset_id = ""
        self.cast_shadows = True
        self.receive_shadows = True

    def to_dict(self):
        d = super().to_dict()
        d["material_asset_id"] = self.material_asset_id
        d["cast_shadows"] = self.cast_shadows
        d["receive_shadows"] = self.receive_shadows
        return d

    @classmethod
    def from_dict(cls, data):
        c = super().from_dict(data)
        c.material_asset_id = data.get("material_asset_id", "")
        c.cast_shadows = data.get("cast_shadows", True)
        c.receive_shadows = data.get("receive_shadows", True)
        return c

class SpriteRenderer(Component):
    """2D sprite rendering"""
    def __init__(self):
        super().__init__()
        self.texture_asset_id = ""
        self.color = {"r": 1.0, "g": 1.0, "b": 1.0, "a": 1.0}
        self.flip_x = False
        self.flip_y = False
        self.sorting_layer = 0
        self.sorting_order = 0

    def to_dict(self):
        d = super().to_dict()
        d["texture_asset_id"] = self.texture_asset_id
        d["color"] = self.color
        d["flip_x"] = self.flip_x
        d["flip_y"] = self.flip_y
        d["sorting_layer"] = self.sorting_layer
        d["sorting_order"] = self.sorting_order
        return d

    @classmethod
    def from_dict(cls, data):
        c = super().from_dict(data)
        c.texture_asset_id = data.get("texture_asset_id", "")
        c.color = data.get("color", {"r": 1.0, "g": 1.0, "b": 1.0, "a": 1.0})
        c.flip_x = data.get("flip_x", False)
        c.flip_y = data.get("flip_y", False)
        c.sorting_layer = data.get("sorting_layer", 0)
        c.sorting_order = data.get("sorting_order", 0)
        return c

class Camera(Component):
    """Camera component"""
    def __init__(self):
        super().__init__()
        self.fov = 60.0
        self.near_clip = 0.1
        self.far_clip = 1000.0
        self.clear_color = {"r": 0.15, "g": 0.15, "b": 0.18, "a": 1.0}
        self.is_orthographic = False
        self.orthographic_size = 5.0
        self.viewport_rect = {"x": 0, "y": 0, "width": 1, "height": 1}
        self.depth = 0

    def to_dict(self):
        d = super().to_dict()
        d["fov"] = self.fov
        d["near_clip"] = self.near_clip
        d["far_clip"] = self.far_clip
        d["clear_color"] = self.clear_color
        d["is_orthographic"] = self.is_orthographic
        d["orthographic_size"] = self.orthographic_size
        d["viewport_rect"] = self.viewport_rect
        d["depth"] = self.depth
        return d

    @classmethod
    def from_dict(cls, data):
        c = super().from_dict(data)
        c.fov = data.get("fov", 60.0)
        c.near_clip = data.get("near_clip", 0.1)
        c.far_clip = data.get("far_clip", 1000.0)
        c.clear_color = data.get("clear_color", {"r": 0.15, "g": 0.15, "b": 0.18, "a": 1.0})
        c.is_orthographic = data.get("is_orthographic", False)
        c.orthographic_size = data.get("orthographic_size", 5.0)
        c.viewport_rect = data.get("viewport_rect", {"x": 0, "y": 0, "width": 1, "height": 1})
        c.depth = data.get("depth", 0)
        return c

class Light(Component):
    """Light component"""
    def __init__(self):
        super().__init__()
        self.light_type = "Directional"  # Directional, Point, Spot
        self.color = {"r": 1.0, "g": 1.0, "b": 1.0}
        self.intensity = 1.0
        self.range = 10.0
        self.spot_angle = 30.0

    def to_dict(self):
        d = super().to_dict()
        d["light_type"] = self.light_type
        d["color"] = self.color
        d["intensity"] = self.intensity
        d["range"] = self.range
        d["spot_angle"] = self.spot_angle
        return d

    @classmethod
    def from_dict(cls, data):
        c = super().from_dict(data)
        c.light_type = data.get("light_type", "Directional")
        c.color = data.get("color", {"r": 1.0, "g": 1.0, "b": 1.0})
        c.intensity = data.get("intensity", 1.0)
        c.range = data.get("range", 10.0)
        c.spot_angle = data.get("spot_angle", 30.0)
        return c

class Script(Component):
    """Script component - references a code file"""
    def __init__(self):
        super().__init__()
        self.language = "javascript"  # "csharp" or "javascript"
        self.source_file = ""  # Path relative to project
        self.source_code = ""  # Inline code for small scripts
        self.class_name = ""
        self.properties = {}  # Serialized public variables

    def to_dict(self):
        d = super().to_dict()
        d["language"] = self.language
        d["source_file"] = self.source_file
        d["source_code"] = self.source_code
        d["class_name"] = self.class_name
        d["properties"] = self.properties
        return d

    @classmethod
    def from_dict(cls, data):
        c = super().from_dict(data)
        c.language = data.get("language", "javascript")
        c.source_file = data.get("source_file", "")
        c.source_code = data.get("source_code", "")
        c.class_name = data.get("class_name", "")
        c.properties = data.get("properties", {})
        return c

class RigidBody(Component):
    """Physics rigidbody"""
    def __init__(self):
        super().__init__()
        self.mass = 1.0
        self.use_gravity = True
        self.is_kinematic = False
        self.velocity = Vector3(0, 0, 0)
        self.angular_velocity = Vector3(0, 0, 0)
        self.drag = 0.0
        self.angular_drag = 0.05

    def to_dict(self):
        d = super().to_dict()
        d["mass"] = self.mass
        d["use_gravity"] = self.use_gravity
        d["is_kinematic"] = self.is_kinematic
        d["velocity"] = self.velocity.to_dict()
        d["angular_velocity"] = self.angular_velocity.to_dict()
        d["drag"] = self.drag
        d["angular_drag"] = self.angular_drag
        return d

    @classmethod
    def from_dict(cls, data):
        c = super().from_dict(data)
        c.mass = data.get("mass", 1.0)
        c.use_gravity = data.get("use_gravity", True)
        c.is_kinematic = data.get("is_kinematic", False)
        c.velocity = Vector3.from_dict(data.get("velocity", {}))
        c.angular_velocity = Vector3.from_dict(data.get("angular_velocity", {}))
        c.drag = data.get("drag", 0.0)
        c.angular_drag = data.get("angular_drag", 0.05)
        return c

class BoxCollider(Component):
    """Box collider"""
    def __init__(self):
        super().__init__()
        self.size = Vector3(1, 1, 1)
        self.center = Vector3(0, 0, 0)
        self.is_trigger = False

    def to_dict(self):
        d = super().to_dict()
        d["size"] = self.size.to_dict()
        d["center"] = self.center.to_dict()
        d["is_trigger"] = self.is_trigger
        return d

    @classmethod
    def from_dict(cls, data):
        c = super().from_dict(data)
        c.size = Vector3.from_dict(data.get("size", {}))
        c.center = Vector3.from_dict(data.get("center", {}))
        c.is_trigger = data.get("is_trigger", False)
        return c

# Component registry for deserialization
COMPONENT_REGISTRY = {
    "Transform": Transform,
    "MeshFilter": MeshFilter,
    "MeshRenderer": MeshRenderer,
    "SpriteRenderer": SpriteRenderer,
    "Camera": Camera,
    "Light": Light,
    "Script": Script,
    "RigidBody": RigidBody,
    "BoxCollider": BoxCollider,
}

def component_from_dict(data: dict) -> Component:
    type_name = data.get("type", "")
    cls = COMPONENT_REGISTRY.get(type_name)
    if cls:
        return cls.from_dict(data)
    return None

class Entity:
    """GameObject equivalent - container for components"""
    def __init__(self, name="New Entity"):
        self.id = str(uuid.uuid4())
        self.name = name
        self.active = True
        self.components: List[Component] = []
        self.parent: Optional[Entity] = None
        self.children: List[Entity] = []
        self.scene = None

    def add_component(self, comp_type) -> Component:
        """Add a component by class type"""
        comp = comp_type()
        comp.entity = self
        self.components.append(comp)
        return comp

    def get_component(self, comp_type) -> Optional[Component]:
        for c in self.components:
            if isinstance(c, comp_type):
                return c
        return None

    def remove_component(self, comp):
        if comp in self.components:
            self.components.remove(comp)

    def get_transform(self) -> Transform:
        return self.get_component(Transform)

    def set_parent(self, parent):
        if self.parent:
            self.parent.children.remove(self)
        self.parent = parent
        if parent:
            parent.children.append(self)

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "active": self.active,
            "components": [c.to_dict() for c in self.components],
            "children": [c.id for c in self.children],
            "parent_id": self.parent.id if self.parent else None
        }

    @classmethod
    def from_dict(cls, data, scene=None):
        e = cls(data.get("name", "Entity"))
        e.id = data.get("id", str(uuid.uuid4()))
        e.active = data.get("active", True)
        e.scene = scene
        for comp_data in data.get("components", []):
            comp = component_from_dict(comp_data)
            if comp:
                comp.entity = e
                e.components.append(comp)
        return e

class Scene:
    """Scene container"""
    def __init__(self, name="New Scene"):
        self.name = name
        self.entities: Dict[str, Entity] = {}
        self.root_entities: List[Entity] = []
        self.settings = {
            "ambient_light": {"r": 0.2, "g": 0.2, "b": 0.2},
            "gravity": {"x": 0, "y": -9.81, "z": 0},
            "physics_timestep": 0.02
        }

    def create_entity(self, name="New Entity", parent=None) -> Entity:
        e = Entity(name)
        e.scene = self
        e.add_component(Transform)
        self.entities[e.id] = e
        if parent and parent in self.entities.values():
            e.set_parent(parent)
        else:
            self.root_entities.append(e)
        return e

    def destroy_entity(self, entity):
        if entity.id in self.entities:
            # Reparent children to root or parent
            for child in entity.children:
                child.set_parent(entity.parent)
            if entity.parent:
                entity.parent.children.remove(entity)
            elif entity in self.root_entities:
                self.root_entities.remove(entity)
            del self.entities[entity.id]

    def find_entity(self, name) -> Optional[Entity]:
        for e in self.entities.values():
            if e.name == name:
                return e
        return None

    def get_entities_with_component(self, comp_type) -> List[Entity]:
        return [e for e in self.entities.values() if e.get_component(comp_type)]

    def to_dict(self):
        return {
            "name": self.name,
            "settings": self.settings,
            "entities": [e.to_dict() for e in self.root_entities]
        }

    @classmethod
    def from_dict(cls, data):
        scene = cls(data.get("name", "Scene"))
        scene.settings = data.get("settings", scene.settings)

        # First pass: create all entities
        entity_data_list = []
        def collect_entities(ed_list):
            for ed in ed_list:
                entity_data_list.append(ed)
                collect_entities(ed.get("children", []))
        collect_entities(data.get("entities", []))

        for ed in entity_data_list:
            e = Entity.from_dict(ed, scene)
            scene.entities[e.id] = e

        # Second pass: rebuild hierarchy
        def build_hierarchy(ed_list, parent=None):
            for ed in ed_list:
                e = scene.entities.get(ed["id"])
                if e:
                    if parent:
                        e.set_parent(parent)
                    elif e not in scene.root_entities:
                        scene.root_entities.append(e)
                    build_hierarchy(ed.get("children", []), e)

        build_hierarchy(data.get("entities", []))
        return scene
