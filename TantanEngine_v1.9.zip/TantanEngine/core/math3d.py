"""3D Math library for Tantan's Creations Web Engine"""
import math
import numpy as np

class Vector3:
    __slots__ = ['x', 'y', 'z']
    def __init__(self, x=0.0, y=0.0, z=0.0):
        self.x = float(x)
        self.y = float(y)
        self.z = float(z)

    def __add__(self, other):
        if isinstance(other, Vector3):
            return Vector3(self.x + other.x, self.y + other.y, self.z + other.z)
        return Vector3(self.x + other, self.y + other, self.z + other)

    def __sub__(self, other):
        if isinstance(other, Vector3):
            return Vector3(self.x - other.x, self.y - other.y, self.z - other.z)
        return Vector3(self.x - other, self.y - other, self.z - other)

    def __mul__(self, other):
        if isinstance(other, Vector3):
            return Vector3(self.x * other.x, self.y * other.y, self.z * other.z)
        return Vector3(self.x * other, self.y * other, self.z * other)

    def __truediv__(self, other):
        if isinstance(other, Vector3):
            return Vector3(self.x / other.x, self.y / other.y, self.z / other.z)
        return Vector3(self.x / other, self.y / other, self.z / other)

    def __neg__(self):
        return Vector3(-self.x, -self.y, -self.z)

    def __repr__(self):
        return f"Vector3({self.x:.3f}, {self.y:.3f}, {self.z:.3f})"

    def to_dict(self):
        return {"x": self.x, "y": self.y, "z": self.z}

    @classmethod
    def from_dict(cls, d):
        return cls(d.get("x", 0), d.get("y", 0), d.get("z", 0))

    def to_array(self):
        return np.array([self.x, self.y, self.z, 1.0], dtype=np.float32)

    @property
    def magnitude(self):
        return math.sqrt(self.x**2 + self.y**2 + self.z**2)

    def normalized(self):
        mag = self.magnitude
        if mag < 0.00001:
            return Vector3(0, 0, 0)
        return Vector3(self.x / mag, self.y / mag, self.z / mag)

    def dot(self, other):
        return self.x * other.x + self.y * other.y + self.z * other.z

    def cross(self, other):
        return Vector3(
            self.y * other.z - self.z * other.y,
            self.z * other.x - self.x * other.z,
            self.x * other.y - self.y * other.x
        )

class Vector2:
    __slots__ = ['x', 'y']
    def __init__(self, x=0.0, y=0.0):
        self.x = float(x)
        self.y = float(y)
    def to_dict(self):
        return {"x": self.x, "y": self.y}
    @classmethod
    def from_dict(cls, d):
        return cls(d.get("x", 0), d.get("y", 0))

class Quaternion:
    def __init__(self, x=0.0, y=0.0, z=0.0, w=1.0):
        self.x, self.y, self.z, self.w = float(x), float(y), float(z), float(w)

    def to_dict(self):
        return {"x": self.x, "y": self.y, "z": self.z, "w": self.w}

    @classmethod
    def from_dict(cls, d):
        return cls(d.get("x", 0), d.get("y", 0), d.get("z", 0), d.get("w", 1))

    @classmethod
    def from_euler(cls, ex, ey, ez):
        # Euler angles in degrees to quaternion
        ex, ey, ez = math.radians(ex), math.radians(ey), math.radians(ez)
        cx, cy, cz = math.cos(ex * 0.5), math.cos(ey * 0.5), math.cos(ez * 0.5)
        sx, sy, sz = math.sin(ex * 0.5), math.sin(ey * 0.5), math.sin(ez * 0.5)
        return cls(
            sx * cy * cz - cx * sy * sz,
            cx * sy * cz + sx * cy * sz,
            cx * cy * sz - sx * sy * cz,
            cx * cy * cz + sx * sy * sz
        )

    def to_euler(self):
        # Quaternion to Euler angles in degrees
        sinr_cosp = 2.0 * (self.w * self.x + self.y * self.z)
        cosr_cosp = 1.0 - 2.0 * (self.x * self.x + self.y * self.y)
        roll = math.atan2(sinr_cosp, cosr_cosp)

        sinp = 2.0 * (self.w * self.y - self.z * self.x)
        if abs(sinp) >= 1:
            pitch = math.copysign(math.pi / 2, sinp)
        else:
            pitch = math.asin(sinp)

        siny_cosp = 2.0 * (self.w * self.z + self.x * self.y)
        cosy_cosp = 1.0 - 2.0 * (self.y * self.y + self.z * self.z)
        yaw = math.atan2(siny_cosp, cosy_cosp)

        return Vector3(math.degrees(roll), math.degrees(pitch), math.degrees(yaw))

    def to_matrix4(self):
        # Convert quaternion to 4x4 rotation matrix
        x, y, z, w = self.x, self.y, self.z, self.w
        xx, xy, xz, xw = x*x, x*y, x*z, x*w
        yy, yz, yw = y*y, y*z, y*w
        zz, zw = z*z, z*w
        return Matrix4([
            [1-2*(yy+zz), 2*(xy-zw), 2*(xz+yw), 0],
            [2*(xy+zw), 1-2*(xx+zz), 2*(yz-xw), 0],
            [2*(xz-yw), 2*(yz+xw), 1-2*(xx+yy), 0],
            [0, 0, 0, 1]
        ])

class Matrix4:
    def __init__(self, data=None):
        if data is None:
            self.m = np.identity(4, dtype=np.float32)
        else:
            self.m = np.array(data, dtype=np.float32)

    def __matmul__(self, other):
        if isinstance(other, Matrix4):
            return Matrix4(self.m @ other.m)
        elif isinstance(other, Vector3):
            v = np.array([other.x, other.y, other.z, 1.0])
            r = self.m @ v
            return Vector3(r[0], r[1], r[2])
        return None

    @classmethod
    def identity(cls):
        return cls()

    @classmethod
    def translation(cls, x, y, z):
        m = np.identity(4, dtype=np.float32)
        m[0,3] = x
        m[1,3] = y
        m[2,3] = z
        return cls(m)

    @classmethod
    def scale(cls, x, y, z):
        m = np.identity(4, dtype=np.float32)
        m[0,0] = x
        m[1,1] = y
        m[2,2] = z
        return cls(m)

    @classmethod
    def rotation_x(cls, angle_deg):
        a = math.radians(angle_deg)
        c, s = math.cos(a), math.sin(a)
        return cls([
            [1, 0, 0, 0],
            [0, c, -s, 0],
            [0, s, c, 0],
            [0, 0, 0, 1]
        ])

    @classmethod
    def rotation_y(cls, angle_deg):
        a = math.radians(angle_deg)
        c, s = math.cos(a), math.sin(a)
        return cls([
            [c, 0, s, 0],
            [0, 1, 0, 0],
            [-s, 0, c, 0],
            [0, 0, 0, 1]
        ])

    @classmethod
    def rotation_z(cls, angle_deg):
        a = math.radians(angle_deg)
        c, s = math.cos(a), math.sin(a)
        return cls([
            [c, -s, 0, 0],
            [s, c, 0, 0],
            [0, 0, 1, 0],
            [0, 0, 0, 1]
        ])

    @classmethod
    def perspective(cls, fov_deg, aspect, near, far):
        f = 1.0 / math.tan(math.radians(fov_deg) / 2.0)
        nf = 1.0 / (near - far)
        return cls([
            [f / aspect, 0, 0, 0],
            [0, f, 0, 0],
            [0, 0, (far + near) * nf, (2 * far * near) * nf],
            [0, 0, -1, 0]
        ])

    @classmethod
    def ortho(cls, left, right, bottom, top, near, far):
        rl, tb, fn = right - left, top - bottom, far - near
        return cls([
            [2.0 / rl, 0, 0, -(right + left) / rl],
            [0, 2.0 / tb, 0, -(top + bottom) / tb],
            [0, 0, -2.0 / fn, -(far + near) / fn],
            [0, 0, 0, 1]
        ])

    def to_dict(self):
        return self.m.tolist()

    @classmethod
    def from_dict(cls, d):
        return cls(d)
