"""Tantan's Creations Web Engine"""
__version__ = "1.9.0"
__author__ = "Tantan's Creations"
