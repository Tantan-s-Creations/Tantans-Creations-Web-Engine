#!/usr/bin/env python3
"""Tantan's Creations Web Engine - Main Entry Point"""
import os
import sys

# Add engine to path
engine_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if engine_dir not in sys.path:
    sys.path.insert(0, engine_dir)

from TantanEngine.editor.launcher import ProjectLauncher


def main():
    """Launch the engine."""
    launcher = ProjectLauncher()
    launcher.run()


if __name__ == "__main__":
    main()
