// Rotator.js
// Simple object rotation script

function Start() {
    this.rotationSpeed = this.properties.rotationSpeed || 30;
    this.axis = this.properties.axis || "y";
}

function Update() {
    var dt = TEngine.deltaTime;
    var speed = this.rotationSpeed;

    if (this.axis === "x") {
        this.transform.rotate(speed * dt, 0, 0);
    } else if (this.axis === "y") {
        this.transform.rotate(0, speed * dt, 0);
    } else if (this.axis === "z") {
        this.transform.rotate(0, 0, speed * dt);
    }
}
