// FPSController.js
// First-person shooter controller

function Start() {
    console.log("FPS controller initialized");
    this.moveSpeed = this.properties.moveSpeed || 5;
    this.lookSpeed = this.properties.lookSpeed || 2;
}

function Update() {
    var h = TEngine.input.getAxis("Horizontal");
    var v = TEngine.input.getAxis("Vertical");

    var forward = this.transform.forward;
    var right = this.transform.right;

    var move = forward.multiply(v).add(right.multiply(h)).normalized();
    move = move.multiply(this.moveSpeed * TEngine.deltaTime);

    this.transform.translate(move.x, 0, move.z);

    var mouseDelta = TEngine.input.mousePosition;
    var rotY = mouseDelta.x * this.lookSpeed;
    this.transform.rotate(0, rotY, 0);
}
