using TantanEngine;
using System.Collections;

public class PlayerController : MonoBehaviour
{
    public float speed = 5.0f;
    public float jumpForce = 10.0f;
    private bool grounded = false;

    void Start()
    {
        Debug.Log("Player controller started");
    }

    void Update()
    {
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");

        if (h != 0 || v != 0)
        {
            Vector3 move = new Vector3(h, 0, v).normalized * speed * Time.deltaTime;
            transform.Translate(move);
        }

        if (Input.GetButton("Jump") && grounded)
        {
            transform.Translate(0, jumpForce * Time.deltaTime, 0);
            grounded = false;
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.name == "Ground")
        {
            grounded = true;
        }
    }
}
