// PlayerController.js
// 2D Platformer character controller

function Start() {
    console.log("Player controller initialized");
    this.speed = this.properties.speed || 5;
    this.jumpForce = 10;
    this.grounded = false;
}

function Update() {
    var h = TEngine.input.getAxis("Horizontal");
    if (h !== 0) {
        var moveX = h * this.speed * TEngine.deltaTime;
        this.transform.translate(moveX, 0, 0);
    }

    if (TEngine.input.getButton("Jump") && this.grounded) {
        this.transform.translate(0, this.jumpForce * TEngine.deltaTime, 0);
        this.grounded = false;
    }

    if (!this.grounded) {
        this.transform.translate(0, -9.81 * TEngine.deltaTime * TEngine.deltaTime, 0);
    }
}

function OnCollisionEnter(other) {
    if (other.name === "Ground") {
        this.grounded = true;
    }
}
