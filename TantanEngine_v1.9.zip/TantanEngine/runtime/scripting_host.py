"""Script execution host for in-engine playtesting."""
from __future__ import annotations

import os
import re
from types import SimpleNamespace
from typing import Dict, Any


class ScriptingHost:
    """Hosts and executes game scripts during play mode."""

    def __init__(self, scene, asset_db, project_path):
        self.scene = scene
        self.asset_db = asset_db
        self.project_path = project_path
        self.script_instances: Dict[str, Any] = {}
        self.globals = {}
        self._setup_environment()

    def _setup_environment(self):
        from ..core.math3d import Vector3

        self.globals = {
            "Vector3": Vector3,
            "print": self._script_print,
            "find_object": self._find_object,
            "instantiate": self._instantiate,
            "destroy": self._destroy,
            "delta_time": 0.016,
            "time": 0.0,
        }

    def _script_print(self, *args):
        msg = " ".join(str(a) for a in args)
        print(f"[SCRIPT] {msg}")

    def _find_object(self, name: str):
        return self.scene.find_entity(name)

    def _instantiate(self, template, position=None):
        # Simplified placeholder for play mode; can be expanded later.
        return None

    def _destroy(self, obj):
        if hasattr(obj, "id"):
            self.scene.destroy_entity(obj)

    def load_scripts(self):
        """Load all script components from scene."""
        from ..core.ecs import Script
        for entity in self.scene.entities.values():
            script_comp = entity.get_component(Script)
            if script_comp and script_comp.enabled:
                self._load_script(entity, script_comp)

    def _load_script(self, entity, script_comp):
        """Load and compile a script for an entity."""
        code = ""
        if script_comp.source_code:
            code = script_comp.source_code
        elif script_comp.source_file:
            path = os.path.join(self.project_path, "Assets", script_comp.source_file)
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    code = f.read()

        if not code:
            return

        transform = entity.get_transform()
        instance = SimpleNamespace(
            entity=entity,
            transform=transform,
            properties=dict(script_comp.properties or {}),
            start_called=False,
        )

        try:
            if script_comp.language == "javascript":
                wrapped = self._wrap_javascript(code)
                namespace: Dict[str, Any] = {}
                exec(wrapped, dict(self.globals), namespace)
                start_fn = namespace.get("Start") or namespace.get("start")
                update_fn = namespace.get("Update") or namespace.get("update")
                fixed_fn = namespace.get("FixedUpdate") or namespace.get("fixedupdate")
                if start_fn or update_fn or fixed_fn:
                    self.script_instances[entity.id] = {
                        "instance": instance,
                        "Start": start_fn,
                        "Update": update_fn,
                        "FixedUpdate": fixed_fn,
                        "start_called": False,
                    }
            else:
                # C# play mode execution is intentionally conservative; the build pipeline handles it more fully.
                wrapped = self._wrap_javascript(code)
                namespace: Dict[str, Any] = {}
                exec(wrapped, dict(self.globals), namespace)
                start_fn = namespace.get("Start")
                update_fn = namespace.get("Update")
                if start_fn or update_fn:
                    self.script_instances[entity.id] = {
                        "instance": instance,
                        "Start": start_fn,
                        "Update": update_fn,
                        "FixedUpdate": namespace.get("FixedUpdate"),
                        "start_called": False,
                    }
        except Exception as e:
            print(f"Script error on {entity.name}: {e}")

    def _wrap_javascript(self, code: str) -> str:
        """Very small JS-to-Python wrapper for common editor templates."""
        code = code.replace("\r\n", "\n")
        code = code.replace("console.log", "print")
        code = code.replace("console.warn", "print")
        code = code.replace("console.error", "print")
        code = code.replace("true", "True").replace("false", "False").replace("null", "None")
        code = code.replace("&&", " and ").replace("||", " or ")
        code = re.sub(r"\bvar\s+", "", code)
        code = re.sub(r"\blet\s+", "", code)
        code = re.sub(r"\bconst\s+", "", code)
        def _replace_function(match):
            name = match.group(1)
            params = match.group(2).strip()
            if params:
                return f"def {name}(self, {params}):"
            return f"def {name}(self):"

        code = re.sub(r"function\s+(\w+)\s*\((.*?)\)\s*{", _replace_function, code)
        code = re.sub(r"}\s*else\s*{", "\nelse:\n", code)
        code = re.sub(r"}\s*else if\s*\((.*?)\)\s*{", r"\nelif (\1):\n", code)
        code = re.sub(r"if\s*\((.*?)\)\s*{", r"if (\1):", code)
        code = re.sub(r"while\s*\((.*?)\)\s*{", r"while (\1):", code)
        code = re.sub(r"for\s*\((.*?)\)\s*{", r"for (\1):", code)
        code = code.replace("this.", "self.")
        code = re.sub(r";\s*$", "", code, flags=re.MULTILINE)

        lines = []
        indent = 0
        for raw in code.split("\n"):
            stripped = raw.strip()
            if not stripped:
                lines.append("")
                continue
            open_braces = stripped.count("{")
            close_braces = stripped.count("}")
            stripped = stripped.replace("{", "").replace("}", "")
            if stripped.startswith(("else:", "elif ")):
                indent = max(0, indent - 1)
            if stripped.startswith("def ") and not stripped.endswith(":"):
                stripped += ":"
            if stripped.startswith("if ") and not stripped.endswith(":"):
                stripped += ":"
            if stripped.startswith("while ") and not stripped.endswith(":"):
                stripped += ":"
            if stripped.startswith("for ") and not stripped.endswith(":"):
                stripped += ":"
            lines.append("    " * indent + stripped)
            indent += open_braces
            indent -= close_braces
            if indent < 0:
                indent = 0

        return "\n".join(lines)

    def call_start(self):
        """Call Start() on all scripts."""
        for eid, payload in self.script_instances.items():
            if not payload.get("start_called", False):
                start_func = payload.get("Start")
                if callable(start_func):
                    try:
                        start_func(payload["instance"])
                        payload["start_called"] = True
                    except Exception as ex:
                        print(f"Start() error: {ex}")
                else:
                    payload["start_called"] = True

    def call_update(self, dt: float):
        """Call Update() on all scripts."""
        self.globals["delta_time"] = dt
        self.globals["time"] = self.globals.get("time", 0) + dt

        for eid, payload in self.script_instances.items():
            update_func = payload.get("Update")
            if callable(update_func):
                try:
                    update_func(payload["instance"])
                except Exception as ex:
                    print(f"Update() error: {ex}")

    def call_fixed_update(self, dt: float):
        """Call FixedUpdate() on all scripts."""
        for eid, payload in self.script_instances.items():
            fixed_func = payload.get("FixedUpdate")
            if callable(fixed_func):
                try:
                    fixed_func(payload["instance"])
                except Exception as ex:
                    print(f"FixedUpdate() error: {ex}")
