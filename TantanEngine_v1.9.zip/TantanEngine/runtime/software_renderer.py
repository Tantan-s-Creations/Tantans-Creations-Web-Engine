"""Software 3D/2D renderer for editor viewport using numpy and PIL"""
import math
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from typing import List, Tuple, Optional, Dict
from ..core.math3d import Vector3, Matrix4

class SoftwareRenderer:
    """Numpy-based software rasterizer for editor viewport"""
    def __init__(self, width=800, height=600):
        self.width = width
        self.height = height
        self.bg_color = (239, 246, 252)
        self.image = Image.new("RGB", (width, height), self.bg_color)
        self.draw = ImageDraw.Draw(self.image)
        self.z_buffer = np.full((height, width), float('inf'))

        # Camera
        self.camera_pos = Vector3(5, 5, 5)
        self.camera_target = Vector3(0, 0, 0)
        self.camera_up = Vector3(0, 1, 0)
        self.fov = 60.0
        self.near = 0.1
        self.far = 1000.0

        # Lighting
        self.light_dir = Vector3(0.3, -0.8, -0.5).normalized()
        self.ambient = 0.3

        # Grid
        self.show_grid = True
        self.grid_size = 20
        self.grid_spacing = 1.0

        # Gizmos
        self.selected_entity = None
        self.gizmo_size = 0.5

        # Stats
        self.frame_triangles = 0
        self.frame_time = 0

    def resize(self, width, height):
        self.width = width
        self.height = height
        self.image = Image.new("RGB", (width, height), self.bg_color)
        self.draw = ImageDraw.Draw(self.image)
        self.z_buffer = np.full((height, width), float('inf'))

    def look_at(self, eye: Vector3, target: Vector3, up: Vector3):
        """Build view matrix from eye, target, up"""
        z = (eye - target).normalized()
        x = up.cross(z).normalized()
        y = z.cross(x)

        view = np.array([
            [x.x, x.y, x.z, -x.dot(eye)],
            [y.x, y.y, y.z, -y.dot(eye)],
            [z.x, z.y, z.z, -z.dot(eye)],
            [0, 0, 0, 1]
        ], dtype=np.float32)
        return view

    def get_view_matrix(self):
        return self.look_at(self.camera_pos, self.camera_target, self.camera_up)

    def get_projection_matrix(self):
        aspect = self.width / self.height if self.height > 0 else 1.0
        return Matrix4.perspective(self.fov, aspect, self.near, self.far).m

    def project_point(self, point: Vector3, view_proj: np.ndarray) -> Optional[Tuple[float, float, float]]:
        """Project 3D point to screen space. Returns (x, y, depth) or None if behind camera."""
        v = np.array([point.x, point.y, point.z, 1.0], dtype=np.float32)
        clip = view_proj @ v

        if clip[3] < 0.001:  # Behind camera
            return None

        ndc = clip[:3] / clip[3]
        # Allow points outside [-1,1] NDC bounds - PIL will clip polygons automatically
        x = (ndc[0] * 0.5 + 0.5) * self.width
        y = (1.0 - (ndc[1] * 0.5 + 0.5)) * self.height
        z = ndc[2]
        return (x, y, z)

    def clear(self):
        self.image = Image.new("RGB", (self.width, self.height), self.bg_color)
        self.draw = ImageDraw.Draw(self.image)
        self.z_buffer = np.full((self.height, self.width), float('inf'))
        self.frame_triangles = 0

    def draw_grid(self, view_proj: np.ndarray):
        """Draw a ground grid"""
        if not self.show_grid:
            return

        color = (168, 192, 214)
        highlight = (113, 158, 138)
        half = self.grid_size // 2

        for i in range(-half, half + 1):
            # X-axis lines (along Z)
            p1 = self.project_point(Vector3(i * self.grid_spacing, 0, -half * self.grid_spacing), view_proj)
            p2 = self.project_point(Vector3(i * self.grid_spacing, 0, half * self.grid_spacing), view_proj)
            if p1 and p2:
                c = highlight if i == 0 else color
                self.draw.line([(p1[0], p1[1]), (p2[0], p2[1])], fill=c, width=1)

            # Z-axis lines (along X)
            p1 = self.project_point(Vector3(-half * self.grid_spacing, 0, i * self.grid_spacing), view_proj)
            p2 = self.project_point(Vector3(half * self.grid_spacing, 0, i * self.grid_spacing), view_proj)
            if p1 and p2:
                c = highlight if i == 0 else color
                self.draw.line([(p1[0], p1[1]), (p2[0], p2[1])], fill=c, width=1)

    def draw_mesh(self, mesh_data: dict, transform_matrix: np.ndarray, view_proj: np.ndarray, 
                  color=(200, 200, 200), wireframe=False):
        """Draw a mesh with transform"""
        if not mesh_data or "vertices" not in mesh_data:
            return

        vertices = mesh_data["vertices"]
        faces = mesh_data.get("faces", [])
        normals = mesh_data.get("normals", [])

        # Transform vertices to world space
        world_verts = []
        for v in vertices:
            wv = transform_matrix @ np.array([v[0], v[1], v[2], 1.0])
            world_verts.append(Vector3(wv[0], wv[1], wv[2]))

        # Draw faces
        for face in faces:
            if len(face) < 3:
                continue

            # Get face vertices
            face_verts = []
            valid = True
            for idx_info in face:
                v_idx = idx_info[0] if isinstance(idx_info, (list, tuple)) else idx_info
                if v_idx < 0 or v_idx >= len(world_verts):
                    valid = False
                    break
                face_verts.append(world_verts[v_idx])

            if not valid or len(face_verts) < 3:
                continue

            # Backface culling - compute normal with correct winding
            if len(face_verts) >= 3:
                v0, v1, v2 = face_verts[0], face_verts[1], face_verts[2]
                edge1 = Vector3(v1.x - v0.x, v1.y - v0.y, v1.z - v0.z)
                edge2 = Vector3(v2.x - v0.x, v2.y - v0.y, v2.z - v0.z)
                # Use edge2 x edge1 to get outward-pointing normal for typical CCW winding
                normal = edge1.cross(edge2).normalized()
                view_dir = Vector3(v0.x - self.camera_pos.x, v0.y - self.camera_pos.y, v0.z - self.camera_pos.z)
                if normal.dot(view_dir) < 0:
                    continue  # Back-facing

            # Project to screen
            screen_verts = []
            for v in face_verts:
                sv = self.project_point(v, view_proj)
                if sv is None:
                    valid = False
                    break
                screen_verts.append(sv)

            if not valid or len(screen_verts) < 3:
                continue

            # Simple flat shading
            if normals and len(face) > 0:
                n_idx = face[0][2] if isinstance(face[0], (list, tuple)) and len(face[0]) > 2 else -1
                if n_idx >= 0 and n_idx < len(normals):
                    n = normals[n_idx]
                    world_normal = Vector3(n[0], n[1], n[2]).normalized()
                else:
                    world_normal = normal
            else:
                world_normal = normal

            light_intensity = max(0.0, -world_normal.dot(self.light_dir))
            intensity = self.ambient + (1.0 - self.ambient) * light_intensity

            r = min(255, int(color[0] * intensity))
            g = min(255, int(color[1] * intensity))
            b = min(255, int(color[2] * intensity))
            face_color = (r, g, b)

            # Draw polygon
            poly = [(v[0], v[1]) for v in screen_verts]
            if wireframe:
                self.draw.polygon(poly, outline=(180, 180, 180))
            else:
                self.draw.polygon(poly, fill=face_color, outline=(60, 60, 60))

            self.frame_triangles += 1

    def draw_cube(self, center: Vector3, size: Vector3, view_proj: np.ndarray, color=(180, 180, 180), wireframe=False):
        """Draw a simple cube"""
        hx, hy, hz = size.x / 2, size.y / 2, size.z / 2
        verts = [
            Vector3(-hx, -hy, -hz), Vector3(hx, -hy, -hz), Vector3(hx, hy, -hz), Vector3(-hx, hy, -hz),
            Vector3(-hx, -hy, hz), Vector3(hx, -hy, hz), Vector3(hx, hy, hz), Vector3(-hx, hy, hz)
        ]
        # Fixed face winding for outward-pointing normals (right-hand rule, CCW when viewed from outside)
        faces = [
            [0, 3, 2, 1],   # Front (z = -hz) -> normal -Z
            [5, 6, 7, 4],   # Back (z = +hz) -> normal +Z
            [4, 7, 3, 0],   # Left (x = -hx) -> normal -X
            [1, 2, 6, 5],   # Right (x = +hx) -> normal +X
            [4, 0, 1, 5],   # Bottom (y = -hy) -> normal -Y
            [3, 7, 6, 2],   # Top (y = +hy) -> normal +Y
        ]

        # Offset by center
        world_verts = [Vector3(v.x + center.x, v.y + center.y, v.z + center.z) for v in verts]

        for face in faces:
            face_verts = [world_verts[i] for i in face]

            # Backface culling
            v0, v1, v2 = face_verts[0], face_verts[1], face_verts[2]
            edge1 = Vector3(v1.x - v0.x, v1.y - v0.y, v1.z - v0.z)
            edge2 = Vector3(v2.x - v0.x, v2.y - v0.y, v2.z - v0.z)
            normal = edge1.cross(edge2).normalized()
            view_dir = Vector3(v0.x - self.camera_pos.x, v0.y - self.camera_pos.y, v0.z - self.camera_pos.z)
            if normal.dot(view_dir) < 0:
                continue

            screen_verts = []
            valid = True
            for v in face_verts:
                sv = self.project_point(v, view_proj)
                if sv is None:
                    valid = False
                    break
                screen_verts.append(sv)

            if valid and len(screen_verts) >= 3:
                light_intensity = max(0.0, -normal.dot(self.light_dir))
                intensity = self.ambient + (1.0 - self.ambient) * light_intensity
                r = min(255, int(color[0] * intensity))
                g = min(255, int(color[1] * intensity))
                b = min(255, int(color[2] * intensity))
                face_color = (r, g, b)

                poly = [(v[0], v[1]) for v in screen_verts]
                if wireframe:
                    self.draw.polygon(poly, outline=(200, 200, 200))
                else:
                    self.draw.polygon(poly, fill=face_color, outline=(50, 50, 50))

                self.frame_triangles += 1

    def draw_gizmo(self, pos: Vector3, view_proj: np.ndarray, selected=False):
        """Draw transform gizmo (XYZ axes)"""
        if not selected:
            return

        size = self.gizmo_size
        # X axis - Red
        p0 = self.project_point(pos, view_proj)
        px = self.project_point(Vector3(pos.x + size, pos.y, pos.z), view_proj)
        if p0 and px:
            self.draw.line([(p0[0], p0[1]), (px[0], px[1])], fill=(229, 118, 132), width=2)

        # Y axis - Green
        py = self.project_point(Vector3(pos.x, pos.y + size, pos.z), view_proj)
        if p0 and py:
            self.draw.line([(p0[0], p0[1]), (py[0], py[1])], fill=(95, 178, 117), width=2)

        # Z axis - Blue
        pz = self.project_point(Vector3(pos.x, pos.y, pos.z + size), view_proj)
        if p0 and pz:
            self.draw.line([(p0[0], p0[1]), (pz[0], pz[1])], fill=(87, 137, 230), width=2)

    def draw_sprite(self, pos: Vector3, size: float, view_proj: np.ndarray, color=(255, 255, 255)):
        """Draw a 2D sprite billboard in 3D space"""
        p = self.project_point(pos, view_proj)
        if p:
            s = size * 50 / max(p[2], 0.1)  # Scale by depth
            x, y = p[0], p[1]
            self.draw.rectangle([x-s, y-s, x+s, y+s], fill=color, outline=(0, 0, 0))

    def render_scene(self, scene, asset_db=None):
        """Render entire scene"""
        self.clear()

        view = self.get_view_matrix()
        proj = self.get_projection_matrix()
        view_proj = proj @ view

        # Draw grid
        self.draw_grid(view_proj)

        # Collect renderable entities
        from ..core.ecs import Transform, MeshFilter, MeshRenderer, SpriteRenderer, Camera, Light

        for entity in scene.root_entities:
            self._render_entity(entity, view_proj, asset_db)

        # Draw stats
        self.draw.text((10, 55), f"Tris: {self.frame_triangles}", fill=(64, 76, 87))
        self.draw.text((10, 70), f"Camera: ({self.camera_pos.x:.1f}, {self.camera_pos.y:.1f}, {self.camera_pos.z:.1f})", fill=(92, 110, 126))

    def _render_entity(self, entity, view_proj, asset_db):
        from ..core.ecs import Transform, MeshFilter, MeshRenderer, SpriteRenderer

        if not entity.active:
            return

        transform = entity.get_component(Transform)
        if not transform:
            return

        # Build transform matrix
        model = transform.get_matrix()
        model_view_proj = view_proj @ model.m

        # Check if selected
        is_selected = (self.selected_entity == entity)

        # Render mesh
        mesh_filter = entity.get_component(MeshFilter)
        mesh_renderer = entity.get_component(MeshRenderer)
        if mesh_filter and mesh_renderer:
            color = (200, 200, 200)
            if asset_db:
                mat = asset_db.get_asset_by_id(mesh_renderer.material_asset_id)
                if mat and hasattr(mat, 'properties'):
                    c = mat.properties.get("color", {})
                    color = (int(c.get("r", 1)*200), int(c.get("g", 1)*200), int(c.get("b", 1)*200))

            if asset_db and mesh_filter.mesh_asset_id:
                mesh_asset = asset_db.get_asset_by_id(mesh_filter.mesh_asset_id)
                if mesh_asset and hasattr(mesh_asset, 'mesh_data') and mesh_asset.mesh_data:
                    self.draw_mesh(mesh_asset.mesh_data, model.m, view_proj, color, wireframe=False)
                else:
                    # Fallback cube
                    self.draw_cube(transform.position, transform.scale, view_proj, color)
            else:
                self.draw_cube(transform.position, transform.scale, view_proj, color)

        # Render sprite
        sprite = entity.get_component(SpriteRenderer)
        if sprite:
            c = sprite.color
            color = (int(c.get("r", 1)*255), int(c.get("g", 1)*255), int(c.get("b", 1)*255))
            self.draw_sprite(transform.position, 0.5, view_proj, color)

        # Draw gizmo if selected
        if is_selected:
            self.draw_gizmo(transform.position, view_proj, True)

        # Render children
        for child in entity.children:
            self._render_entity(child, view_proj, asset_db)

    def get_tk_image(self):
        """Convert PIL image to Tkinter-compatible PhotoImage"""
        from PIL import ImageTk
        return ImageTk.PhotoImage(self.image)
